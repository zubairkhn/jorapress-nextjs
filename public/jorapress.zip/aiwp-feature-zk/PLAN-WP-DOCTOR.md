# JoraPress Roadmap — WordPress Doctor (beating Novamira)

> Status: **Implemented (v1).** Phases A–E built on 2026-06-15. See
> "Implementation status" at the bottom for what shipped and what's deferred.
> Author: Zubair · Date: 2026-06-15

## Vision

Novamira-style tools stop at "an AI builds your site." JoraPress already has a secure
**remote-execution core** (tools + safety + sandbox + backups + audit + skills).
The differentiator is to make JoraPress also a **WordPress Doctor**: it *diagnoses and
fixes* real problems — bugs, fatal errors, performance, and SEO — with every fix
gated, snapshotted, audited, and one-click reversible.

The competitive edge: not just *creating* sites, but *keeping them healthy*.

### What we already have (reuse, don't rebuild)
- Execution core + tool router (`execute_php`, `db_query`, file ops, `wp_cli`, `wp_rest`).
- Safety layer: master kill switch, production guardrail, write-gating, rate limits.
- Crash guard, sandbox (versioned/revertible), pre-write backups, immutable audit log.
- Two front doors: MCP endpoint (BYO agent) + admin chat (BYO API key).
- Skills (Markdown playbooks) + memory.

All new capability below is built **on top of** these — new diagnostic tools,
remediation flows, skills packs, and a dashboard. No bypassing the safety layer.

---

## Design principles
1. **Diagnose before fix.** Every domain has a read-only scanner that returns a
   structured, prioritized issue list before anything is changed.
2. **Every fix is reversible.** Fixers route through existing write-gating,
   backups, sandbox, and audit. Nothing new touches the DB/filesystem unsafely.
3. **Auto-fixable vs. manual.** Each issue is tagged `auto` (safe to apply
   automatically) or `manual` (needs human judgment / approval).
4. **Severity-ranked.** Critical → Warning → Recommendation, with evidence.
5. **Provider-agnostic.** Scanners are pure PHP; only AI-assisted fixes (e.g.
   meta-description generation) use the configured provider.

### Common issue schema (returned by every scanner)
```jsonc
{
  "id": "perf.autoload_bloat",
  "domain": "performance",          // bugs | performance | seo | health
  "severity": "warning",            // critical | warning | recommendation
  "title": "Autoloaded options are 2.3 MB",
  "evidence": { "size_kb": 2304, "top": [["plugin_x_cache", 1800]] },
  "suggested_fix": "Stop autoloading large transient-like options.",
  "auto_fixable": true,
  "fix_tool": "perf_fix",
  "fix_args": { "action": "trim_autoload" }
}
```

---

## Phase A — Diagnostics core (read-only scanners)

New tools, exposed over **both** MCP (`tools/list`) and the chat agent. Each
lives in `includes/core/tools/` implementing the existing tool interface, and is
registered in the tool router.

| Tool | Detects |
|------|---------|
| `site_health` | Wraps WP Site Health; PHP/MySQL versions, HTTPS, loopback cron, REST availability, object cache, debug flags. |
| `error_scan` | Parses `wp-content/debug.log` and recent fatals; maps each error to offending plugin/theme/file/line; flags deprecated APIs and PHP-version incompatibilities. |
| `perf_scan` | Autoloaded-options bloat, slow/duplicate queries, transient & expired-cron buildup, missing object/page cache, oversized images, render-blocking CSS/JS, missing cache headers, large DB tables/revisions. |
| `seo_scan` | Missing/duplicate titles & meta descriptions, H1 structure, image alt text, XML sitemap, robots.txt, canonicals, Open Graph/Twitter cards, JSON-LD schema, broken internal links, noindex mistakes. |

Deliverables:
- `class-jorapress-site-health-tool.php`, `class-jorapress-error-scan-tool.php`,
  `class-jorapress-perf-scan-tool.php`, `class-jorapress-seo-scan-tool.php`.
- A shared `Scanner` base/trait producing the issue schema above.
- Register all four in the tool router + MCP `tools/list`.

---

## Phase B — Remediation (gated, sandboxed, reversible)

Each scanner pairs with a fixer tool. Fixers **must** go through the existing
safety pipeline (write-gating → backup snapshot → apply → audit → revertible).

**Bugs / errors (`bug_fix`)**
- Deactivate/patch the offending plugin or theme code on a caught fatal.
- Replace deprecated function calls with current equivalents.
- Repair common `wp-config`/permission/cron misconfigurations.

**Performance (`perf_fix`)**
- Trim autoload bloat; purge stale transients and expired cron.
- Clean post revisions / orphaned meta (snapshotted first).
- Image optimization (resize/recompress/WebP) for oversized media.
- Defer/async non-critical JS, move render-blocking CSS.
- Enable/configure object cache & page cache where the host allows.

**SEO (`seo_fix`)**
- AI-generated titles & meta descriptions (uses configured provider).
- Auto alt-text for images missing it.
- Inject JSON-LD schema (Article/Product/LocalBusiness/Breadcrumb).
- Generate/repair XML sitemap and robots.txt.
- Fix broken internal links and bad canonicals.

Each fixer supports a `dry_run` mode that returns the planned diff without
applying, so the agent (or dashboard) can preview before committing.

---

## Phase C — Skills packs

Add Markdown playbooks under `includes/skills/packs/` so the agent auto-loads the
right knowledge when a task matches:
- `debugging.md` — reading logs, isolating plugin conflicts, safe-mode triage.
- `performance.md` — diagnosis order, caching strategy, image/DB hygiene.
- `seo.md` — on-page checklist, schema patterns, sitemap/robots best practice.
- `wp-best-practices.md` — coding standards, security, deprecation map.

---

## Phase D — "Site Doctor" admin dashboard

New JoraPress submenu (`jorapress-doctor`) + view + REST controller, reusing the existing
REST/audit/sandbox plumbing and `admin/js/admin.js` patterns.

- Run scans on demand; results grouped into **Bugs / Performance / SEO / Health**.
- Severity badges, evidence, and per-issue **Fix** / **Fix all safe** buttons.
- Before/after diff preview (from fixer `dry_run`) and one-click **Revert**
  (sandbox/backup history).
- Overall **Health Score** (0–100) with breakdown per domain.

Deliverables: `includes/admin/views/doctor.php`, a `Doctor` REST controller,
menu entry in `class-jorapress-admin.php`, UI in `admin/js/` + styles.

---

## Phase E — Automation & reporting

- Scheduled audits via WP-Cron (daily/weekly, configurable).
- Email/summary report with new issues and resolved counts.
- Health-score trend stored over time (recurring value, the retention hook).
- Optional: notify on new critical issues only.

Deliverables: cron registration in the activator, a `Reporter` class, settings
for cadence/recipients, a `jorapress_doctor_history` table (or option store).

---

## Suggested build order
1. **Phase A** scanners (all four) — pure value, zero risk, read-only.
2. **Phase D** dashboard wired to the scanners — makes the value visible.
3. **Phase B** fixers, domain by domain, each behind the safety layer.
4. **Phase C** skills packs alongside the matching fixers.
5. **Phase E** automation last, once scans+fixes are trusted.

## Safety & guardrails (unchanged contract)
- Nothing here weakens existing gating. Fixers respect the master switch,
  production guardrail, write-gating, rate limits, backups, and audit log.
- Destructive cleanups (revisions, orphaned data) always snapshot first and are
  revertible from the Sandbox/history UI.
- AI-assisted SEO writes are previewable (`dry_run`) before they touch content.

## Implementation status (v1 — 2026-06-15)

**Shipped:**
- **Phase A** — `ScannerTool` base + `site_health`, `error_scan`, `perf_scan`,
  `seo_scan`, all registered in the tool router (so they appear over MCP and in
  the chat agent). Shared issue schema + severity ranking.
- **Phase B** — `FixerTool` base + `bug_fix`, `perf_fix`, `seo_fix` with
  `dry_run` preview, write-gating via `is_write()`, and pre-write snapshots.
- **Phase C** — skills packs: `debugging`, `performance`, `seo`,
  `wp-best-practices`.
- **Phase D** — Site Doctor menu + view, `DoctorController` REST routes
  (`/doctor/scan`, `/doctor/fix`, `/doctor/history`), health score + ring UI,
  per-issue Preview/Apply, `doctor.js` + styles. Scans run read-only regardless
  of the master switch; fixes route through the full safety pipeline.
- **Phase E** — `Reporter` WP-Cron audits (off/daily/weekly), emailed summary,
  rolling score history; settings fields + reschedule on save; scheduled on
  activation, cleared on deactivation.

**Deferred / follow-ups:**
- Image optimization ships as a hook (`jorapress_optimize_image`) — no bundled
  optimizer yet.
- AI-written SEO copy ships as a hook (`jorapress_seo_generate_text`) with a
  heuristic fallback — not yet wired to the provider manager.
- Health-score trend is stored but not yet charted in the dashboard.
- `clean_revisions` uses a window function (MySQL 8.0+/MariaDB 10.2+).
- JSON-LD schema, Open Graph, broken-link repair are agent tasks via
  `execute_php`, not yet dedicated fixer actions.

## Open questions
- Bundle image optimization in-plugin or call an external service/library?
- Object/page cache: configure popular plugins (W3TC/LiteSpeed) or ship our own
  drop-in?
- Health-score weighting per domain — expose as a setting?
