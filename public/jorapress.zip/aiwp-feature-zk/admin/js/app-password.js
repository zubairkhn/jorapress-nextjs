/**
 * Enhances WordPress core's "Application Passwords" screen (profile.php /
 * user-edit.php). When core reveals a newly generated password — shown only as
 * a space-chunked raw string — this adds two ready-to-use Base64 values:
 *
 *   • the full HTTP Basic "Authorization" header, and
 *   • the Base64 token on its own.
 *
 * Both are computed entirely in the browser from the password core just
 * displayed, so the secret is never sent back to the server. Spaces are
 * stripped because WordPress ignores them when verifying application passwords.
 *
 * @package JoraPress
 */
( function () {
	'use strict';

	var cfg = window.JORAPRESS_APP_PW || {};
	var strings = cfg.strings || {};

	function base64( str ) {
		try {
			return window.btoa( unescape( encodeURIComponent( str ) ) );
		} catch ( e ) {
			return '';
		}
	}

	function field( labelText, value ) {
		var p = document.createElement( 'p' );
		p.style.margin = '6px 0 0';

		var label = document.createElement( 'label' );
		label.textContent = labelText;
		label.style.display = 'block';
		label.style.fontWeight = '600';

		var row = document.createElement( 'span' );
		row.style.display = 'inline-flex';
		row.style.gap = '6px';
		row.style.alignItems = 'center';
		row.style.maxWidth = '100%';

		var input = document.createElement( 'input' );
		input.type = 'text';
		input.readOnly = true;
		input.className = 'code';
		input.value = value;
		input.style.minWidth = '320px';
		input.style.flex = '1 1 auto';
		input.addEventListener( 'focus', function () { input.select(); } );

		var btn = document.createElement( 'button' );
		btn.type = 'button';
		btn.className = 'button button-secondary';
		btn.textContent = strings.copy || 'Copy';
		btn.addEventListener( 'click', function () {
			input.select();
			if ( navigator.clipboard ) {
				navigator.clipboard.writeText( value );
			} else {
				document.execCommand( 'copy' );
			}
			var original = btn.textContent;
			btn.textContent = strings.copied || 'Copied!';
			setTimeout( function () { btn.textContent = original; }, 1500 );
		} );

		row.appendChild( input );
		row.appendChild( btn );
		p.appendChild( label );
		p.appendChild( row );
		return p;
	}

	function enhance( input ) {
		if ( input.dataset.jorapressEnhanced ) {
			return;
		}
		input.dataset.jorapressEnhanced = '1';

		var raw = ( input.value || '' ).replace( /\s+/g, '' );
		if ( ! raw ) {
			return;
		}

		var login = cfg.login || '';
		var token = base64( login + ':' + raw );
		if ( ! token ) {
			return;
		}

		var wrap = document.createElement( 'div' );
		wrap.className = 'jorapress-app-pw-base64';
		wrap.style.marginTop = '10px';
		wrap.appendChild( field( strings.header || 'Authorization header:', 'Basic ' + token ) );
		wrap.appendChild( field( strings.token || 'Base64 token only:', token ) );

		var anchor = input.closest( '.application-password-display' ) || input.parentNode;
		anchor.parentNode.insertBefore( wrap, anchor.nextSibling );
	}

	function scan() {
		var input = document.getElementById( 'new-application-password-value' );
		if ( input ) {
			enhance( input );
		}
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		scan(); // In case it is already present.

		var section = document.getElementById( 'application-passwords-section' ) || document.body;
		var observer = new MutationObserver( scan );
		observer.observe( section, { childList: true, subtree: true } );
	} );
} )();
