/**
 * JoraPress admin front-end. Vanilla JS (no build step). Drives the chat panel,
 * sandbox manager and audit viewer against the REST API. Uses wp.apiFetch so
 * the REST nonce is attached automatically.
 *
 * @package JoraPress
 */
( function () {
	'use strict';

	var cfg = window.JoraPress || {};
	var api = window.wp && window.wp.apiFetch ? window.wp.apiFetch : null;

	function request( path, method, data ) {
		var url = cfg.root + path;
		if ( api ) {
			return api( { url: url, method: method || 'GET', data: data || undefined } );
		}
		// Fallback to fetch with explicit nonce.
		return fetch( url, {
			method: method || 'GET',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': cfg.nonce
			},
			body: data ? JSON.stringify( data ) : undefined,
			credentials: 'same-origin'
		} ).then( function ( r ) { return r.json(); } );
	}

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( text !== undefined ) { n.textContent = text; }
		return n;
	}

	// ---------------------------------------------------------------- Chat
	function initChat( root ) {
		var log = document.getElementById( 'jorapress-chat-log' );
		var pendingBox = document.getElementById( 'jorapress-chat-pending' );
		var form = document.getElementById( 'jorapress-chat-form' );
		var input = document.getElementById( 'jorapress-chat-input' );
		var messages = []; // internal message list mirrored client-side.

		function bubble( role, text ) {
			var b = el( 'div', 'jorapress-msg jorapress-msg--' + role );
			b.appendChild( el( 'div', 'jorapress-msg__role', role ) );
			var body = el( 'div', 'jorapress-msg__body' );
			body.textContent = text || '';
			b.appendChild( body );
			log.appendChild( b );
			log.scrollTop = log.scrollHeight;
			return b;
		}

		function renderSteps( steps ) {
			( steps || [] ).forEach( function ( s ) {
				var d = el( 'details', 'jorapress-step' );
				var sum = el( 'summary', null, '🔧 ' + s.tool + ( s.result && s.result.ok === false ? ' — error' : ' — ok' ) );
				d.appendChild( sum );
				var pre = el( 'pre', 'jorapress-step__pre' );
				pre.textContent = JSON.stringify( { args: s.args, result: s.result }, null, 2 );
				d.appendChild( pre );
				log.appendChild( d );
			} );
			log.scrollTop = log.scrollHeight;
		}

		function setBusy( busy ) {
			form.querySelector( 'button' ).disabled = busy;
			input.disabled = busy;
		}

		function handleResult( res ) {
			if ( ! res ) { return; }
			if ( res.messages ) { messages = res.messages; }
			renderSteps( res.steps );

			if ( res.status === 'error' ) {
				bubble( 'system', '⚠ ' + ( res.error || 'Error' ) );
				setBusy( false );
				return;
			}
			if ( res.assistant_text ) {
				bubble( 'assistant', res.assistant_text );
			}
			if ( res.status === 'awaiting_approval' ) {
				renderApproval( res.pending );
				setBusy( false );
				return;
			}
			if ( res.status === 'max_steps' ) {
				bubble( 'system', 'Reached the step limit. Send another message to continue.' );
			}
			setBusy( false );
		}

		function renderApproval( pending ) {
			pendingBox.hidden = false;
			pendingBox.innerHTML = '';
			pendingBox.appendChild( el( 'h3', null, 'The agent wants to run ' + pending.length + ' action(s):' ) );

			pending.forEach( function ( tc ) {
				var card = el( 'div', 'jorapress-pending__card' );
				card.appendChild( el( 'strong', null, tc.name ) );
				var pre = el( 'pre' );
				pre.textContent = JSON.stringify( tc.arguments, null, 2 );
				card.appendChild( pre );
				pendingBox.appendChild( card );
			} );

			var approve = el( 'button', 'button button-primary', cfg.strings.approve );
			var deny = el( 'button', 'button', cfg.strings.deny );
			approve.onclick = function () { resolveApproval( pending, [] ); };
			deny.onclick = function () { resolveApproval( [], pending ); };
			pendingBox.appendChild( approve );
			pendingBox.appendChild( deny );
		}

		function resolveApproval( approved, denied ) {
			pendingBox.hidden = true;
			pendingBox.innerHTML = '';
			setBusy( true );
			bubble( 'system', approved.length ? cfg.strings.thinking : 'Denied. Continuing…' );
			request( '/chat/approve', 'POST', { messages: messages, approved: approved, denied: denied } )
				.then( function ( res ) {
					if ( res.messages ) { messages = res.messages; }
					renderSteps( res.steps );
					// Continue the loop with no new prompt.
					return request( '/chat/run', 'POST', { messages: messages, prompt: '' } );
				} )
				.then( handleResult )
				.catch( function ( e ) { bubble( 'system', '⚠ ' + e.message ); setBusy( false ); } );
		}

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var text = input.value.trim();
			if ( ! text ) { return; }
			bubble( 'user', text );
			input.value = '';
			setBusy( true );
			bubble( 'system', cfg.strings.thinking );
			request( '/chat/run', 'POST', { messages: messages, prompt: text } )
				.then( handleResult )
				.catch( function ( err ) { bubble( 'system', '⚠ ' + err.message ); setBusy( false ); } );
		} );
	}

	// ------------------------------------------------------------- Sandbox
	function initSandbox( root ) {
		function render( files ) {
			root.innerHTML = '';
			if ( ! files || ! files.length ) {
				root.appendChild( el( 'p', null, 'No sandbox files yet.' ) );
				return;
			}
			var table = el( 'table', 'widefat striped' );
			var thead = el( 'thead' );
			thead.innerHTML = '<tr><th>File</th><th>Rev</th><th>Updated</th><th>Status</th><th>Actions</th></tr>';
			table.appendChild( thead );
			var tbody = el( 'tbody' );

			files.forEach( function ( f ) {
				var tr = el( 'tr' );
				tr.appendChild( el( 'td', null, f.rel_path ) );
				tr.appendChild( el( 'td', null, f.revision ) );
				tr.appendChild( el( 'td', null, f.updated_at ) );
				var status = Number( f.fatal ) ? 'FATAL (disabled)' : ( Number( f.disabled ) ? 'disabled' : 'active' );
				tr.appendChild( el( 'td', null, status ) );

				var actions = el( 'td' );
				var toggle = el( 'button', 'button button-small', Number( f.disabled ) ? 'Enable' : 'Disable' );
				toggle.onclick = function () { act( Number( f.disabled ) ? 'enable' : 'disable', f.rel_path ); };
				var revert = el( 'button', 'button button-small button-link-delete', 'Revert' );
				revert.onclick = function () {
					if ( window.confirm( 'Delete (revert) ' + f.rel_path + '? A backup is kept.' ) ) {
						act( 'revert', f.rel_path );
					}
				};
				actions.appendChild( toggle );
				actions.appendChild( document.createTextNode( ' ' ) );
				actions.appendChild( revert );
				tr.appendChild( actions );
				tbody.appendChild( tr );
			} );
			table.appendChild( tbody );
			root.appendChild( table );
		}

		function act( type, path ) {
			request( '/sandbox/action', 'POST', { action_type: type, rel_path: path } )
				.then( function ( r ) { render( r.files ); } );
		}

		request( '/sandbox', 'GET' ).then( function ( r ) { render( r.files ); } );
	}

	// --------------------------------------------------------------- Audit
	function initAudit( root ) {
		request( '/audit', 'GET' ).then( function ( r ) {
			root.innerHTML = '';
			var entries = r.entries || [];
			if ( ! entries.length ) {
				root.appendChild( el( 'p', null, 'No activity yet.' ) );
				return;
			}
			var table = el( 'table', 'widefat striped' );
			table.innerHTML = '<thead><tr><th>When</th><th>User</th><th>Door</th><th>Tool</th><th>Status</th></tr></thead>';
			var tbody = el( 'tbody' );
			entries.forEach( function ( e2 ) {
				var tr = el( 'tr' );
				tr.appendChild( el( 'td', null, e2.created_at ) );
				tr.appendChild( el( 'td', null, e2.user_id ) );
				tr.appendChild( el( 'td', null, e2.front_door ) );
				tr.appendChild( el( 'td', null, e2.tool ) );
				tr.appendChild( el( 'td', null, e2.status ) );
				tbody.appendChild( tr );
			} );
			table.appendChild( tbody );
			root.appendChild( table );
		} );
	}

	// ------------------------------------------------------------- Connect
	function initConnect( root ) {
		var url = root.getAttribute( 'data-mcp-url' );
		var allowHttp = root.getAttribute( 'data-allow-http' ) === '1';
		var userInput = document.getElementById( 'jorapress-connect-user' );
		var passInput = document.getElementById( 'jorapress-connect-pass' );
		var headerOut = document.getElementById( 'jorapress-connect-header' );
		var desktopOut = document.getElementById( 'jorapress-connect-desktop' );
		var claudeOut = document.getElementById( 'jorapress-connect-claudecode' );
		var cursorOut = document.getElementById( 'jorapress-connect-cursor' );

		function b64( str ) {
			// btoa needs binary-safe input; encode UTF-8 first.
			try {
				return btoa( unescape( encodeURIComponent( str ) ) );
			} catch ( e ) {
				return '';
			}
		}

		function render() {
			var user = ( userInput.value || '' ).trim();
			var pass = ( passInput.value || '' ).trim();
			var placeholder = ! pass;
			// WordPress accepts the spaces in app passwords; keep them as typed.
			var token = b64( user + ':' + pass );
			var header = 'Basic ' + ( placeholder ? '<paste your application password above>' : token );

			headerOut.textContent = header;

			// Claude Desktop via mcp-remote bridge.
			var args = [ '-y', 'mcp-remote', url ];
			if ( allowHttp ) { args.push( '--allow-http' ); }
			args.push( '--header', 'Authorization: ' + header );

			var desktop = {
				mcpServers: {
					jorapress: {
						command: 'npx',
						args: args
					}
				}
			};
			desktopOut.textContent = JSON.stringify( desktop, null, 2 );

			// Claude Code CLI.
			var cc = 'claude mcp add --transport http jorapress ' + url +
				' --header "Authorization: ' + header + '"';
			claudeOut.textContent = cc;

			// Cursor / Windsurf — native http transport (no bridge needed).
			var cursor = {
				mcpServers: {
					jorapress: {
						type: 'http',
						url: url,
						headers: { Authorization: header }
					}
				}
			};
			cursorOut.textContent = JSON.stringify( cursor, null, 2 );
		}

		userInput.addEventListener( 'input', render );
		passInput.addEventListener( 'input', render );
		render();
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var node = document.querySelector( '[data-jorapress-app]' );
		if ( ! node ) { return; }
		var app = node.getAttribute( 'data-jorapress-app' );
		if ( 'chat' === app ) { initChat( node ); }
		else if ( 'sandbox' === app ) { initSandbox( node ); }
		else if ( 'audit' === app ) { initAudit( node ); }
		else if ( 'connect' === app ) { initConnect( node ); }
	} );
}() );
