<?php
/**
 * Plugin Name:       JoraPress — AI WordPress Builder
 * Plugin URI:        https://gharfar.com/jorapress
 * Description:       A Novamira-style AI bridge for WordPress. Exposes a secure remote-execution core to an external AI agent over MCP (Bring Your Own Agent) and a built-in admin chat panel (BYO API key). The AI builds and designs sites with any page builder (Elementor, Bricks, Divi, Gutenberg…) by running PHP, SQL, WP-CLI and file operations — no per-builder code required.
 * Version:           0.1.0
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Author:            Zubair
 * Author URI:        https://gharfar.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       jorapress
 * Domain Path:       /languages
 *
 * @package JoraPress
 *
 * ---------------------------------------------------------------------------
 * SECURITY NOTICE
 * ---------------------------------------------------------------------------
 * This plugin ships REMOTE ARBITRARY CODE EXECUTION as a feature. It is meant
 * for development and staging environments. Treat the security layer as the
 * product. Do not run it on a production site with live traffic.
 * ---------------------------------------------------------------------------
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

// ---------------------------------------------------------------------------
// Constants. Rename these (and the text domain) when you finalise the plugin
// name — a single find-and-replace of "jorapress"/"JoraPress" handles the rest.
// ---------------------------------------------------------------------------
define( 'JORAPRESS_VERSION', '0.1.0' );
define( 'JORAPRESS_SLUG', 'jorapress' );
define( 'JORAPRESS_FILE', __FILE__ );
define( 'JORAPRESS_DIR', plugin_dir_path( __FILE__ ) );
define( 'JORAPRESS_URL', plugin_dir_url( __FILE__ ) );
define( 'JORAPRESS_BASENAME', plugin_basename( __FILE__ ) );

// REST namespace used by both the MCP endpoint and the admin chat panel.
define( 'JORAPRESS_REST_NAMESPACE', 'jorapress/v1' );

// Minimum capability required to use any AI ability.
define( 'JORAPRESS_CAPABILITY', 'manage_options' );

// ---------------------------------------------------------------------------
// Composer autoload (optional). The plugin also ships a PSR-style manual
// loader below so it runs even without `composer install`.
// ---------------------------------------------------------------------------
if ( file_exists( JORAPRESS_DIR . 'vendor/autoload.php' ) ) {
	require_once JORAPRESS_DIR . 'vendor/autoload.php';
}

require_once JORAPRESS_DIR . 'includes/class-jorapress-autoloader.php';
JoraPress\Autoloader::register();

// ---------------------------------------------------------------------------
// Activation / deactivation / uninstall hooks.
// ---------------------------------------------------------------------------
register_activation_hook( __FILE__, array( '\JoraPress\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\JoraPress\Deactivator', 'deactivate' ) );

// ---------------------------------------------------------------------------
// Boot.
// ---------------------------------------------------------------------------
add_action(
	'plugins_loaded',
	static function (): void {
		\JoraPress\Plugin::instance()->boot();
	},
	5
);
