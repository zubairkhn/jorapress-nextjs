<?php
/**
 * Exception thrown by the safety layer. Carries an HTTP-ish status code so the
 * front doors can translate it into the right response.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SafetyException extends \RuntimeException {

	public function __construct( string $message, int $code = 400 ) {
		parent::__construct( $message, $code );
	}
}
