<?php
/**
 * wp_cli — run WP-CLI commands where the host allows shell access. Degrades
 * gracefully when shell_exec / proc_open are disabled (common on shared hosts).
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WpCliTool implements ToolInterface {

	public function name(): string {
		return 'wp_cli';
	}

	public function description(): string {
		return 'Run a WP-CLI command (without the leading "wp"). Examples: "plugin list --status=active", '
			. '"search-replace olddomain.com newdomain.com --dry-run", "cache flush". Requires shell access '
			. 'on the host and the wp_cli capability to be enabled.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'command' => array(
					'type'        => 'string',
					'description' => 'WP-CLI command without the leading "wp", e.g. "plugin list".',
				),
			),
			'required'   => array( 'command' ),
		);
	}

	/**
	 * Most WP-CLI commands can mutate state; treat as write unless a read verb.
	 */
	public function is_write( array $args ): bool {
		$cmd  = strtolower( trim( (string) ( $args['command'] ?? '' ) ) );
		$read = array( 'plugin list', 'theme list', 'option get', 'post list', 'user list', 'core version', '--info', 'cli info' );
		foreach ( $read as $r ) {
			if ( str_starts_with( $cmd, $r ) ) {
				return false;
			}
		}
		return true;
	}

	public function run( array $args ): array {
		if ( ! $this->shell_available() ) {
			return array(
				'ok'    => false,
				'error' => 'Shell execution is disabled on this host; WP-CLI is unavailable. Use execute_php instead.',
			);
		}

		$command = (string) ( $args['command'] ?? '' );
		if ( '' === trim( $command ) ) {
			return array(
				'ok'    => false,
				'error' => 'No command provided.',
			);
		}

		$bin  = $this->locate_wp_cli();
		$path = escapeshellarg( ABSPATH );
		$full = sprintf( '%s --path=%s %s 2>&1', $bin, $path, $command );

		$output    = array();
		$exit_code = 0;
		exec( $full, $output, $exit_code ); // phpcs:ignore

		return array(
			'ok'        => 0 === $exit_code,
			'exit_code' => $exit_code,
			'output'    => implode( "\n", $output ),
		);
	}

	private function shell_available(): bool {
		if ( ! function_exists( 'exec' ) ) {
			return false;
		}
		$disabled = explode( ',', (string) ini_get( 'disable_functions' ) );
		$disabled = array_map( 'trim', $disabled );
		return ! in_array( 'exec', $disabled, true );
	}

	private function locate_wp_cli(): string {
		// Prefer a bundled phar or a PATH binary.
		foreach ( array( 'wp', '/usr/local/bin/wp', WP_CONTENT_DIR . '/wp-cli.phar' ) as $candidate ) {
			if ( 'wp' === $candidate || file_exists( $candidate ) ) {
				return 'wp' === $candidate ? 'wp' : escapeshellarg( $candidate );
			}
		}
		return 'wp';
	}
}
