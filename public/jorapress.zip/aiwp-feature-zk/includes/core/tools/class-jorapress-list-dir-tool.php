<?php
/**
 * list_dir — list directory contents within the WordPress install.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ListDirTool extends FilesystemTool {

	public function name(): string {
		return 'list_dir';
	}

	public function description(): string {
		return 'List files and folders in a directory relative to the WordPress install root.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'path' => array(
					'type'        => 'string',
					'description' => 'Directory relative to the install root. Use "" or "." for root.',
				),
			),
			'required'   => array( 'path' ),
		);
	}

	public function run( array $args ): array {
		$rel = trim( (string) ( $args['path'] ?? '' ) );
		if ( '' === $rel || '.' === $rel ) {
			$rel = '';
		}
		$abs = $this->resolve( $rel );

		if ( ! is_dir( $abs ) ) {
			return array(
				'ok'    => false,
				'error' => 'Not a directory.',
			);
		}

		$items = array();
		$dh     = scandir( $abs );
		foreach ( (array) $dh as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}
			$full    = $abs . '/' . $entry;
			$items[] = array(
				'name' => $entry,
				'type' => is_dir( $full ) ? 'dir' : 'file',
				'size' => is_file( $full ) ? filesize( $full ) : null,
			);
		}

		return array(
			'ok'    => true,
			'path'  => $rel,
			'items' => $items,
		);
	}
}
