<?php
/**
 * Base class for JoraPress "Doctor" scanners — read-only diagnostic tools that audit
 * the site and return a prioritized list of issues in a shared schema.
 *
 * Every scanner is read-only (is_write() === false) and never touches the DB or
 * filesystem destructively. Each issue it reports follows {@see issue()} so the
 * Site Doctor dashboard and the AI agent can consume them uniformly and decide
 * what (if anything) to fix.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class ScannerTool implements ToolInterface {

	public const SEVERITY_CRITICAL       = 'critical';
	public const SEVERITY_WARNING        = 'warning';
	public const SEVERITY_RECOMMENDATION = 'recommendation';

	/** Domain this scanner reports under: bugs | performance | seo | health. */
	abstract protected function domain(): string;

	/** Collect issues. @return array<int,array<string,mixed>> */
	abstract protected function scan(): array;

	/**
	 * Scanners take no required arguments. The optional `severity` filter trims
	 * the result to issues at or above the requested level.
	 */
	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'min_severity' => array(
					'type'        => 'string',
					'enum'        => array( self::SEVERITY_RECOMMENDATION, self::SEVERITY_WARNING, self::SEVERITY_CRITICAL ),
					'description' => 'Only return issues at or above this severity. Default: recommendation (all).',
				),
			),
			'required'   => array(),
		);
	}

	/** Scanners are always read-only. */
	public function is_write( array $args ): bool {
		return false;
	}

	public function run( array $args ): array {
		$min    = (string) ( $args['min_severity'] ?? self::SEVERITY_RECOMMENDATION );
		$issues = array();

		foreach ( $this->scan() as $issue ) {
			if ( $this->rank( (string) ( $issue['severity'] ?? '' ) ) >= $this->rank( $min ) ) {
				$issues[] = $issue;
			}
		}

		// Critical first.
		usort(
			$issues,
			fn( $a, $b ) => $this->rank( (string) $b['severity'] ) <=> $this->rank( (string) $a['severity'] )
		);

		return array(
			'ok'      => true,
			'domain'  => $this->domain(),
			'summary' => $this->tally( $issues ),
			'issues'  => $issues,
		);
	}

	/**
	 * Build one issue in the shared schema.
	 *
	 * @param array<string,mixed> $extra Optional: evidence, fix_tool, fix_args, auto_fixable.
	 * @return array<string,mixed>
	 */
	protected function issue( string $id, string $severity, string $title, string $suggested_fix, array $extra = array() ): array {
		return array_merge(
			array(
				'id'            => $this->domain() . '.' . $id,
				'domain'        => $this->domain(),
				'severity'      => $severity,
				'title'         => $title,
				'suggested_fix' => $suggested_fix,
				'auto_fixable'  => (bool) ( $extra['auto_fixable'] ?? false ),
				'evidence'      => $extra['evidence'] ?? array(),
				'fix_tool'      => $extra['fix_tool'] ?? null,
				'fix_args'      => $extra['fix_args'] ?? null,
			),
			array()
		);
	}

	/** @param array<int,array<string,mixed>> $issues */
	protected function tally( array $issues ): array {
		$counts = array(
			self::SEVERITY_CRITICAL       => 0,
			self::SEVERITY_WARNING        => 0,
			self::SEVERITY_RECOMMENDATION => 0,
		);
		foreach ( $issues as $i ) {
			$sev = (string) ( $i['severity'] ?? self::SEVERITY_RECOMMENDATION );
			if ( isset( $counts[ $sev ] ) ) {
				++$counts[ $sev ];
			}
		}
		$counts['total'] = count( $issues );
		return $counts;
	}

	private function rank( string $severity ): int {
		return match ( $severity ) {
			self::SEVERITY_CRITICAL       => 3,
			self::SEVERITY_WARNING        => 2,
			self::SEVERITY_RECOMMENDATION => 1,
			default                       => 0,
		};
	}
}
