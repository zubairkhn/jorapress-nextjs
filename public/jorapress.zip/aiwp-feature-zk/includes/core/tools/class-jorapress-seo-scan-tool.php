<?php
/**
 * seo_scan — on-page SEO audit across published content: missing/duplicate
 * titles & meta descriptions, missing image alt text, sitemap/robots presence,
 * and noindex mistakes. Read-only; findings point at the seo_fix actions.
 *
 * Works with or without a dedicated SEO plugin: it reads Yoast/Rank Math meta
 * keys when present and falls back to the post title/excerpt otherwise.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SeoScanTool extends ScannerTool {

	private const SAMPLE = 200; // Cap posts inspected per run.

	public function name(): string {
		return 'seo_scan';
	}

	public function description(): string {
		return 'Audit on-page SEO: missing/duplicate titles & meta descriptions, missing image alt text, XML sitemap, robots.txt and accidental noindex.';
	}

	protected function domain(): string {
		return 'seo';
	}

	protected function scan(): array {
		$issues = array();

		$posts = get_posts(
			array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => 'publish',
				'posts_per_page' => self::SAMPLE,
				'no_found_rows'  => true,
			)
		);

		$missing_desc = array();
		$descriptions = array();
		$titles       = array();

		foreach ( $posts as $post ) {
			$desc = $this->meta_description( $post->ID );
			if ( '' === $desc ) {
				$missing_desc[] = array( 'id' => $post->ID, 'title' => get_the_title( $post ) );
			} else {
				$descriptions[ md5( strtolower( trim( $desc ) ) ) ][] = $post->ID;
			}

			$title                          = strtolower( trim( get_the_title( $post ) ) );
			$titles[ md5( $title ) ][]      = $post->ID;
		}

		// Missing meta descriptions.
		if ( ! empty( $missing_desc ) ) {
			$issues[] = $this->issue(
				'missing_meta_desc',
				self::SEVERITY_WARNING,
				sprintf( '%d page(s) missing a meta description', count( $missing_desc ) ),
				'Add concise meta descriptions (JoraPress can generate them with AI).',
				array(
					'evidence'     => array( 'items' => array_slice( $missing_desc, 0, 25 ) ),
					'auto_fixable' => true,
					'fix_tool'     => 'seo_fix',
					'fix_args'     => array( 'action' => 'generate_meta', 'post_ids' => wp_list_pluck( $missing_desc, 'id' ) ),
				)
			);
		}

		// Duplicate meta descriptions.
		foreach ( $descriptions as $ids ) {
			if ( count( $ids ) > 1 ) {
				$issues[] = $this->issue(
					'dup_meta_desc',
					self::SEVERITY_RECOMMENDATION,
					sprintf( '%d pages share an identical meta description', count( $ids ) ),
					'Make each meta description unique to avoid diluting relevance.',
					array( 'evidence' => array( 'post_ids' => $ids ) )
				);
				break; // One representative issue is enough.
			}
		}

		// Duplicate titles.
		foreach ( $titles as $ids ) {
			if ( count( $ids ) > 1 ) {
				$issues[] = $this->issue(
					'dup_title',
					self::SEVERITY_RECOMMENDATION,
					sprintf( '%d pages share an identical title', count( $ids ) ),
					'Give each page a unique, descriptive title.',
					array( 'evidence' => array( 'post_ids' => $ids ) )
				);
				break;
			}
		}

		// Images missing alt text.
		$no_alt = $this->images_missing_alt();
		if ( $no_alt > 0 ) {
			$issues[] = $this->issue(
				'missing_alt',
				self::SEVERITY_WARNING,
				sprintf( '%d image(s) missing alt text', $no_alt ),
				'Alt text helps accessibility and image SEO (JoraPress can generate it).',
				array(
					'evidence'     => array( 'count' => $no_alt ),
					'auto_fixable' => true,
					'fix_tool'     => 'seo_fix',
					'fix_args'     => array( 'action' => 'generate_alt' ),
				)
			);
		}

		// Search engine visibility.
		if ( '0' === (string) get_option( 'blog_public', '1' ) ) {
			$issues[] = $this->issue(
				'noindex_site',
				self::SEVERITY_CRITICAL,
				'Search engines are blocked (Discourage search engines is ON)',
				'Settings → Reading → uncheck "Discourage search engines" once the site is live.',
				array(
					'auto_fixable' => true,
					'fix_tool'     => 'seo_fix',
					'fix_args'     => array( 'action' => 'allow_indexing' ),
				)
			);
		}

		// Sitemap.
		if ( ! $this->sitemap_available() ) {
			$issues[] = $this->issue(
				'sitemap',
				self::SEVERITY_RECOMMENDATION,
				'No XML sitemap detected',
				'Enable the WordPress core sitemap or an SEO plugin sitemap and submit it to search engines.',
				array(
					'auto_fixable' => true,
					'fix_tool'     => 'seo_fix',
					'fix_args'     => array( 'action' => 'enable_sitemap' ),
				)
			);
		}

		return $issues;
	}

	/** Read a post's meta description from Yoast/Rank Math, else its excerpt. */
	private function meta_description( int $post_id ): string {
		foreach ( array( '_yoast_wpseo_metadesc', 'rank_math_description' ) as $key ) {
			$val = (string) get_post_meta( $post_id, $key, true );
			if ( '' !== $val ) {
				return $val;
			}
		}
		$post = get_post( $post_id );
		return $post ? (string) $post->post_excerpt : '';
	}

	private function images_missing_alt(): int {
		global $wpdb;
		// Attachments that are images and have no (or empty) _wp_attachment_image_alt.
		$sql = $wpdb->prepare(
			"SELECT COUNT(p.ID) FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} m ON ( m.post_id = p.ID AND m.meta_key = '_wp_attachment_image_alt' )
			 WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE %s
			 AND ( m.meta_value IS NULL OR m.meta_value = '' )",
			'image/%'
		);
		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB
	}

	private function sitemap_available(): bool {
		// Core sitemaps (5.5+) are on unless filtered/disabled.
		if ( function_exists( 'wp_sitemaps_get_server' ) ) {
			$server = wp_sitemaps_get_server();
			if ( $server && $server->sitemaps_enabled() ) {
				return true;
			}
		}
		// SEO plugins expose their own sitemap routes.
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' );
	}
}
