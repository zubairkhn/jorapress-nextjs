<?php
/**
 * write_file — create or overwrite a file. Files written inside the sandbox
 * dir are tracked & revertable. Writes elsewhere in the install back up the
 * previous version first.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

use JoraPress\Core\Sandbox;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WriteFileTool extends FilesystemTool {

	public function name(): string {
		return 'write_file';
	}

	public function description(): string {
		return 'Write (create or overwrite) a text file. Set "sandbox": true to write into the '
			. 'tracked, revertable JoraPress sandbox directory (recommended for new AI-authored PHP). '
			. 'Otherwise the path is relative to the WordPress install root and the previous version '
			. 'is backed up.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'path'     => array(
					'type'        => 'string',
					'description' => 'Target path. Relative to the sandbox dir when sandbox=true, else to the install root.',
				),
				'contents' => array(
					'type'        => 'string',
					'description' => 'Full file contents to write.',
				),
				'sandbox'  => array(
					'type'        => 'boolean',
					'description' => 'Write into the tracked sandbox dir (default true).',
				),
			),
			'required'   => array( 'path', 'contents' ),
		);
	}

	public function is_write( array $args ): bool {
		return true;
	}

	public function run( array $args ): array {
		$path     = (string) ( $args['path'] ?? '' );
		$contents = (string) ( $args['contents'] ?? '' );
		$sandbox  = (bool) ( $args['sandbox'] ?? true );

		if ( '' === $path ) {
			return array(
				'ok'    => false,
				'error' => 'No path provided.',
			);
		}

		if ( $sandbox ) {
			$res = Sandbox::write( $path, $contents );
			return array(
				'ok'       => true,
				'location' => 'sandbox',
				'rel_path' => $res['rel_path'],
				'bytes'    => $res['bytes'],
				'created'  => $res['created'],
			);
		}

		$abs = $this->resolve( $path );
		wp_mkdir_p( dirname( $abs ) );
		$bytes = file_put_contents( $abs, $contents ); // phpcs:ignore

		return array(
			'ok'       => false !== $bytes,
			'location' => 'install',
			'path'     => $path,
			'bytes'    => false === $bytes ? 0 : $bytes,
		);
	}
}
