<?php
/**
 * site_health — wraps server/WordPress environment checks into the shared issue
 * schema: PHP/MySQL versions, HTTPS, debug flags, loopback cron, REST API,
 * object cache and core update status.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SiteHealthTool extends ScannerTool {

	public function name(): string {
		return 'site_health';
	}

	public function description(): string {
		return 'Audit the WordPress/server environment (PHP & MySQL versions, HTTPS, debug flags, cron, REST API, object cache, core updates) and report issues.';
	}

	protected function domain(): string {
		return 'health';
	}

	protected function scan(): array {
		global $wp_version;
		$issues = array();

		// PHP version.
		if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
			$issues[] = $this->issue(
				'php_version',
				version_compare( PHP_VERSION, '7.4', '<' ) ? self::SEVERITY_CRITICAL : self::SEVERITY_WARNING,
				sprintf( 'PHP %s is outdated', PHP_VERSION ),
				'Ask your host to upgrade to PHP 8.1 or newer for security and performance.',
				array( 'evidence' => array( 'php' => PHP_VERSION ) )
			);
		}

		// Core updates.
		if ( function_exists( 'get_core_updates' ) ) {
			$updates = get_core_updates();
			if ( is_array( $updates ) && ! empty( $updates[0]->response ) && 'latest' !== $updates[0]->response ) {
				$issues[] = $this->issue(
					'core_update',
					self::SEVERITY_WARNING,
					'A WordPress core update is available',
					'Update WordPress core from Dashboard → Updates.',
					array( 'evidence' => array( 'current' => $wp_version ) )
				);
			}
		}

		// Plugin/theme updates.
		$plugin_updates = function_exists( 'get_plugin_updates' ) ? get_plugin_updates() : array();
		if ( ! function_exists( 'get_plugin_updates' ) && file_exists( ABSPATH . 'wp-admin/includes/update.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
			$plugin_updates = get_plugin_updates();
		}
		if ( ! empty( $plugin_updates ) ) {
			$issues[] = $this->issue(
				'plugin_updates',
				self::SEVERITY_WARNING,
				sprintf( '%d plugin update(s) pending', count( $plugin_updates ) ),
				'Update plugins to receive security and bug fixes.',
				array(
					'evidence'     => array( 'plugins' => array_keys( $plugin_updates ) ),
					'auto_fixable' => true,
					'fix_tool'     => 'bug_fix',
					'fix_args'     => array( 'action' => 'update_plugins' ),
				)
			);
		}

		// HTTPS.
		if ( ! is_ssl() && 0 !== strpos( (string) home_url(), 'https://' ) ) {
			$issues[] = $this->issue(
				'https',
				self::SEVERITY_WARNING,
				'Site is not served over HTTPS',
				'Install an SSL certificate and move the site to https:// — required for security and SEO.',
				array( 'evidence' => array( 'home_url' => home_url() ) )
			);
		}

		// WP_DEBUG left on with display.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
			$issues[] = $this->issue(
				'debug_display',
				self::SEVERITY_WARNING,
				'WP_DEBUG_DISPLAY is on (errors shown to visitors)',
				'Set WP_DEBUG_DISPLAY to false in wp-config.php; log to file instead.',
				array()
			);
		}

		// Object cache.
		if ( ! wp_using_ext_object_cache() ) {
			$issues[] = $this->issue(
				'object_cache',
				self::SEVERITY_RECOMMENDATION,
				'No persistent object cache detected',
				'Add Redis or Memcached with a drop-in for faster repeated queries.',
				array()
			);
		}

		// Cron.
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON && ! $this->has_real_cron() ) {
			$issues[] = $this->issue(
				'cron_disabled',
				self::SEVERITY_WARNING,
				'WP-Cron is disabled and no system cron is evident',
				'Add a real system cron hitting wp-cron.php, or re-enable WP-Cron.',
				array()
			);
		}

		// REST API reachability (basic).
		if ( ! function_exists( 'rest_url' ) || '' === rest_url() ) {
			$issues[] = $this->issue(
				'rest_api',
				self::SEVERITY_CRITICAL,
				'REST API is unavailable',
				'The REST API is required by the block editor and JoraPress. Check security plugins/firewall.',
				array()
			);
		}

		return $issues;
	}

	private function has_real_cron(): bool {
		// Best-effort: presence of a recent cron run option suggests it's firing.
		$crons = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
		return is_array( $crons ) && ! empty( $crons );
	}
}
