<?php
/**
 * read_file — read a file from the WordPress install (theme/plugin source,
 * config, etc.) so the AI can learn the stack before changing it.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ReadFileTool extends FilesystemTool {

	public function name(): string {
		return 'read_file';
	}

	public function description(): string {
		return 'Read a UTF-8 text file relative to the WordPress install root. Returns up to ~200KB.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'path'       => array(
					'type'        => 'string',
					'description' => 'Path relative to the WordPress install root, e.g. wp-content/themes/foo/functions.php',
				),
				'max_bytes'  => array(
					'type'        => 'integer',
					'description' => 'Maximum bytes to read (default 200000).',
				),
			),
			'required'   => array( 'path' ),
		);
	}

	public function run( array $args ): array {
		$abs = $this->resolve( (string) ( $args['path'] ?? '' ) );
		if ( ! is_file( $abs ) ) {
			return array(
				'ok'    => false,
				'error' => 'File not found.',
			);
		}
		$max      = (int) ( $args['max_bytes'] ?? 200000 );
		$max      = max( 1, min( 2000000, $max ) );
		$contents = file_get_contents( $abs, false, null, 0, $max ); // phpcs:ignore

		return array(
			'ok'        => true,
			'path'      => $args['path'],
			'bytes'     => filesize( $abs ),
			'truncated' => filesize( $abs ) > $max,
			'contents'  => false === $contents ? '' : $contents,
		);
	}
}
