<?php
/**
 * bug_fix — remediates bug/error findings: update plugins with pending updates,
 * or deactivate a plugin that is throwing fatals. Deactivation is reversible
 * (the plugin can be reactivated from Plugins) and the active-plugins list is
 * snapshotted first.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

use JoraPress\Core\Backup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BugFixTool extends FixerTool {

	public function name(): string {
		return 'bug_fix';
	}

	public function description(): string {
		return 'Fix bug/error findings: update plugins that have pending updates, or deactivate a plugin throwing fatal errors. Supports dry_run.';
	}

	protected function actions(): array {
		return array(
			'update_plugins'     => 'Update all plugins with pending updates',
			'deactivate_plugin'  => 'Deactivate a plugin (by folder name) that is causing fatals',
		);
	}

	protected function apply( string $action, array $args, bool $dry_run ): array {
		return match ( $action ) {
			'update_plugins'    => $this->update_plugins( $dry_run ),
			'deactivate_plugin' => $this->deactivate_plugin( $args, $dry_run ),
			default             => array( 'detail' => 'No-op.' ),
		};
	}

	private function update_plugins( bool $dry_run ): array {
		if ( ! function_exists( 'get_plugin_updates' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}
		$updates = get_plugin_updates();
		$slugs   = array_keys( $updates );

		if ( empty( $slugs ) ) {
			return array( 'changed' => 0, 'detail' => 'No plugin updates pending.' );
		}

		if ( $dry_run ) {
			return array(
				'changed' => 0,
				'detail'  => sprintf( 'Would update %d plugin(s): %s', count( $slugs ), implode( ', ', $slugs ) ),
				'plan'    => $slugs,
			);
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		$skin     = new \Automatic_Upgrader_Skin();
		$upgrader = new \Plugin_Upgrader( $skin );
		$results  = $upgrader->bulk_upgrade( $slugs );

		$ok = is_array( $results ) ? count( array_filter( $results ) ) : 0;
		return array(
			'changed' => $ok,
			'detail'  => sprintf( 'Updated %d of %d plugin(s).', $ok, count( $slugs ) ),
		);
	}

	private function deactivate_plugin( array $args, bool $dry_run ): array {
		$target = (string) ( $args['plugin'] ?? '' );
		// Accept "plugin: folder" (as the scanner reports) or a raw folder/file.
		$target = trim( (string) preg_replace( '/^plugin:\s*/i', '', $target ) );
		if ( '' === $target ) {
			return array( 'changed' => 0, 'detail' => 'No plugin specified.' );
		}

		$file = $this->resolve_plugin_file( $target );
		if ( null === $file ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Plugin "%s" not found among active plugins.', $target ) );
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would deactivate %s.', $file ), 'plan' => $file );
		}

		// Snapshot the active-plugins list so the change is auditable/revertible.
		Backup::snapshot_rows( $GLOBALS['wpdb']->options, "option_name = 'active_plugins'" );

		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		deactivate_plugins( $file, true );

		return array( 'changed' => 1, 'detail' => sprintf( 'Deactivated %s.', $file ) );
	}

	private function resolve_plugin_file( string $folder ): ?string {
		$active = (array) get_option( 'active_plugins', array() );
		foreach ( $active as $plugin_file ) {
			if ( 0 === strpos( (string) $plugin_file, $folder . '/' ) || $plugin_file === $folder ) {
				return (string) $plugin_file;
			}
		}
		return null;
	}
}
