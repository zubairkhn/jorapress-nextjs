<?php
/**
 * Contract every Execution Core tool implements. Tools are the "primitives"
 * the AI composes — kept small and powerful rather than many narrow wrappers.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface ToolInterface {

	/** Machine name, e.g. "execute_php". */
	public function name(): string;

	/** Human/AI-facing description. */
	public function description(): string;

	/**
	 * JSON Schema for the tool's arguments (MCP tools/list `inputSchema`).
	 *
	 * @return array<string,mixed>
	 */
	public function input_schema(): array;

	/**
	 * Does this specific invocation perform a write? Used by the safety layer
	 * to apply read-before-write gating.
	 *
	 * @param array<string,mixed> $args
	 */
	public function is_write( array $args ): bool;

	/**
	 * Execute the tool.
	 *
	 * @param array<string,mixed> $args
	 * @return array<string,mixed> Structured result.
	 */
	public function run( array $args ): array;
}
