<?php
/**
 * execute_php — the master key. Evaluates arbitrary PHP inside the WP runtime
 * so the AI can call any core/plugin/theme API (including every page builder's)
 * without per-builder code. Always wrapped by the crash guard.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

use JoraPress\Core\CrashGuard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ExecutePhpTool implements ToolInterface {

	public function name(): string {
		return 'execute_php';
	}

	public function description(): string {
		return 'Evaluate PHP code inside the live WordPress runtime and return its output. '
			. 'Use `return` or echo to produce a result. WordPress, all active plugins and theme '
			. 'functions are available (e.g. get_post(), update_post_meta(), Elementor/Bricks APIs). '
			. 'Wrapped in a crash guard so fatals are caught and returned as errors.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'code' => array(
					'type'        => 'string',
					'description' => 'PHP code to run. Do NOT include opening <?php tags. Use return/echo for output.',
				),
			),
			'required'   => array( 'code' ),
		);
	}

	/**
	 * execute_php can do anything, so it is always treated as a write for
	 * gating purposes. The agent should prefer db_query/read_file for reads.
	 */
	public function is_write( array $args ): bool {
		return true;
	}

	public function run( array $args ): array {
		$code = isset( $args['code'] ) ? (string) $args['code'] : '';
		if ( '' === trim( $code ) ) {
			return array(
				'ok'    => false,
				'error' => 'No code provided.',
			);
		}

		// Strip an accidental leading <?php.
		$code = preg_replace( '/^\s*<\?php/i', '', $code, 1 ) ?? $code;

		$result = CrashGuard::run_guarded(
			static function () use ( $code ) {
				// phpcs:ignore Squiz.PHP.Eval.Discouraged -- arbitrary execution is the documented feature.
				return eval( $code );
			}
		);

		return array(
			'ok'     => $result['ok'],
			'output' => $result['output'],
			'error'  => $result['error'],
		);
	}
}
