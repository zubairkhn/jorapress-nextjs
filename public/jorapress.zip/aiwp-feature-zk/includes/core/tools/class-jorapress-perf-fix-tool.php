<?php
/**
 * perf_fix — remediates performance findings: trim autoloaded options, delete
 * old post revisions, purge expired transients. Every destructive action
 * snapshots the affected rows first so it can be rolled back. Image optimization
 * is delegated to a filter hook so a host can plug in its own optimizer.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

use JoraPress\Core\Backup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PerfFixTool extends FixerTool {

	/** Options above this size are candidates to stop autoloading. */
	private const AUTOLOAD_THRESHOLD = 102400; // 100 KB.

	public function name(): string {
		return 'perf_fix';
	}

	public function description(): string {
		return 'Fix performance findings: stop autoloading bloated options, delete old post revisions, purge expired transients, optimize images. Supports dry_run.';
	}

	protected function actions(): array {
		return array(
			'trim_autoload'   => 'Stop autoloading options larger than 100 KB',
			'clean_revisions' => 'Delete post revisions beyond the most recent 5 per post',
			'clean_transients'=> 'Delete expired transients',
			'optimize_images' => 'Optimize oversized images (via host optimizer hook)',
		);
	}

	protected function apply( string $action, array $args, bool $dry_run ): array {
		return match ( $action ) {
			'trim_autoload'    => $this->trim_autoload( $dry_run ),
			'clean_revisions'  => $this->clean_revisions( $args, $dry_run ),
			'clean_transients' => $this->clean_transients( $dry_run ),
			'optimize_images'  => $this->optimize_images( $dry_run ),
			default            => array( 'detail' => 'No-op.' ),
		};
	}

	private function trim_autoload( bool $dry_run ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT option_name, LENGTH(option_value) AS len FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto-on','auto') AND LENGTH(option_value) > %d ORDER BY len DESC", self::AUTOLOAD_THRESHOLD ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$names = wp_list_pluck( (array) $rows, 'option_name' );

		if ( empty( $names ) ) {
			return array( 'changed' => 0, 'detail' => 'No oversized autoloaded options found.' );
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would stop autoloading %d option(s).', count( $names ) ), 'plan' => $names );
		}

		Backup::snapshot_rows( $wpdb->options, "autoload IN ('yes','on','auto-on','auto') AND LENGTH(option_value) > " . self::AUTOLOAD_THRESHOLD );

		$changed = 0;
		foreach ( $names as $name ) {
			// Toggle autoload off without altering the value: re-set with autoload=no.
			$value = get_option( $name );
			if ( delete_option( $name ) && add_option( $name, $value, '', 'no' ) ) {
				++$changed;
			}
		}
		return array( 'changed' => $changed, 'detail' => sprintf( 'Stopped autoloading %d option(s).', $changed ) );
	}

	private function clean_revisions( array $args, bool $dry_run ): array {
		global $wpdb;
		$keep = max( 0, (int) ( $args['keep'] ?? 5 ) );

		// Revisions to delete: all but the newest $keep per parent.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT r.ID FROM {$wpdb->posts} r
				 WHERE r.post_type = 'revision'
				 AND r.ID NOT IN (
					SELECT keep_id FROM (
						SELECT ID AS keep_id,
						ROW_NUMBER() OVER ( PARTITION BY post_parent ORDER BY post_date DESC ) AS rn
						FROM {$wpdb->posts} WHERE post_type = 'revision'
					) ranked WHERE ranked.rn <= %d
				 )",
				$keep
			)
		); // phpcs:ignore WordPress.DB

		$ids = array_map( 'intval', (array) $ids );
		if ( empty( $ids ) ) {
			return array( 'changed' => 0, 'detail' => 'No surplus revisions to delete.' );
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would delete %d revision(s), keeping %d per post.', count( $ids ), $keep ), 'plan' => count( $ids ) );
		}

		Backup::snapshot_rows( $wpdb->posts, "post_type = 'revision'" );

		$changed = 0;
		foreach ( $ids as $id ) {
			if ( wp_delete_post_revision( $id ) ) {
				++$changed;
			}
		}
		return array( 'changed' => $changed, 'detail' => sprintf( 'Deleted %d revision(s).', $changed ) );
	}

	private function clean_transients( bool $dry_run ): array {
		global $wpdb;
		$now = time();

		$timeouts = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d", $wpdb->esc_like( '_transient_timeout_' ) . '%', $now ) ); // phpcs:ignore WordPress.DB

		if ( empty( $timeouts ) ) {
			return array( 'changed' => 0, 'detail' => 'No expired transients.' );
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would delete %d expired transient(s).', count( $timeouts ) ), 'plan' => count( $timeouts ) );
		}

		$changed = 0;
		foreach ( $timeouts as $timeout_name ) {
			$name = substr( (string) $timeout_name, strlen( '_transient_timeout_' ) );
			if ( delete_transient( $name ) ) {
				++$changed;
			}
		}
		return array( 'changed' => $changed, 'detail' => sprintf( 'Deleted %d expired transient(s).', $changed ) );
	}

	/**
	 * Image optimization is intentionally delegated: hosts/plugins implement the
	 * actual compression via the `jorapress_optimize_image` filter (returns true on
	 * success). Without a handler this reports that no optimizer is wired.
	 */
	private function optimize_images( bool $dry_run ): array {
		if ( ! has_filter( 'jorapress_optimize_image' ) ) {
			return array( 'changed' => 0, 'detail' => 'No image optimizer is wired (add an jorapress_optimize_image filter or an optimization plugin).' );
		}

		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => 'image',
				'fields'         => 'ids',
				'posts_per_page' => 100,
				'no_found_rows'  => true,
			)
		);

		$targets = array();
		foreach ( $ids as $id ) {
			$file = get_attached_file( (int) $id );
			if ( $file && is_file( $file ) && filesize( $file ) > 1048576 ) {
				$targets[] = (int) $id;
			}
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would optimize %d image(s).', count( $targets ) ), 'plan' => count( $targets ) );
		}

		$changed = 0;
		foreach ( $targets as $id ) {
			if ( true === apply_filters( 'jorapress_optimize_image', false, $id ) ) {
				++$changed;
			}
		}
		return array( 'changed' => $changed, 'detail' => sprintf( 'Optimized %d image(s).', $changed ) );
	}
}
