<?php
/**
 * perf_scan — performance audit: autoloaded-options bloat, post-revision and
 * transient buildup, oversized images, object cache presence and large DB
 * tables. Read-only; each finding points at the matching perf_fix action.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PerfScanTool extends ScannerTool {

	public function name(): string {
		return 'perf_scan';
	}

	public function description(): string {
		return 'Audit performance: autoloaded options bloat, post revisions, expired transients, oversized images, missing object cache and large database tables.';
	}

	protected function domain(): string {
		return 'performance';
	}

	protected function scan(): array {
		global $wpdb;
		$issues = array();

		// Autoloaded options size.
		$autoload_bytes = (int) $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto-on','auto')" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $autoload_bytes > 1048576 ) { // > 1 MB.
			$top = $wpdb->get_results( "SELECT option_name, LENGTH(option_value) AS len FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto-on','auto') ORDER BY len DESC LIMIT 10", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$issues[] = $this->issue(
				'autoload_bloat',
				$autoload_bytes > 3145728 ? self::SEVERITY_WARNING : self::SEVERITY_RECOMMENDATION,
				sprintf( 'Autoloaded options are %s', size_format( $autoload_bytes ) ),
				'Large autoloaded options load on every request. Stop autoloading the heaviest non-essential ones.',
				array(
					'evidence'     => array( 'bytes' => $autoload_bytes, 'top' => $top ),
					'auto_fixable' => true,
					'fix_tool'     => 'perf_fix',
					'fix_args'     => array( 'action' => 'trim_autoload' ),
				)
			);
		}

		// Post revisions.
		$revisions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $revisions > 200 ) {
			$issues[] = $this->issue(
				'revisions',
				self::SEVERITY_RECOMMENDATION,
				sprintf( '%d post revisions stored', $revisions ),
				'Old revisions bloat the database. Clean them up and cap WP_POST_REVISIONS.',
				array(
					'evidence'     => array( 'count' => $revisions ),
					'auto_fixable' => true,
					'fix_tool'     => 'perf_fix',
					'fix_args'     => array( 'action' => 'clean_revisions' ),
				)
			);
		}

		// Expired transients.
		$expired = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d", $wpdb->esc_like( '_transient_timeout_' ) . '%', time() ) ); // phpcs:ignore WordPress.DB
		if ( $expired > 50 ) {
			$issues[] = $this->issue(
				'expired_transients',
				self::SEVERITY_RECOMMENDATION,
				sprintf( '%d expired transients in the database', $expired ),
				'Delete expired transients to shrink the options table.',
				array(
					'evidence'     => array( 'count' => $expired ),
					'auto_fixable' => true,
					'fix_tool'     => 'perf_fix',
					'fix_args'     => array( 'action' => 'clean_transients' ),
				)
			);
		}

		// Object cache.
		if ( ! wp_using_ext_object_cache() ) {
			$issues[] = $this->issue(
				'no_object_cache',
				self::SEVERITY_RECOMMENDATION,
				'No persistent object cache',
				'A Redis/Memcached object cache dramatically cuts repeated query cost.',
				array()
			);
		}

		// Oversized images in the media library.
		$big_images = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE %s", 'image/%' ) ); // phpcs:ignore WordPress.DB
		$oversized  = $this->count_oversized_images();
		if ( $oversized > 0 ) {
			$issues[] = $this->issue(
				'oversized_images',
				self::SEVERITY_RECOMMENDATION,
				sprintf( '%d image(s) larger than 1 MB', $oversized ),
				'Compress/resize large images (or serve WebP) to speed up page loads.',
				array(
					'evidence'     => array( 'oversized' => $oversized, 'total_images' => $big_images ),
					'auto_fixable' => false,
					'fix_tool'     => 'perf_fix',
					'fix_args'     => array( 'action' => 'optimize_images' ),
				)
			);
		}

		return $issues;
	}

	/** Count attachment images whose original file exceeds 1 MB (capped scan). */
	private function count_oversized_images(): int {
		$query = new \WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => 'image',
				'fields'         => 'ids',
				'posts_per_page' => 200,
				'no_found_rows'  => true,
			)
		);

		$count = 0;
		foreach ( $query->posts as $id ) {
			$file = get_attached_file( (int) $id );
			if ( $file && is_file( $file ) && filesize( $file ) > 1048576 ) {
				++$count;
			}
		}
		return $count;
	}
}
