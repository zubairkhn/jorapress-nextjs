<?php
/**
 * seo_fix — remediates SEO findings: generate missing meta descriptions and
 * image alt text, allow search engine indexing, and force-enable the core XML
 * sitemap. Content generation runs through the `jorapress_seo_generate_text` filter
 * (so an AI provider can supply copy) with a deterministic heuristic fallback.
 * Posts are snapshotted before their meta is changed.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core\Tools;

use JoraPress\Core\Backup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SeoFixTool extends FixerTool {

	private const META_LIMIT = 50; // Cap writes per run.

	public function name(): string {
		return 'seo_fix';
	}

	public function description(): string {
		return 'Fix SEO findings: generate missing meta descriptions and image alt text, allow search-engine indexing, enable the XML sitemap. Supports dry_run.';
	}

	protected function actions(): array {
		return array(
			'generate_meta'   => 'Generate meta descriptions for pages missing one',
			'generate_alt'    => 'Generate alt text for images missing it',
			'allow_indexing'  => 'Allow search engines to index the site',
			'enable_sitemap'  => 'Force-enable the core XML sitemap',
		);
	}

	protected function apply( string $action, array $args, bool $dry_run ): array {
		return match ( $action ) {
			'generate_meta'  => $this->generate_meta( $args, $dry_run ),
			'generate_alt'   => $this->generate_alt( $args, $dry_run ),
			'allow_indexing' => $this->allow_indexing( $dry_run ),
			'enable_sitemap' => $this->enable_sitemap( $dry_run ),
			default          => array( 'detail' => 'No-op.' ),
		};
	}

	private function generate_meta( array $args, bool $dry_run ): array {
		$ids = array_map( 'intval', (array) ( $args['post_ids'] ?? array() ) );
		if ( empty( $ids ) ) {
			// Fall back to scanning for any published post/page without a description.
			$ids = get_posts(
				array(
					'post_type'      => array( 'post', 'page' ),
					'post_status'    => 'publish',
					'posts_per_page' => self::META_LIMIT,
					'fields'         => 'ids',
					'no_found_rows'  => true,
				)
			);
		}
		$ids = array_slice( $ids, 0, self::META_LIMIT );

		$key     = $this->seo_meta_key();
		$changed = 0;
		$plan    = array();

		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post ) {
				continue;
			}
			// Skip if it already has one (unless caller forces).
			if ( '' !== (string) get_post_meta( $id, $key, true ) && empty( $args['overwrite'] ) ) {
				continue;
			}

			$desc = $this->generate_text( 'meta_description', $post );
			if ( '' === $desc ) {
				continue;
			}

			if ( $dry_run ) {
				$plan[] = array( 'id' => $id, 'preview' => $desc );
				continue;
			}

			Backup::snapshot_post( (int) $id );
			update_post_meta( $id, $key, $desc );
			++$changed;
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would write %d meta description(s).', count( $plan ) ), 'plan' => $plan );
		}
		return array( 'changed' => $changed, 'detail' => sprintf( 'Wrote %d meta description(s) to "%s".', $changed, $key ) );
	}

	private function generate_alt( array $args, bool $dry_run ): array {
		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				 LEFT JOIN {$wpdb->postmeta} m ON ( m.post_id = p.ID AND m.meta_key = '_wp_attachment_image_alt' )
				 WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE %s
				 AND ( m.meta_value IS NULL OR m.meta_value = '' )
				 LIMIT %d",
				'image/%',
				self::META_LIMIT
			)
		); // phpcs:ignore WordPress.DB

		$ids = array_map( 'intval', (array) $ids );
		if ( empty( $ids ) ) {
			return array( 'changed' => 0, 'detail' => 'No images missing alt text.' );
		}

		$changed = 0;
		$plan    = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			$alt  = $this->generate_text( 'alt_text', $post );
			if ( '' === $alt ) {
				continue;
			}
			if ( $dry_run ) {
				$plan[] = array( 'id' => $id, 'preview' => $alt );
				continue;
			}
			update_post_meta( $id, '_wp_attachment_image_alt', $alt );
			++$changed;
		}

		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => sprintf( 'Would write alt text for %d image(s).', count( $plan ) ), 'plan' => $plan );
		}
		return array( 'changed' => $changed, 'detail' => sprintf( 'Wrote alt text for %d image(s).', $changed ) );
	}

	private function allow_indexing( bool $dry_run ): array {
		if ( '1' === (string) get_option( 'blog_public', '1' ) ) {
			return array( 'changed' => 0, 'detail' => 'Indexing is already allowed.' );
		}
		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => 'Would set blog_public = 1 (allow indexing).' );
		}
		update_option( 'blog_public', '1' );
		return array( 'changed' => 1, 'detail' => 'Search engines are now allowed to index the site.' );
	}

	private function enable_sitemap( bool $dry_run ): array {
		if ( $dry_run ) {
			return array( 'changed' => 0, 'detail' => 'Would force-enable the core XML sitemap.' );
		}
		// Picked up by the jorapress_force_core_sitemap filter wired in Plugin::boot().
		update_option( 'jorapress_force_core_sitemap', 1 );
		if ( function_exists( 'flush_rewrite_rules' ) ) {
			flush_rewrite_rules( false );
		}
		return array( 'changed' => 1, 'detail' => 'Core XML sitemap force-enabled at /wp-sitemap.xml.' );
	}

	/**
	 * Produce SEO copy. Lets an AI provider answer via the filter; otherwise uses
	 * a deterministic heuristic so the feature works with no API key.
	 *
	 * @param \WP_Post|null $post
	 */
	private function generate_text( string $kind, $post ): string {
		$fallback = '';

		if ( $post instanceof \WP_Post ) {
			if ( 'meta_description' === $kind ) {
				$source   = $post->post_excerpt ? $post->post_excerpt : wp_strip_all_tags( (string) $post->post_content );
				$fallback = $this->truncate_words( $source, 155 );
			} elseif ( 'alt_text' === $kind ) {
				$title    = get_the_title( $post );
				$fallback = $title ? $title : $this->humanize_filename( get_post_meta( $post->ID, '_wp_attached_file', true ) );
			}
		}

		/**
		 * Filter SEO copy before the heuristic fallback. Return a non-empty string
		 * (e.g. from an AI provider) to override.
		 *
		 * @param string       $text Default heuristic text.
		 * @param string       $kind 'meta_description' | 'alt_text'.
		 * @param \WP_Post|null $post
		 */
		$text = (string) apply_filters( 'jorapress_seo_generate_text', $fallback, $kind, $post );

		return trim( $text );
	}

	private function seo_meta_key(): string {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return '_yoast_wpseo_metadesc';
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			return 'rank_math_description';
		}
		// No SEO plugin: store on a neutral key the scanner also reads is not
		// possible, so use the post excerpt-compatible Yoast key as a de-facto
		// standard most themes/plugins can later import.
		return '_yoast_wpseo_metadesc';
	}

	private function truncate_words( string $text, int $max_chars ): string {
		$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $text ) ) ?? '' );
		if ( strlen( $text ) <= $max_chars ) {
			return $text;
		}
		$cut = substr( $text, 0, $max_chars );
		$cut = substr( $cut, 0, (int) strrpos( $cut, ' ' ) );
		return rtrim( $cut, " ,.;:" ) . '…';
	}

	private function humanize_filename( $relpath ): string {
		$name = pathinfo( (string) $relpath, PATHINFO_FILENAME );
		$name = (string) preg_replace( '/[-_]+/', ' ', $name );
		$name = (string) preg_replace( '/\d+/', '', $name );
		return ucfirst( trim( $name ) );
	}
}
