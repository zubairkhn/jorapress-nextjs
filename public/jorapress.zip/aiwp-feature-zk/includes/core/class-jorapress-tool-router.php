<?php
/**
 * Tool router — the single chokepoint every tool call passes through,
 * regardless of front door (MCP or chat panel). Applies the safety preflight,
 * runs the tool, logs to the audit trail.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

use JoraPress\Core\Tools\ToolInterface;
use JoraPress\Core\Tools\ExecutePhpTool;
use JoraPress\Core\Tools\DbQueryTool;
use JoraPress\Core\Tools\ReadFileTool;
use JoraPress\Core\Tools\WriteFileTool;
use JoraPress\Core\Tools\EditFileTool;
use JoraPress\Core\Tools\ListDirTool;
use JoraPress\Core\Tools\WpCliTool;
use JoraPress\Core\Tools\WpRestTool;
use JoraPress\Core\Tools\SiteHealthTool;
use JoraPress\Core\Tools\ErrorScanTool;
use JoraPress\Core\Tools\PerfScanTool;
use JoraPress\Core\Tools\SeoScanTool;
use JoraPress\Core\Tools\BugFixTool;
use JoraPress\Core\Tools\PerfFixTool;
use JoraPress\Core\Tools\SeoFixTool;
use JoraPress\Licensing\License;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ToolRouter {

	/**
	 * Tools that require a paid (Pro/Agency) license. The automated fixers are
	 * the headline Pro feature; the read-only scanners stay free.
	 */
	private const PRO_TOOLS = array( 'bug_fix', 'perf_fix', 'seo_fix' );

	/** @var array<string,ToolInterface> */
	private array $tools = array();

	public function __construct(
		private Safety $safety,
		private AuditLog $audit
	) {}

	public function register_default_tools(): void {
		$defaults = array(
			new ExecutePhpTool(),
			new DbQueryTool(),
			new ReadFileTool(),
			new WriteFileTool(),
			new EditFileTool(),
			new ListDirTool(),
			new WpCliTool(),
			new WpRestTool(),
			// Doctor scanners (read-only diagnostics).
			new SiteHealthTool(),
			new ErrorScanTool(),
			new PerfScanTool(),
			new SeoScanTool(),
			// Doctor fixers (gated, snapshotted, dry_run-capable).
			new BugFixTool(),
			new PerfFixTool(),
			new SeoFixTool(),
		);

		foreach ( $defaults as $tool ) {
			$this->register( $tool );
		}

		// Allow add-ons / Pro packs to register more tools.
		do_action( 'jorapress_register_tools', $this );
	}

	public function register( ToolInterface $tool ): void {
		$this->tools[ $tool->name() ] = $tool;
	}

	public function has( string $name ): bool {
		return isset( $this->tools[ $name ] );
	}

	/** Whether a tool requires a paid license. */
	public static function is_pro_tool( string $name ): bool {
		return in_array( $name, self::PRO_TOOLS, true );
	}

	/**
	 * @return array<string,ToolInterface>
	 */
	public function all(): array {
		return $this->tools;
	}

	/**
	 * MCP-style tool descriptors for tools/list.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function descriptors(): array {
		$out = array();
		foreach ( $this->tools as $tool ) {
			// Respect capability gating in descriptors.
			if ( 'wp_cli' === $tool->name() && ! $this->safety->wp_cli_allowed() ) {
				continue;
			}
			// Don't advertise Pro fixers to an unlicensed site.
			if ( self::is_pro_tool( $tool->name() ) && ! License::is_pro() ) {
				continue;
			}
			$out[] = array(
				'name'        => $tool->name(),
				'description' => $tool->description(),
				'inputSchema' => $tool->input_schema(),
			);
		}
		return $out;
	}

	/**
	 * Execute a tool by name. Runs safety preflight + audit logging.
	 *
	 * @param array<string,mixed> $args
	 * @return array<string,mixed>
	 * @throws SafetyException
	 */
	public function call( string $name, array $args, string $front_door = 'mcp' ): array {
		if ( ! $this->has( $name ) ) {
			throw new SafetyException( sprintf( 'Unknown tool: %s', $name ), 404 );
		}

		$tool = $this->tools[ $name ];

		if ( 'wp_cli' === $name && ! $this->safety->wp_cli_allowed() ) {
			throw new SafetyException( 'The wp_cli tool is disabled in settings.', 423 );
		}

		if ( self::is_pro_tool( $name ) && ! License::is_pro() ) {
			throw new SafetyException(
				sprintf(
					/* translators: %s: tool name */
					'%s is a Pro feature. Add your license key in JoraPress → Settings to unlock the automated fixers.',
					$name
				),
				402
			);
		}

		$is_write = $tool->is_write( $args );

		// Safety gate (master switch, capability, production guard, write gate,
		// rate limit). Throws on violation.
		$this->safety->preflight( $name, $is_write );

		try {
			$result = $tool->run( $args );
			$status = ( $result['ok'] ?? true ) ? 'ok' : 'tool_error';
			$this->audit->record( $name, $args, $this->summarise( $result ), $status, $front_door );
			return $result;
		} catch ( \Throwable $e ) {
			$this->audit->record( $name, $args, $e->getMessage(), 'exception', $front_door );
			return array(
				'ok'    => false,
				'error' => $e->getMessage(),
			);
		}
	}

	private function summarise( array $result ): string {
		$copy = $result;
		if ( isset( $copy['rows'] ) && is_array( $copy['rows'] ) ) {
			$copy['rows'] = sprintf( '[%d rows]', count( $copy['rows'] ) );
		}
		if ( isset( $copy['contents'] ) ) {
			$copy['contents'] = sprintf( '[%d chars]', strlen( (string) $copy['contents'] ) );
		}
		return (string) wp_json_encode( $copy );
	}
}
