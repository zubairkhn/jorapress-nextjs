<?php
/**
 * Secrets handling. Encrypts API keys at rest using libsodium when available,
 * falling back to OpenSSL. The encryption key is derived from WP salts so it
 * never lives in the database alongside the ciphertext.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Crypto {

	/**
	 * 32-byte key derived from WP auth salts.
	 */
	private static function key(): string {
		$material = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' )
			. ( defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '' )
			. ( defined( 'LOGGED_IN_KEY' ) ? LOGGED_IN_KEY : '' );

		if ( '' === $material ) {
			$material = wp_salt( 'auth' );
		}

		return hash( 'sha256', 'jorapress|' . $material, true );
	}

	public static function encrypt( string $plaintext ): string {
		if ( '' === $plaintext ) {
			return '';
		}

		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = sodium_crypto_secretbox( $plaintext, $nonce, self::key() );
			return 'sodium:' . base64_encode( $nonce . $cipher );
		}

		// OpenSSL fallback.
		$iv     = random_bytes( 16 );
		$cipher = openssl_encrypt( $plaintext, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
		return 'ossl:' . base64_encode( $iv . $cipher );
	}

	public static function decrypt( string $payload ): string {
		if ( '' === $payload ) {
			return '';
		}

		if ( str_starts_with( $payload, 'sodium:' ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$raw   = base64_decode( substr( $payload, 7 ), true );
			if ( false === $raw ) {
				return '';
			}
			$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$ct    = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$plain = sodium_crypto_secretbox_open( $ct, $nonce, self::key() );
			return false === $plain ? '' : $plain;
		}

		if ( str_starts_with( $payload, 'ossl:' ) ) {
			$raw = base64_decode( substr( $payload, 5 ), true );
			if ( false === $raw ) {
				return '';
			}
			$iv    = substr( $raw, 0, 16 );
			$ct    = substr( $raw, 16 );
			$plain = openssl_decrypt( $ct, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
			return false === $plain ? '' : $plain;
		}

		return '';
	}
}
