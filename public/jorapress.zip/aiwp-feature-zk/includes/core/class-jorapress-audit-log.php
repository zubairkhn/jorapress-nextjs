<?php
/**
 * Append-only audit log. Records every tool call for safety + support.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AuditLog {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jorapress_audit_log';
	}

	/**
	 * Record a tool call.
	 *
	 * @param string $front_door 'mcp' or 'chat'.
	 * @param array  $args       Tool arguments (sensitive values should be redacted by the caller).
	 */
	public function record( string $tool, array $args, string $result_summary, string $status = 'ok', string $front_door = 'mcp' ): int {
		global $wpdb;

		$wpdb->insert(
			$this->table,
			array(
				'created_at'     => current_time( 'mysql', true ),
				'user_id'        => get_current_user_id(),
				'front_door'     => $front_door,
				'tool'           => $tool,
				'args'           => wp_json_encode( $this->truncate_args( $args ) ),
				'result_summary' => mb_substr( $result_summary, 0, 20000 ),
				'status'         => $status,
				'ip'             => $this->client_ip(),
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * @return array<int,object>
	 */
	public function recent( int $limit = 100, int $offset = 0 ): array {
		global $wpdb;
		$limit  = max( 1, min( 500, $limit ) );
		$offset = max( 0, $offset );

		return (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit,
				$offset
			)
		);
	}

	public function export_csv(): string {
		$rows = $this->recent( 500 );
		$out  = "id,created_at,user_id,front_door,tool,status,ip\n";
		foreach ( $rows as $r ) {
			$out .= sprintf(
				"%d,%s,%d,%s,%s,%s,%s\n",
				$r->id,
				$r->created_at,
				$r->user_id,
				$r->front_door,
				$r->tool,
				$r->status,
				$r->ip
			);
		}
		return $out;
	}

	private function truncate_args( array $args ): array {
		array_walk_recursive(
			$args,
			static function ( &$value ): void {
				if ( is_string( $value ) && strlen( $value ) > 8000 ) {
					$value = substr( $value, 0, 8000 ) . '…[truncated]';
				}
			}
		);
		return $args;
	}

	private function client_ip(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( $ip, 0, 64 );
	}
}
