<?php
/**
 * Crash guard. A fatal error in AI-loaded code must never white-screen the
 * site. We register a shutdown handler that records the last-loaded sandbox
 * file, and auto-disables any file that fataled on the previous request.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CrashGuard {

	private static ?string $current_file = null;

	public static function register(): void {
		register_shutdown_function( array( __CLASS__, 'on_shutdown' ) );
	}

	/**
	 * Mark which sandbox file is about to run, so the shutdown handler knows
	 * what to blame on a fatal.
	 */
	public static function guard_file( string $rel_path ): void {
		self::$current_file = $rel_path;
		update_option( 'jorapress_crashguard_pending', $rel_path, false );
	}

	public static function clear(): void {
		self::$current_file = null;
		delete_option( 'jorapress_crashguard_pending' );
	}

	/**
	 * Run arbitrary AI PHP inside a try/catch that converts ANY Throwable into
	 * a structured error instead of a fatal. Returns [ok, output, error].
	 *
	 * @return array{ok:bool,output:string,error:?string}
	 */
	public static function run_guarded( callable $fn ): array {
		ob_start();
		try {
			$return = $fn();
			$output = (string) ob_get_clean();
			if ( null !== $return && '' === $output ) {
				$output = is_scalar( $return ) ? (string) $return : wp_json_encode( $return );
			}
			return array(
				'ok'     => true,
				'output' => (string) $output,
				'error'  => null,
			);
		} catch ( \Throwable $e ) {
			if ( ob_get_level() > 0 ) {
				ob_end_clean();
			}
			return array(
				'ok'     => false,
				'output' => '',
				'error'  => sprintf( '%s: %s in %s:%d', get_class( $e ), $e->getMessage(), $e->getFile(), $e->getLine() ),
			);
		}
	}

	/**
	 * Shutdown handler — if a true fatal slipped through, blame and disable the
	 * pending sandbox file so it won't load again.
	 */
	public static function on_shutdown(): void {
		$error = error_get_last();
		if ( null === $error ) {
			return;
		}

		$fatal_types = E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR;
		if ( ! ( $error['type'] & $fatal_types ) ) {
			return;
		}

		$pending = get_option( 'jorapress_crashguard_pending', '' );
		if ( ! empty( $pending ) ) {
			Sandbox::mark_fatal( (string) $pending );
			delete_option( 'jorapress_crashguard_pending' );
		}
	}
}
