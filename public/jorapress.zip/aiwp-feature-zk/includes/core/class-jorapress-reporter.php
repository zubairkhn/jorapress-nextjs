<?php
/**
 * Scheduled Site Doctor audits. Runs the read-only scanners on a WP-Cron
 * schedule, records the health score over time, and emails a summary when
 * configured. Read-only — never applies fixes automatically.
 *
 * Options:
 *   jorapress_doctor_schedule  off | daily | weekly   (default off)
 *   jorapress_doctor_email     recipient address      (default admin email)
 *   jorapress_doctor_history   rolling score history (shared with DoctorController)
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

use JoraPress\Plugin;
use JoraPress\Rest\DoctorController;
use JoraPress\Licensing\License;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Reporter {

	public const HOOK            = 'jorapress_doctor_audit';
	private const HISTORY_OPTION = 'jorapress_doctor_history';
	private const HISTORY_MAX    = 60;

	/** domain => scanner tool name. */
	private const SCANNERS = array(
		'health'      => 'site_health',
		'bugs'        => 'error_scan',
		'performance' => 'perf_scan',
		'seo'         => 'seo_scan',
	);

	public static function register(): void {
		add_filter( 'cron_schedules', array( __CLASS__, 'add_weekly' ) );
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
	}

	/** Ensure a weekly interval exists (daily is built in). */
	public static function add_weekly( array $schedules ): array {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display'  => __( 'Once Weekly', 'jorapress' ),
			);
		}
		return $schedules;
	}

	/**
	 * (Re)schedule the audit event to match the saved cadence. Call on activation
	 * and whenever the schedule setting changes.
	 */
	public static function reschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );

		// Scheduled audits are a Pro feature.
		if ( ! License::is_pro() ) {
			return;
		}

		$cadence = (string) get_option( 'jorapress_doctor_schedule', 'off' );
		if ( 'daily' === $cadence || 'weekly' === $cadence ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $cadence, self::HOOK );
		}
	}

	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Cron callback: run scanners, record the score, email a summary.
	 *
	 * @return array<string,mixed> The audit result (also handy for manual runs).
	 */
	public static function run(): array {
		// Pro-only; if the license lapsed, stop scheduling and bail.
		if ( ! License::is_pro() ) {
			self::unschedule();
			return array( 'ok' => false, 'error' => 'Scheduled audits require a Pro license.' );
		}

		$router     = Plugin::instance()->router();
		$domains    = array();
		$all_issues = array();

		foreach ( self::SCANNERS as $domain => $tool ) {
			if ( ! $router->has( $tool ) ) {
				continue;
			}
			$result             = $router->all()[ $tool ]->run( array() );
			$domains[ $domain ] = $result;
			foreach ( (array) ( $result['issues'] ?? array() ) as $issue ) {
				$all_issues[] = $issue;
			}
		}

		$score  = DoctorController::score( $all_issues );
		$counts = self::counts( $all_issues );

		self::record_history( $score, $counts );

		$recipient = sanitize_email( (string) get_option( 'jorapress_doctor_email', get_option( 'admin_email' ) ) );
		if ( $recipient && is_email( $recipient ) ) {
			self::send_email( $recipient, $score, $counts, $domains );
		}

		return array( 'score' => $score, 'counts' => $counts, 'domains' => $domains );
	}

	/** @param array<int,array<string,mixed>> $issues */
	private static function counts( array $issues ): array {
		$out = array( 'critical' => 0, 'warning' => 0, 'recommendation' => 0, 'total' => count( $issues ) );
		foreach ( $issues as $i ) {
			$sev = (string) ( $i['severity'] ?? '' );
			if ( isset( $out[ $sev ] ) ) {
				++$out[ $sev ];
			}
		}
		return $out;
	}

	private static function record_history( int $score, array $counts ): void {
		$history   = (array) get_option( self::HISTORY_OPTION, array() );
		$history[] = array(
			'time'   => current_time( 'mysql' ),
			'score'  => $score,
			'counts' => $counts,
		);
		if ( count( $history ) > self::HISTORY_MAX ) {
			$history = array_slice( $history, -self::HISTORY_MAX );
		}
		update_option( self::HISTORY_OPTION, $history, false );
	}

	/** @param array<string,mixed> $domains */
	private static function send_email( string $to, int $score, array $counts, array $domains ): void {
		$site = wp_specialchars_decode( (string) get_option( 'blogname' ), ENT_QUOTES );

		/* translators: 1: site name, 2: score */
		$subject = sprintf( __( '[%1$s] Site Doctor report — health %2$d/100', 'jorapress' ), $site, $score );

		$lines   = array();
		$lines[] = sprintf( __( 'Health score: %d/100', 'jorapress' ), $score );
		$lines[] = sprintf(
			/* translators: 1: critical, 2: warnings, 3: recommendations */
			__( 'Critical: %1$d · Warnings: %2$d · Recommendations: %3$d', 'jorapress' ),
			$counts['critical'],
			$counts['warning'],
			$counts['recommendation']
		);
		$lines[] = '';

		foreach ( $domains as $domain => $payload ) {
			$issues = (array) ( $payload['issues'] ?? array() );
			$lines[] = strtoupper( $domain ) . ' (' . count( $issues ) . ')';
			foreach ( array_slice( $issues, 0, 8 ) as $issue ) {
				$lines[] = sprintf( '  [%s] %s', $issue['severity'] ?? '?', $issue['title'] ?? '' );
			}
			$lines[] = '';
		}

		$lines[] = sprintf(
			/* translators: %s dashboard URL */
			__( 'Open the Site Doctor: %s', 'jorapress' ),
			admin_url( 'admin.php?page=jorapress-doctor' )
		);

		wp_mail( $to, $subject, implode( "\n", $lines ) );
	}
}
