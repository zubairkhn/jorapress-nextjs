<?php
/**
 * Sandbox: a dedicated, versioned, recoverable directory for AI-written PHP
 * snippets/files. Everything the agent writes is tracked so it can be listed,
 * disabled and reverted from the admin dashboard with one click.
 *
 * Location: wp-content/uploads/jorapress-sandbox/
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Sandbox {

	public static function dir(): string {
		$uploads = wp_upload_dir();
		return trailingslashit( $uploads['basedir'] ) . 'jorapress-sandbox';
	}

	public static function backups_dir(): string {
		return self::dir() . '/.backups';
	}

	/**
	 * Create the sandbox dir, protect it and drop an index guard.
	 */
	public static function ensure_dir(): void {
		$dir = self::dir();
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! is_dir( self::backups_dir() ) ) {
			wp_mkdir_p( self::backups_dir() );
		}

		// Block direct web access to the sandbox.
		$htaccess = $dir . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		$index = $dir . '/index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php // Silence is golden.\n" ); // phpcs:ignore
		}
	}

	/**
	 * Resolve a relative sandbox path to an absolute one, blocking traversal.
	 */
	public static function resolve( string $rel_path ): string {
		$rel_path = ltrim( str_replace( '\\', '/', $rel_path ), '/' );
		if ( str_contains( $rel_path, '..' ) ) {
			throw new SafetyException( __( 'Path traversal is not allowed in the sandbox.', 'jorapress' ), 400 );
		}
		return self::dir() . '/' . $rel_path;
	}

	/**
	 * Write a tracked file into the sandbox, backing up the previous revision.
	 */
	public static function write( string $rel_path, string $contents ): array {
		self::ensure_dir();
		$abs = self::resolve( $rel_path );

		wp_mkdir_p( dirname( $abs ) );

		$existed = file_exists( $abs );
		if ( $existed ) {
			self::backup( $rel_path );
		}

		$bytes = file_put_contents( $abs, $contents ); // phpcs:ignore
		if ( false === $bytes ) {
			throw new SafetyException( sprintf( 'Could not write sandbox file: %s', $rel_path ), 500 );
		}

		self::register_file( $rel_path, ! $existed );

		return array(
			'rel_path' => $rel_path,
			'bytes'    => $bytes,
			'created'  => ! $existed,
		);
	}

	/**
	 * Safely include a sandbox PHP file under the crash guard.
	 */
	public static function load( string $rel_path ): array {
		$abs = self::resolve( $rel_path );
		if ( ! file_exists( $abs ) ) {
			throw new SafetyException( sprintf( 'Sandbox file not found: %s', $rel_path ), 404 );
		}
		if ( self::is_disabled( $rel_path ) ) {
			throw new SafetyException( sprintf( 'Sandbox file is disabled: %s', $rel_path ), 423 );
		}

		CrashGuard::guard_file( $rel_path );
		$result = CrashGuard::run_guarded(
			static function () use ( $abs ) {
				return include $abs;
			}
		);
		CrashGuard::clear();

		return $result;
	}

	private static function backup( string $rel_path ): void {
		$abs = self::resolve( $rel_path );
		if ( ! file_exists( $abs ) ) {
			return;
		}
		$stamp  = gmdate( 'Ymd-His' );
		$target = self::backups_dir() . '/' . sanitize_file_name( str_replace( '/', '__', $rel_path ) ) . '.' . $stamp . '.bak';
		copy( $abs, $target );
	}

	private static function register_file( string $rel_path, bool $created ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jorapress_sandbox_files';
		$now   = current_time( 'mysql', true );

		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE rel_path = %s", $rel_path ) ); // phpcs:ignore

		if ( $existing ) {
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET updated_at = %s, revision = revision + 1, fatal = 0 WHERE id = %d", // phpcs:ignore
					$now,
					$existing
				)
			);
		} else {
			$wpdb->insert(
				$table,
				array(
					'rel_path'   => $rel_path,
					'created_at' => $now,
					'updated_at' => $now,
					'revision'   => 1,
				),
				array( '%s', '%s', '%s', '%d' )
			);
		}
	}

	public static function mark_fatal( string $rel_path ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jorapress_sandbox_files';
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET fatal = 1, disabled = 1 WHERE rel_path = %s", $rel_path ) ); // phpcs:ignore
	}

	public static function is_disabled( string $rel_path ): bool {
		global $wpdb;
		$table = $wpdb->prefix . 'jorapress_sandbox_files';
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT disabled FROM {$table} WHERE rel_path = %s", $rel_path ) ); // phpcs:ignore
	}

	public static function set_disabled( string $rel_path, bool $disabled ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jorapress_sandbox_files';
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET disabled = %d WHERE rel_path = %s", $disabled ? 1 : 0, $rel_path ) ); // phpcs:ignore
	}

	/**
	 * Delete a sandbox file (backing it up first) and drop its registry row.
	 */
	public static function revert( string $rel_path ): void {
		$abs = self::resolve( $rel_path );
		if ( file_exists( $abs ) ) {
			self::backup( $rel_path );
			unlink( $abs );
		}
		global $wpdb;
		$table = $wpdb->prefix . 'jorapress_sandbox_files';
		$wpdb->delete( $table, array( 'rel_path' => $rel_path ), array( '%s' ) );
	}

	/**
	 * @return array<int,object>
	 */
	public static function list_files(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'jorapress_sandbox_files';
		return (array) $wpdb->get_results( "SELECT * FROM {$table} ORDER BY updated_at DESC" ); // phpcs:ignore
	}
}
