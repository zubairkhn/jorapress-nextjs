<?php
/**
 * Project memory (Pro). Key/value notes the agent can persist between sessions:
 * conventions, past decisions, project context. Stored in wp_jorapress_memory.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Memory;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Memory {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jorapress_memory';
	}

	public function set( string $key, string $value, string $scope = 'global' ): void {
		global $wpdb;
		$wpdb->replace(
			$this->table,
			array(
				'scope'      => $scope,
				'mem_key'    => $key,
				'mem_value'  => $value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%s', '%s' )
		);
	}

	public function get( string $key, string $scope = 'global' ): ?string {
		global $wpdb;
		$value = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT mem_value FROM {$this->table} WHERE scope = %s AND mem_key = %s", // phpcs:ignore
				$scope,
				$key
			)
		);
		return null === $value ? null : (string) $value;
	}

	/**
	 * @return array<int,object>
	 */
	public function all( string $scope = 'global' ): array {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$this->table} WHERE scope = %s ORDER BY mem_key", $scope ) // phpcs:ignore
		);
	}

	public function delete( string $key, string $scope = 'global' ): void {
		global $wpdb;
		$wpdb->delete( $this->table, array( 'scope' => $scope, 'mem_key' => $key ), array( '%s', '%s' ) );
	}

	/**
	 * Render a compact context block for the system prompt.
	 */
	public function context_block( string $scope = 'global' ): string {
		$rows = $this->all( $scope );
		if ( ! $rows ) {
			return '';
		}
		$lines = array();
		foreach ( $rows as $r ) {
			$lines[] = sprintf( '- %s: %s', $r->mem_key, $r->mem_value );
		}
		return implode( "\n", $lines );
	}
}
