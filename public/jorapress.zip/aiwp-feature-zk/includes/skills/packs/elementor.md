<!-- jorapress-skill: elementor, hero, section, widget, page builder ; pro -->
# Elementor layout schema

**Where the layout lives:** the `_elementor_data` post meta on the page/post.
Supporting meta you must keep consistent:
- `_elementor_edit_mode` = `builder`
- `_elementor_template_type` = `wp-page` (or `header`, `footer`, `single`, etc.)
- `_elementor_version` = the installed Elementor version (read it; don't hardcode)

**Format:** `_elementor_data` is a JSON-encoded **array of top-level elements**.
The tree is: section → column → widget. Every element object has:
- `id` — a unique 7-char hex string (e.g. `a1b2c3d`). Generate fresh ids.
- `elType` — `section`, `column`, or `widget`.
- `settings` — an object of element settings.
- `elements` — child elements array.
- widgets additionally carry `widgetType` (e.g. `heading`, `text-editor`, `button`, `image`).

**Minimal hero example (one section, one full-width column, heading + button):**
```json
[
  {
    "id":"1a2b3c4","elType":"section","settings":{"layout":"full_width"},
    "elements":[
      {
        "id":"2b3c4d5","elType":"column","settings":{"_column_size":100},
        "elements":[
          {"id":"3c4d5e6","elType":"widget","widgetType":"heading",
            "settings":{"title":"Welcome","header_size":"h1"},"elements":[]},
          {"id":"4d5e6f7","elType":"widget","widgetType":"button",
            "settings":{"text":"Get started","link":{"url":"#"}},"elements":[]}
        ]
      }
    ]
  }
]
```

**Procedure (always do this):**
1. Read an existing Elementor page first to learn the exact widget settings keys for THIS site/version:
   `db_query` → `SELECT meta_value FROM {prefix}postmeta WHERE post_id=<id> AND meta_key='_elementor_data'`.
2. Build the new tree, generate unique `id`s, write it back:
   `update_post_meta( $id, '_elementor_data', wp_slash( $json ) )` (the value must be a JSON **string**).
3. Set `_elementor_edit_mode=builder` and keep `_elementor_version`.
4. Clear the cache so it renders:
   `execute_php` → `\Elementor\Plugin::$instance->files_manager->clear_cache();`

**Elementor v4 / atomic widgets:** newer versions introduce atomic widgets with a
different settings shape. Always read a live example before generating — do not assume.
