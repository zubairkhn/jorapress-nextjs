<!-- jorapress-skill: best practice, best practices, security, harden, standards, coding standards, sanitize, escape, nonce, capability, wp-config, maintenance -->
# WordPress best practices

**Security when writing code:**
- **Escape on output:** `esc_html()`, `esc_attr()`, `esc_url()`, `wp_kses_post()`.
- **Sanitize on input:** `sanitize_text_field()`, `absint()`, `sanitize_key()`.
- **Verify intent:** nonces (`wp_verify_nonce` / `check_admin_referer`) and
  capabilities (`current_user_can`) on every state-changing action.
- **Parameterize SQL:** always `$wpdb->prepare()`; never interpolate input.
- **No secrets in code/logs.** Keys belong in encrypted option storage.

**Data & DB:**
- Use the WP API (`get_posts`, `WP_Query`, `update_post_meta`) over raw SQL when
  possible. Snapshot before destructive writes.
- Don't autoload large options (`add_option( $k, $v, '', 'no' )`).
- Cap revisions; clean transients periodically.

**Code quality:**
- Follow WordPress coding standards; prefix functions/options/hooks.
- Check a function exists before using version-specific APIs.
- Avoid dynamic properties (PHP 8.2+): declare them.
- Replace deprecated calls promptly (see the debugging skill).

**Operational:**
- Keep core, themes, and plugins updated (`bug_fix action=update_plugins`).
- Run on PHP 8.1+; enable a persistent object cache in production.
- Take backups before bulk changes — JoraPress snapshots, but keep host backups too.
- JoraPress is dev/staging-first: respect the production guardrail and write-gating.
