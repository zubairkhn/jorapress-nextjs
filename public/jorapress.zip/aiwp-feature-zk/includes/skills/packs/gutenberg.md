<!-- jorapress-skill: gutenberg, block, blocks, block editor, post_content -->
# Gutenberg / block editor

**Where the layout lives:** directly in `post_content` as block markup (HTML
comments delimiting each block).

**Format:** `<!-- wp:NAMESPACE/NAME {JSON-ATTRS} --> ...html... <!-- /wp:NAMESPACE/NAME -->`
Core blocks use the `core/` namespace, often written without it (`wp:heading`).

**Example — heading + paragraph + button:**
```html
<!-- wp:heading {"level":1} --><h1 class="wp-block-heading">Welcome</h1><!-- /wp:heading -->
<!-- wp:paragraph --><p>Intro copy here.</p><!-- /wp:paragraph -->
<!-- wp:buttons --><div class="wp-block-buttons">
  <!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Get started</a></div><!-- /wp:button -->
</div><!-- /wp:buttons -->
```

**Procedure:**
1. Read the current `post_content` to match existing patterns/classes:
   `wp_rest` GET `/wp/v2/pages/<id>?context=edit` or `get_post_field('post_content',$id)`.
2. Build valid block markup. Inner HTML must match what the block's `save` outputs,
   otherwise the editor flags "block recovery". Keep the wrapper classes shown above.
3. Write it: `wp_update_post(['ID'=>$id,'post_content'=>$markup])`.
4. No cache clear is needed for core blocks.

**Validation tip:** after writing, you can run `do_blocks($content)` via execute_php to
confirm it renders without errors.
