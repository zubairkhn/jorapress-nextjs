<!-- jorapress-skill: bricks, divi, beaver, oxygen, builder schema ; pro -->
# Other builders — storage formats

Always READ a live example from the site before generating, then write + clear cache.

## Bricks
- **Stored in:** `_bricks_page_content_2` post meta (array/JSON).
- **Shape:** flat array of elements, each `{ "id", "name", "parent", "settings", "children" }`.
  Hierarchy is expressed via `parent` ids (not nesting), plus a `children` id list.
- Read: `get_post_meta($id,'_bricks_page_content_2',true)`.
- Clear cache: regenerate CSS via `Bricks\Assets::generate_css_file()` style routines
  (check the installed version's API by reading the plugin source first).

## Divi
- **Stored in:** `post_content` directly, as shortcodes.
- **Shape:** `[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text]...[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]`.
- Write via `wp_update_post`. Ensure `_et_pb_use_builder` meta = `on`.

## Beaver Builder
- **Stored in:** `_fl_builder_data` post meta as a **serialized PHP object graph**
  (not JSON). Read/manipulate via execute_php using FLBuilderModel, not by hand.
- Also keep `_fl_builder_enabled` = 1.

## Oxygen
- **Stored in:** `ct_builder_shortcodes` post meta (a shortcode string), plus
  `ct_builder_json` in newer versions. Read both before editing.

**Golden rule:** there is no per-builder tool. The schema differs per builder *and*
per version — read first, write second, clear cache third.
