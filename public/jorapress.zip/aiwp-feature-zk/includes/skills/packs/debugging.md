<!-- jorapress-skill: bug, bugs, error, errors, fatal, white screen, debug, debugging, broken, crash, exception, deprecated, conflict, not working, 500 -->
# Debugging WordPress issues

**Start with a scan, not a guess.** Run the `error_scan` tool first — it parses
the debug log, groups errors, and attributes each to a plugin/theme. Then use
`site_health` for environment-level problems (PHP version, REST, cron, HTTPS).

**Triage order:**
1. **Fatals first.** A fatal/`Uncaught` error breaks pages. `error_scan` tags the
   offending plugin/theme. Confirm with `read_file` around the reported file/line.
2. **Reproduce safely.** Prefer `execute_php` with a small probe over editing
   files. The crash guard catches fatals from `execute_php`.
3. **Isolate.** If a plugin is the source, `bug_fix action=deactivate_plugin
   plugin=<folder>` (run with `dry_run=true` first). Deactivation is reversible.
4. **Patch, don't hack.** Replace deprecated calls with current equivalents;
   fix the root cause. Use `edit_file` for surgical changes (AI-written files go
   to the sandbox and are revertible).

**Enabling logs** (if `error_scan` reports logging is off): set in `wp-config.php`
```php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false ); // never show errors to visitors
```

**Common deprecations to fix:** `get_page_by_title()` (removed 6.3 →
`WP_Query`), `wp_make_content_images_responsive()`, dynamic properties on PHP
8.2+ (declare them or add `#[\AllowDynamicProperties]`).

**Rules:** always `dry_run` a fixer before applying; never disable the crash
guard; snapshot before DB writes (the fixers do this for you).
