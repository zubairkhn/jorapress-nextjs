<?php
/**
 * Skills manager. Skills are short Markdown playbooks the agent auto-loads when
 * a task matches — site conventions and version-accurate builder schema notes.
 *
 * Each pack begins with a trigger comment:
 *   <!-- jorapress-skill: keyword1, keyword2, ... ; pro -->
 * The optional "pro" flag gates the pack behind a Pro licence.
 *
 * Packs live in:  includes/skills/packs/*.md   (bundled)
 *           and:  wp-content/uploads/jorapress-skills/*.md  (user-authored)
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Skills;

use JoraPress\Licensing\License;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SkillsManager {

	/**
	 * @return array<int,array{name:string,keywords:array<int,string>,pro:bool,body:string,source:string}>
	 */
	public function packs(): array {
		$packs = array();

		foreach ( $this->dirs() as $dir ) {
			if ( ! is_dir( $dir ) ) {
				continue;
			}
			foreach ( (array) glob( $dir . '/*.md' ) as $file ) {
				$packs[] = $this->parse_pack( (string) file_get_contents( $file ), basename( $file, '.md' ), $dir );
			}
		}

		return $packs;
	}

	/**
	 * Return the concatenated bodies of every pack whose keywords appear in the
	 * prompt. Pro packs are skipped without a licence.
	 */
	public function match( string $prompt ): string {
		$prompt = strtolower( $prompt );
		$out    = array();

		foreach ( $this->packs() as $pack ) {
			if ( $pack['pro'] && ! License::is_pro() ) {
				continue;
			}
			foreach ( $pack['keywords'] as $kw ) {
				if ( '' !== $kw && str_contains( $prompt, $kw ) ) {
					$out[] = '## Skill: ' . $pack['name'] . "\n" . $pack['body'];
					break;
				}
			}
		}

		return implode( "\n\n", $out );
	}

	/**
	 * @return array<int,string>
	 */
	private function dirs(): array {
		$uploads = wp_upload_dir();
		return array(
			JORAPRESS_DIR . 'includes/skills/packs',
			trailingslashit( $uploads['basedir'] ) . 'jorapress-skills',
		);
	}

	private function parse_pack( string $contents, string $name, string $dir ): array {
		$keywords = array();
		$pro      = false;

		if ( preg_match( '/<!--\s*jorapress-skill:\s*(.+?)\s*-->/i', $contents, $m ) ) {
			$spec     = $m[1];
			$parts    = explode( ';', $spec );
			$keywords = array_filter( array_map( 'trim', explode( ',', strtolower( $parts[0] ) ) ) );
			if ( isset( $parts[1] ) && str_contains( strtolower( $parts[1] ), 'pro' ) ) {
				$pro = true;
			}
			$contents = (string) preg_replace( '/<!--\s*jorapress-skill:.+?-->/i', '', $contents, 1 );
		} else {
			// Fall back to the filename as a single keyword.
			$keywords = array( strtolower( $name ) );
		}

		return array(
			'name'     => $name,
			'keywords' => array_values( $keywords ),
			'pro'      => $pro,
			'body'     => trim( $contents ),
			'source'   => str_contains( $dir, 'uploads' ) ? 'user' : 'bundled',
		);
	}
}
