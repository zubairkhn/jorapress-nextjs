<?php
/**
 * Self-hosted auto-updater. Asks the JoraPress backend whether a newer build
 * exists for this licensed site and, if so, feeds it into the normal WordPress
 * plugin-update flow (Dashboard → Updates / Plugins screen).
 *
 * The download package URL carries the license key + site so the backend can
 * authorise the zip download. Results are cached in a transient to avoid
 * hitting the backend on every admin page load.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Updater {

	private const CACHE_KEY = 'jorapress_update_check';
	private const CACHE_TTL = 6 * HOUR_IN_SECONDS;

	public static function init(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 10, 3 );
		// Drop our cache right after WordPress refreshes update data.
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ) );
	}

	/**
	 * @param mixed $transient
	 * @return mixed
	 */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$info = self::check();
		if ( empty( $info['update_available'] ) || empty( $info['package'] ) ) {
			return $transient;
		}

		$item = (object) array(
			'slug'        => JORAPRESS_SLUG,
			'plugin'      => JORAPRESS_BASENAME,
			'new_version' => (string) $info['latest'],
			'url'         => 'https://jorapress.com',
			'package'     => (string) $info['package'],
		);

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ JORAPRESS_BASENAME ] = $item;

		return $transient;
	}

	/**
	 * Populate the "View details" modal.
	 *
	 * @param mixed                       $result
	 * @param string                      $action
	 * @param object{slug?:string}|object $args
	 * @return mixed
	 */
	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $result;
		}
		if ( ! isset( $args->slug ) || JORAPRESS_SLUG !== $args->slug ) {
			return $result;
		}

		$info = self::check();
		return (object) array(
			'name'          => 'JoraPress — AI WordPress Builder',
			'slug'          => JORAPRESS_SLUG,
			'version'       => (string) ( $info['latest'] ?? JORAPRESS_VERSION ),
			'download_link' => (string) ( $info['package'] ?? '' ),
			'homepage'      => 'https://jorapress.com',
			'sections'      => array(
				'description' => 'Let your AI agent build and heal your WordPress site.',
			),
		);
	}

	public static function flush(): void {
		delete_transient( self::CACHE_KEY );
	}

	/**
	 * Query the backend (cached). Returns the decoded /api/update/check payload.
	 *
	 * @return array<string,mixed>
	 */
	private static function check(): array {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$key = License::license_key();
		$base = License::api_base();
		if ( '' === $key || '' === $base ) {
			return array();
		}

		$url = add_query_arg(
			array(
				'key'     => rawurlencode( $key ),
				'site'    => rawurlencode( home_url( '/' ) ),
				'version' => rawurlencode( JORAPRESS_VERSION ),
			),
			$base . '/api/update/check'
		);

		$response = wp_remote_get( $url, array( 'timeout' => 20 ) );
		if ( is_wp_error( $response ) ) {
			return array();
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : array();

		set_transient( self::CACHE_KEY, $data, self::CACHE_TTL );
		return $data;
	}
}
