<?php
/**
 * Licensing + auto-update scaffold. Intentionally provider-agnostic: wire it to
 * Freemius or EDD Software Licensing + a self-hosted update server (the plugin
 * cannot rely on the WordPress.org repo because its core feature is arbitrary
 * code execution).
 *
 * `License::is_pro()` is the single gate the rest of the plugin checks; it is
 * filterable so any backend can supply the verdict.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class License {

	public static function is_pro(): bool {
		$pro = (bool) get_option( 'jorapress_license_active', 0 );

		/**
		 * Filter the Pro entitlement. Hook your Freemius/EDD check here.
		 *
		 * @param bool $pro
		 */
		return (bool) apply_filters( 'jorapress_is_pro', $pro );
	}

	public static function license_key(): string {
		return (string) get_option( 'jorapress_license_key', '' );
	}

	/**
	 * Activate a license key against the remote update/licence server.
	 * Replace the endpoint + response handling with your provider's API.
	 */
	public static function activate( string $key ): array {
		$key = trim( $key );
		if ( '' === $key ) {
			return array( 'ok' => false, 'error' => 'Empty license key.' );
		}

		$endpoint = apply_filters( 'jorapress_license_endpoint', '' );
		if ( '' === $endpoint ) {
			// No backend wired yet — store optimistically for local dev.
			update_option( 'jorapress_license_key', $key, false );
			update_option( 'jorapress_license_active', 1 );
			return array( 'ok' => true, 'note' => 'Stored locally (no license server configured).' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'body'    => array(
					'action'  => 'activate',
					'key'     => $key,
					'site'    => home_url( '/' ),
					'version' => JORAPRESS_VERSION,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'error' => $response->get_error_message() );
		}

		$data   = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$active = (bool) ( $data['success'] ?? false );

		update_option( 'jorapress_license_key', $key, false );
		update_option( 'jorapress_license_active', $active ? 1 : 0 );

		return array( 'ok' => $active, 'data' => $data );
	}

	public static function deactivate(): void {
		update_option( 'jorapress_license_active', 0 );
		delete_option( 'jorapress_license_key' );
	}

	/**
	 * Register the self-hosted update checker. Hook your EDD/Freemius updater or
	 * a custom `pre_set_site_transient_update_plugins` filter here.
	 */
	public static function register_updates(): void {
		do_action( 'jorapress_register_updates' );
	}
}
