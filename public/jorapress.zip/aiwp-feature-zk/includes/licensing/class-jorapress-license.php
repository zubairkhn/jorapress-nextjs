<?php
/**
 * Licensing client. Talks to the JoraPress backend (jorapress-backend) to
 * activate, validate and deactivate a license key, and exposes the resulting
 * tier/entitlement to the rest of the plugin.
 *
 * `License::is_pro()` is the single gate the plugin checks; `License::tier()`
 * returns 'free' | 'pro' | 'agency'. Both read a cached local snapshot that is
 * refreshed on activation and periodically re-validated against the backend.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class License {

	private const OPT_KEY     = 'jorapress_license_key';
	private const OPT_ACTIVE  = 'jorapress_license_active';
	private const OPT_TIER    = 'jorapress_license_tier';
	private const OPT_EXPIRES = 'jorapress_license_expires';
	private const OPT_CHECK   = 'jorapress_license_last_check';

	private const REVALIDATE_EVERY = DAY_IN_SECONDS;

	/** Base URL of the backend, filterable. */
	public static function api_base(): string {
		$base = defined( 'JORAPRESS_API_BASE' ) ? JORAPRESS_API_BASE : '';
		return untrailingslashit( (string) apply_filters( 'jorapress_api_base', $base ) );
	}

	public static function license_key(): string {
		return (string) get_option( self::OPT_KEY, '' );
	}

	/** 'free' | 'pro' | 'agency'. */
	public static function tier(): string {
		self::maybe_revalidate();
		if ( ! self::is_active() ) {
			return 'free';
		}
		$tier = (string) get_option( self::OPT_TIER, '' );
		return in_array( $tier, array( 'pro', 'agency' ), true ) ? $tier : 'free';
	}

	/** True for any paid tier. Filterable so other backends can override. */
	public static function is_pro(): bool {
		$pro = 'free' !== self::tier();
		return (bool) apply_filters( 'jorapress_is_pro', $pro );
	}

	public static function is_agency(): bool {
		return 'agency' === self::tier();
	}

	private static function is_active(): bool {
		if ( ! (bool) get_option( self::OPT_ACTIVE, 0 ) ) {
			return false;
		}
		$expires = (int) get_option( self::OPT_EXPIRES, 0 );
		if ( $expires > 0 && $expires < time() ) {
			return false; // lapsed
		}
		return true;
	}

	/**
	 * Activate a key against the backend and cache the verdict.
	 *
	 * @return array{ok:bool,error?:string,tier?:string}
	 */
	public static function activate( string $key ): array {
		$key = trim( $key );
		if ( '' === $key ) {
			return array( 'ok' => false, 'error' => 'Empty license key.' );
		}

		$res = self::post(
			'/api/license/activate',
			array(
				'key'     => $key,
				'site'    => home_url( '/' ),
				'version' => JORAPRESS_VERSION,
			)
		);

		if ( is_wp_error( $res ) ) {
			return array( 'ok' => false, 'error' => $res->get_error_message() );
		}

		if ( empty( $res['valid'] ) ) {
			return array( 'ok' => false, 'error' => (string) ( $res['error'] ?? 'License not valid.' ) );
		}

		update_option( self::OPT_KEY, $key, false );
		self::store_snapshot( $res );

		return array( 'ok' => true, 'tier' => (string) ( $res['tier'] ?? 'free' ) );
	}

	/** Re-check status with the backend (no site binding change). */
	public static function validate(): void {
		$key = self::license_key();
		if ( '' === $key ) {
			return;
		}
		$res = self::post( '/api/license/validate', array( 'key' => $key ) );
		if ( ! is_wp_error( $res ) ) {
			self::store_snapshot( $res );
		}
		update_option( self::OPT_CHECK, time(), false );
	}

	/** Release this site's seat on the backend and clear the local snapshot. */
	public static function deactivate(): void {
		$key = self::license_key();
		if ( '' !== $key ) {
			self::post(
				'/api/license/deactivate',
				array(
					'key'  => $key,
					'site' => home_url( '/' ),
				)
			);
		}
		delete_option( self::OPT_KEY );
		update_option( self::OPT_ACTIVE, 0 );
		delete_option( self::OPT_TIER );
		delete_option( self::OPT_EXPIRES );
	}

	public static function expires_at(): int {
		return (int) get_option( self::OPT_EXPIRES, 0 );
	}

	/** Register the auto-updater. Called on init. */
	public static function register_updates(): void {
		Updater::init();
		do_action( 'jorapress_register_updates' );
	}

	// ── internals ──────────────────────────────────────────────────────

	/** @param array<string,mixed> $res */
	private static function store_snapshot( array $res ): void {
		$valid = ! empty( $res['valid'] );
		update_option( self::OPT_ACTIVE, $valid ? 1 : 0 );
		update_option( self::OPT_TIER, (string) ( $res['tier'] ?? 'free' ), false );
		update_option( self::OPT_EXPIRES, (int) ( $res['expires_at'] ?? 0 ), false );
		update_option( self::OPT_CHECK, time(), false );
	}

	private static function maybe_revalidate(): void {
		if ( '' === self::license_key() ) {
			return;
		}
		$last = (int) get_option( self::OPT_CHECK, 0 );
		if ( ( time() - $last ) > self::REVALIDATE_EVERY ) {
			self::validate();
		}
	}

	/**
	 * POST JSON to the backend and decode the response.
	 *
	 * @param array<string,mixed> $body
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function post( string $path, array $body ) {
		$base = self::api_base();
		if ( '' === $base ) {
			return new \WP_Error( 'no_backend', 'No license backend configured.' );
		}

		$response = wp_remote_post(
			$base . $path,
			array(
				'timeout' => 20,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : array();
	}
}
