<?php
/**
 * Server-side agent loop for the chat-panel front door.
 *
 * Stateless across requests: the conversation lives client-side and is posted
 * back each turn. The loop runs prompt -> model -> tool calls -> results,
 * honouring a step cap and an optional "pause for approval" gate on writes.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Agent;

use JoraPress\Core\ToolRouter;
use JoraPress\Skills\SkillsManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Loop {

	public function __construct(
		private ToolRouter $router,
		private ProviderManager $providers,
		private SkillsManager $skills
	) {}

	/**
	 * Run agent turns until the model stops calling tools, the step cap is hit,
	 * or a write needs approval.
	 *
	 * @param array<int,array<string,mixed>> $messages Internal message list.
	 * @return array<string,mixed> {
	 *   status: 'done'|'awaiting_approval'|'max_steps'|'error',
	 *   messages: updated list, steps: executed tool steps, pending: pending tool calls,
	 *   assistant_text: latest assistant text, error?: string
	 * }
	 */
	public function run( array $messages, string $user_prompt = '' ): array {
		$provider = $this->providers->active();
		if ( ! $provider ) {
			return array(
				'status' => 'error',
				'error'  => 'No model provider configured.',
			);
		}

		$model   = $this->providers->active_model();
		$api_key = $this->providers->api_key( $provider->id() );
		if ( '' === $api_key ) {
			return array(
				'status' => 'error',
				'error'  => sprintf( 'No API key set for %s. Add one in JoraPress settings.', $provider->label() ),
			);
		}

		if ( '' !== $user_prompt ) {
			$messages[] = array(
				'role'    => 'user',
				'content' => $user_prompt,
			);
		}

		$system           = $this->system_prompt( $user_prompt );
		$tools            = $this->router->descriptors();
		$require_approval = (bool) get_option( 'jorapress_require_approval', 1 );
		$max_steps        = (int) get_option( 'jorapress_agent_max_steps', 25 );
		$steps            = array();

		for ( $i = 0; $i < $max_steps; $i++ ) {
			$resp = $provider->send( $messages, $tools, $system, $model, $api_key );

			if ( 'error' === ( $resp['stop_reason'] ?? '' ) ) {
				return array(
					'status'   => 'error',
					'error'    => $resp['error'] ?? 'Model error.',
					'messages' => $messages,
				);
			}

			$assistant = array(
				'role'    => 'assistant',
				'content' => $resp['text'],
			);
			if ( ! empty( $resp['tool_calls'] ) ) {
				$assistant['tool_calls'] = $resp['tool_calls'];
			}
			$messages[] = $assistant;

			// No tool calls -> the model is done talking.
			if ( empty( $resp['tool_calls'] ) ) {
				return array(
					'status'         => 'done',
					'messages'       => $messages,
					'steps'          => $steps,
					'assistant_text' => $resp['text'],
				);
			}

			// Tool calls present. If any is a write and approval is required,
			// pause and hand the pending calls back to the UI.
			if ( $require_approval && $this->any_write( $resp['tool_calls'] ) ) {
				return array(
					'status'         => 'awaiting_approval',
					'messages'       => $messages,
					'pending'        => $resp['tool_calls'],
					'assistant_text' => $resp['text'],
					'steps'          => $steps,
				);
			}

			// Auto-execute (reads, or approval disabled).
			$messages = $this->execute_tool_calls( $messages, $resp['tool_calls'], $steps );
		}

		return array(
			'status'   => 'max_steps',
			'messages' => $messages,
			'steps'    => $steps,
		);
	}

	/**
	 * Execute a set of approved tool calls, append results, and return the
	 * updated message list. Used both by the loop and by the explicit approval
	 * endpoint.
	 *
	 * @param array<int,array<string,mixed>> $messages
	 * @param array<int,array<string,mixed>> $tool_calls
	 * @param array<int,array<string,mixed>> $steps  (by reference)
	 * @return array<int,array<string,mixed>>
	 */
	public function execute_tool_calls( array $messages, array $tool_calls, array &$steps ): array {
		foreach ( $tool_calls as $tc ) {
			$result = $this->router->call( (string) $tc['name'], (array) $tc['arguments'], 'chat' );
			$text   = (string) wp_json_encode( $result, JSON_UNESCAPED_SLASHES );

			$messages[] = array(
				'role'         => 'tool',
				'tool_call_id' => $tc['id'],
				'name'         => $tc['name'],
				'content'      => $text,
			);

			$steps[] = array(
				'tool'   => $tc['name'],
				'args'   => $tc['arguments'],
				'result' => $result,
			);
		}
		return $messages;
	}

	private function any_write( array $tool_calls ): bool {
		foreach ( $tool_calls as $tc ) {
			$name = (string) $tc['name'];
			if ( ! $this->router->has( $name ) ) {
				continue;
			}
			$tool = $this->router->all()[ $name ];
			if ( $tool->is_write( (array) $tc['arguments'] ) ) {
				return true;
			}
		}
		return false;
	}

	private function system_prompt( string $user_prompt ): string {
		$base = <<<'SYS'
You are JoraPress, an AI agent embedded in a WordPress site via a secure execution bridge.
You build and design WordPress sites by composing low-level tools. There is NO per-builder tool.
To work with a page builder (Elementor, Bricks, Divi, Gutenberg, Beaver Builder, Oxygen):
  1. READ an existing page's layout (db_query on post meta, or execute_php) to learn the exact JSON/shortcode shape this site & version uses.
  2. GENERATE the correct structure and WRITE it (update_post_meta / wp_update_post).
  3. CLEAR the builder's cache so the change renders (e.g. Elementor files-manager clear_cache).
Prefer read-only tools first. Make minimal, reversible changes. Explain what you will do before destructive writes.
This is a dev/staging environment. Snapshots are taken automatically before writes.
SYS;

		$skills = $this->skills->match( $user_prompt );
		if ( '' !== $skills ) {
			$base .= "\n\n# Loaded skills (site conventions & builder schemas)\n" . $skills;
		}

		$memory = ( new \JoraPress\Memory\Memory() )->context_block();
		if ( '' !== $memory ) {
			$base .= "\n\n# Project memory\n" . $memory;
		}

		return $base;
	}
}
