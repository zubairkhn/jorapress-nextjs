<?php
/**
 * Chat panel view. The conversation UI is rendered by admin.js against the
 * /chat/run and /chat/approve REST endpoints.
 *
 * @package JoraPress
 * @var \JoraPress\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap jorapress-wrap jorapress-chat-wrap">
	<h1><?php esc_html_e( 'JoraPress Chat', 'jorapress' ); ?></h1>

	<?php if ( ! $safety->is_enabled() ) : ?>
		<div class="notice notice-warning inline"><p>
			<?php
			printf(
				/* translators: link */
				esc_html__( 'AI abilities are disabled. Enable them on the %s first.', 'jorapress' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=jorapress' ) ) . '">' . esc_html__( 'Dashboard', 'jorapress' ) . '</a>'
			);
			?>
		</p></div>
	<?php endif; ?>

	<div id="jorapress-chat" data-jorapress-app="chat">
		<div id="jorapress-chat-log" class="jorapress-chat-log"></div>
		<div id="jorapress-chat-pending" class="jorapress-chat-pending" hidden></div>
		<form id="jorapress-chat-form" class="jorapress-chat-form">
			<textarea id="jorapress-chat-input" rows="2" placeholder="<?php esc_attr_e( 'e.g. Rebuild my homepage hero in Elementor with a headline, subtext and a Get started button…', 'jorapress' ); ?>"></textarea>
			<button type="submit" class="button button-primary"><?php esc_html_e( 'Send', 'jorapress' ); ?></button>
		</form>
		<p class="description"><?php esc_html_e( 'The agent will read your site, propose changes, and (when approval is on) pause before any write.', 'jorapress' ); ?></p>
	</div>
</div>
