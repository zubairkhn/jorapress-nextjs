<?php
/**
 * Sandbox view — lists AI-written files with disable / enable / revert actions.
 * Driven by the REST API + admin.js.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap jorapress-wrap">
	<h1><?php esc_html_e( 'AI Sandbox', 'jorapress' ); ?></h1>
	<p><?php esc_html_e( 'Files the AI wrote into the recoverable sandbox directory. A file that caused a fatal error is auto-disabled. Everything here is one-click revertible.', 'jorapress' ); ?></p>

	<div id="jorapress-sandbox" data-jorapress-app="sandbox">
		<p class="jorapress-loading"><?php esc_html_e( 'Loading…', 'jorapress' ); ?></p>
	</div>
</div>
