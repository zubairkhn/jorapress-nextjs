<?php
/**
 * Audit log view.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap jorapress-wrap">
	<h1><?php esc_html_e( 'Audit Log', 'jorapress' ); ?></h1>
	<p><?php esc_html_e( 'Every tool call: who, when, what, and the result. Read-only.', 'jorapress' ); ?></p>

	<div id="jorapress-audit" data-jorapress-app="audit">
		<p class="jorapress-loading"><?php esc_html_e( 'Loading…', 'jorapress' ); ?></p>
	</div>
</div>
