<?php
/**
 * Site Doctor view. Runs the diagnostic scanners and lets the operator apply
 * (or preview) fixes, grouped by Bugs / Performance / SEO / Health.
 *
 * @package JoraPress
 * @var \JoraPress\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$writes  = $safety->writes_allowed();
$enabled = $safety->is_enabled();
?>
<div class="wrap jorapress-wrap" id="jorapress-doctor">
	<h1><span class="dashicons dashicons-heart"></span> <?php esc_html_e( 'Site Doctor', 'jorapress' ); ?></h1>
	<p class="jorapress-tagline"><?php esc_html_e( 'Diagnose and fix bugs, performance and SEO issues. Scans are read-only; fixes are gated, snapshotted and reversible.', 'jorapress' ); ?></p>

	<?php if ( ! $enabled || ! $writes ) : ?>
		<div class="notice notice-info inline"><p>
			<?php esc_html_e( 'Scanning works any time. Applying fixes needs AI abilities enabled (Dashboard) and writes allowed (Settings).', 'jorapress' ); ?>
		</p></div>
	<?php endif; ?>

	<p>
		<button class="button button-primary button-hero" id="jorapress-doctor-scan"><?php esc_html_e( 'Run full scan', 'jorapress' ); ?></button>
		<span class="jorapress-doctor-meta" id="jorapress-doctor-meta"></span>
	</p>

	<div class="jorapress-doctor-score" id="jorapress-doctor-score" hidden>
		<div class="jorapress-score-ring" id="jorapress-score-ring"><span id="jorapress-score-num">–</span></div>
		<div class="jorapress-score-counts" id="jorapress-score-counts"></div>
	</div>

	<div id="jorapress-doctor-results" class="jorapress-doctor-results"></div>
</div>
