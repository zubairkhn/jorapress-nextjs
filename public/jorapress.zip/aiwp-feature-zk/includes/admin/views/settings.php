<?php
/**
 * Settings view.
 *
 * @package JoraPress
 * @var \JoraPress\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use JoraPress\Agent\ProviderManager;
use JoraPress\Licensing\License;

$pm       = new ProviderManager();
$provider = (string) get_option( 'jorapress_provider', 'anthropic' );
$saved    = isset( $_GET['jorapress_msg'] ) && 'saved' === $_GET['jorapress_msg']; // phpcs:ignore WordPress.Security.NonceVerification
?>
<div class="wrap jorapress-wrap">
	<h1><?php esc_html_e( 'JoraPress Settings', 'jorapress' ); ?></h1>

	<?php if ( $saved ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'jorapress' ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'jorapress_save_settings' ); ?>
		<input type="hidden" name="action" value="jorapress_save_settings">

		<h2><?php esc_html_e( 'Safety', 'jorapress' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><?php esc_html_e( 'Allow writes', 'jorapress' ); ?></th>
				<td>
					<label><input type="checkbox" name="jorapress_allow_writes" value="1" <?php checked( $safety->writes_allowed() ); ?>>
					<?php esc_html_e( 'Permit database/file writes (read-only by default).', 'jorapress' ); ?></label>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Allow WP-CLI', 'jorapress' ); ?></th>
				<td>
					<label><input type="checkbox" name="jorapress_allow_wp_cli" value="1" <?php checked( $safety->wp_cli_allowed() ); ?>>
					<?php esc_html_e( 'Allow the wp_cli tool (requires host shell access).', 'jorapress' ); ?></label>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Require approval', 'jorapress' ); ?></th>
				<td>
					<label><input type="checkbox" name="jorapress_require_approval" value="1" <?php checked( (bool) get_option( 'jorapress_require_approval', 1 ) ); ?>>
					<?php esc_html_e( 'Pause the chat agent for approval before each write.', 'jorapress' ); ?></label>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Rate limit', 'jorapress' ); ?></th>
				<td><input type="number" name="jorapress_rate_limit" value="<?php echo esc_attr( (string) get_option( 'jorapress_rate_limit', 60 ) ); ?>" min="0" class="small-text"> <?php esc_html_e( 'tool calls / minute / user (0 = unlimited).', 'jorapress' ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Agent max steps', 'jorapress' ); ?></th>
				<td><input type="number" name="jorapress_agent_max_steps" value="<?php echo esc_attr( (string) get_option( 'jorapress_agent_max_steps', 25 ) ); ?>" min="1" class="small-text"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Production override', 'jorapress' ); ?></th>
				<td>
					<label><input type="checkbox" name="jorapress_ack_production_risk" value="1" <?php checked( $safety->production_ack() ); ?>>
					<?php esc_html_e( 'I understand the risk and want to allow AI tools on a production-looking site.', 'jorapress' ); ?></label>
					<p class="description"><?php esc_html_e( 'Strongly discouraged. Use dev/staging.', 'jorapress' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Chat panel model', 'jorapress' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><?php esc_html_e( 'Provider', 'jorapress' ); ?></th>
				<td>
					<select name="jorapress_provider">
						<?php foreach ( $pm->all() as $p ) : ?>
							<option value="<?php echo esc_attr( $p->id() ); ?>" <?php selected( $provider, $p->id() ); ?>><?php echo esc_html( $p->label() ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Model', 'jorapress' ); ?></th>
				<td><input type="text" name="jorapress_model" value="<?php echo esc_attr( (string) get_option( 'jorapress_model', '' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $pm->active() ? $pm->active()->default_model() : '' ); ?>"></td>
			</tr>
			<?php foreach ( $pm->all() as $p ) : ?>
			<tr>
				<th><?php echo esc_html( sprintf( /* translators: provider */ __( '%s API key', 'jorapress' ), $p->label() ) ); ?></th>
				<td>
					<input type="password" name="jorapress_key_input_<?php echo esc_attr( $p->id() ); ?>" class="regular-text" autocomplete="new-password"
						placeholder="<?php echo $pm->has_api_key( $p->id() ) ? esc_attr__( '•••••• (saved — leave blank to keep)', 'jorapress' ) : esc_attr__( 'Paste key (stored encrypted)', 'jorapress' ); ?>">
				</td>
			</tr>
			<?php endforeach; ?>
		</table>

		<h2><?php esc_html_e( 'Site Doctor', 'jorapress' ); ?></h2>
		<table class="form-table" role="presentation">
			<?php $schedule = (string) get_option( 'jorapress_doctor_schedule', 'off' ); ?>
			<tr>
				<th><?php esc_html_e( 'Scheduled audits', 'jorapress' ); ?></th>
				<td>
					<select name="jorapress_doctor_schedule">
						<option value="off" <?php selected( $schedule, 'off' ); ?>><?php esc_html_e( 'Off', 'jorapress' ); ?></option>
						<option value="daily" <?php selected( $schedule, 'daily' ); ?>><?php esc_html_e( 'Daily', 'jorapress' ); ?></option>
						<option value="weekly" <?php selected( $schedule, 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'jorapress' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'Run read-only Bug / Performance / SEO / Health scans on a schedule and track the health score over time.', 'jorapress' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Report email', 'jorapress' ); ?></th>
				<td><input type="email" name="jorapress_doctor_email" value="<?php echo esc_attr( (string) get_option( 'jorapress_doctor_email', get_option( 'admin_email' ) ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( (string) get_option( 'admin_email' ) ); ?>">
				<p class="description"><?php esc_html_e( 'Where to send the audit summary (leave blank to skip email).', 'jorapress' ); ?></p></td>
			</tr>
		</table>

		<?php submit_button( __( 'Save settings', 'jorapress' ) ); ?>
	</form>

	<hr>
	<h2><?php esc_html_e( 'Pro licence', 'jorapress' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'jorapress_license' ); ?>
		<input type="hidden" name="action" value="jorapress_license">
		<p>
			<input type="text" name="jorapress_license_key" class="regular-text" value="<?php echo esc_attr( License::license_key() ); ?>" placeholder="<?php esc_attr_e( 'Licence key', 'jorapress' ); ?>">
			<?php if ( License::is_pro() ) : ?>
				<button class="button" name="license_action" value="deactivate"><?php esc_html_e( 'Deactivate', 'jorapress' ); ?></button>
				<span class="jorapress-badge jorapress-badge--pro"><?php esc_html_e( 'PRO active', 'jorapress' ); ?></span>
			<?php else : ?>
				<button class="button button-primary" name="license_action" value="activate"><?php esc_html_e( 'Activate', 'jorapress' ); ?></button>
			<?php endif; ?>
		</p>
		<p class="description"><?php esc_html_e( 'Pro unlocks version-accurate builder skills, project memory and priority schema updates.', 'jorapress' ); ?></p>
	</form>
</div>
