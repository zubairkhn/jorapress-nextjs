<?php
/**
 * Dashboard view. Master switch, status at a glance, quick links.
 *
 * @package JoraPress
 * @var \JoraPress\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$enabled    = $safety->is_enabled();
$is_prod    = $safety->looks_like_production();
$prod_ack   = $safety->production_ack();
$writes     = $safety->writes_allowed();
?>
<div class="wrap jorapress-wrap">
	<h1><span class="dashicons dashicons-superhero"></span> <?php esc_html_e( 'JoraPress — AI WordPress Builder', 'jorapress' ); ?></h1>
	<p class="jorapress-tagline"><?php esc_html_e( 'A secure bridge that lets an AI agent build and design this site. Bring your own agent over MCP, or use the built-in chat panel.', 'jorapress' ); ?></p>

	<?php if ( $is_prod && ! $prod_ack ) : ?>
		<div class="notice notice-error inline"><p>
			<strong><?php esc_html_e( 'Production site detected.', 'jorapress' ); ?></strong>
			<?php esc_html_e( 'JoraPress is meant for dev/staging. Tool calls are blocked until you acknowledge the risk in Settings.', 'jorapress' ); ?>
		</p></div>
	<?php endif; ?>

	<div class="jorapress-cards">
		<div class="jorapress-card jorapress-card--switch">
			<h2><?php esc_html_e( 'AI abilities', 'jorapress' ); ?></h2>
			<p class="jorapress-status <?php echo $enabled ? 'on' : 'off'; ?>">
				<?php echo $enabled ? esc_html__( 'ENABLED', 'jorapress' ) : esc_html__( 'DISABLED', 'jorapress' ); ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'jorapress_toggle' ); ?>
				<input type="hidden" name="action" value="jorapress_toggle">
				<input type="hidden" name="enabled" value="<?php echo $enabled ? '0' : '1'; ?>">
				<button class="button button-<?php echo $enabled ? 'secondary' : 'primary'; ?> button-hero">
					<?php echo $enabled ? esc_html__( 'Disable all AI (kill switch)', 'jorapress' ) : esc_html__( 'Enable AI abilities', 'jorapress' ); ?>
				</button>
			</form>
		</div>

		<div class="jorapress-card">
			<h2><?php esc_html_e( 'Status', 'jorapress' ); ?></h2>
			<ul class="jorapress-statuslist">
				<li><?php esc_html_e( 'Environment', 'jorapress' ); ?>: <strong><?php echo esc_html( function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'unknown' ); ?></strong></li>
				<li><?php esc_html_e( 'Looks like production', 'jorapress' ); ?>: <strong><?php echo $is_prod ? esc_html__( 'yes', 'jorapress' ) : esc_html__( 'no', 'jorapress' ); ?></strong></li>
				<li><?php esc_html_e( 'Writes allowed', 'jorapress' ); ?>: <strong><?php echo $writes ? esc_html__( 'yes', 'jorapress' ) : esc_html__( 'no (read-only)', 'jorapress' ); ?></strong></li>
				<li><?php esc_html_e( 'MCP endpoint', 'jorapress' ); ?>: <code><?php echo esc_html( rest_url( JORAPRESS_REST_NAMESPACE . '/mcp' ) ); ?></code></li>
			</ul>
		</div>

		<div class="jorapress-card">
			<h2><?php esc_html_e( 'Get started', 'jorapress' ); ?></h2>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=jorapress-chat' ) ); ?>"><?php esc_html_e( 'Open Chat', 'jorapress' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=jorapress-connect' ) ); ?>"><?php esc_html_e( 'Connect an AI client', 'jorapress' ); ?></a>
			</p>
			<p class="description"><?php esc_html_e( 'Non-technical? Use Chat. Developer? Connect Claude Code / Cursor / Windsurf over MCP.', 'jorapress' ); ?></p>
		</div>
	</div>
</div>
