<?php
/**
 * Admin UI: menu, page routing, asset loading, settings registration and the
 * activation security notice.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Admin;

use JoraPress\Core\Safety;
use JoraPress\Core\AuditLog;
use JoraPress\Licensing\License;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin {

	private Settings $settings;

	public function __construct(
		private Safety $safety,
		private AuditLog $audit
	) {
		$this->settings = new Settings( $safety );
	}

	public function hooks(): void {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this->settings, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'profile_assets' ) );
		add_action( 'admin_notices', array( $this, 'notices' ) );
		add_action( 'init', array( License::class, 'register_updates' ) );
	}

	public function menu(): void {
		$cap = JORAPRESS_CAPABILITY;

		add_menu_page(
			__( 'JoraPress', 'jorapress' ),
			__( 'JoraPress Builder', 'jorapress' ),
			$cap,
			'jorapress',
			array( $this, 'render_dashboard' ),
			'dashicons-superhero',
			58
		);

		$pages = array(
			'jorapress'          => __( 'Dashboard', 'jorapress' ),
			'jorapress-chat'     => __( 'Chat', 'jorapress' ),
			'jorapress-doctor'   => __( 'Site Doctor', 'jorapress' ),
			'jorapress-connect'  => __( 'Connect (MCP)', 'jorapress' ),
			'jorapress-sandbox'  => __( 'Sandbox', 'jorapress' ),
			'jorapress-audit'    => __( 'Audit Log', 'jorapress' ),
			'jorapress-settings' => __( 'Settings', 'jorapress' ),
		);

		$callbacks = array(
			'jorapress-chat'     => 'render_chat',
			'jorapress-doctor'   => 'render_doctor',
			'jorapress-connect'  => 'render_connect',
			'jorapress-sandbox'  => 'render_sandbox',
			'jorapress-audit'    => 'render_audit',
			'jorapress-settings' => 'render_settings',
		);

		foreach ( $pages as $slug => $title ) {
			if ( 'jorapress' === $slug ) {
				continue;
			}
			add_submenu_page( 'jorapress', $title, $title, $cap, $slug, array( $this, $callbacks[ $slug ] ) );
		}

		// Rename the first submenu entry to "Dashboard".
		add_submenu_page( 'jorapress', __( 'Dashboard', 'jorapress' ), __( 'Dashboard', 'jorapress' ), $cap, 'jorapress', array( $this, 'render_dashboard' ) );
	}

	public function assets( string $hook ): void {
		if ( ! str_contains( $hook, 'jorapress' ) ) {
			return;
		}

		wp_enqueue_style( 'jorapress-admin', JORAPRESS_URL . 'admin/css/admin.css', array(), JORAPRESS_VERSION );

		wp_enqueue_script( 'jorapress-admin', JORAPRESS_URL . 'admin/js/admin.js', array( 'wp-api-fetch' ), JORAPRESS_VERSION, true );
		wp_enqueue_script( 'jorapress-doctor', JORAPRESS_URL . 'admin/js/doctor.js', array( 'jorapress-admin' ), JORAPRESS_VERSION, true );
		wp_localize_script(
			'jorapress-admin',
			'JoraPress',
			array(
				'root'     => esc_url_raw( rest_url( JORAPRESS_REST_NAMESPACE ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'enabled'  => $this->safety->is_enabled(),
				'strings'  => array(
					'thinking' => __( 'Thinking…', 'jorapress' ),
					'approve'  => __( 'Approve', 'jorapress' ),
					'deny'     => __( 'Deny', 'jorapress' ),
				),
			)
		);
	}

	/**
	 * Enhance WordPress core's Application Passwords screen so a freshly created
	 * password is also offered as a ready-to-use Base64 HTTP Basic value. Core
	 * only shows the space-chunked raw password, which most people then have to
	 * Base64-encode by hand before they can use it with the MCP endpoint / REST
	 * API. We compute it in the browser (the password never returns to PHP).
	 */
	public function profile_assets( string $hook ): void {
		if ( 'profile.php' !== $hook && 'user-edit.php' !== $hook ) {
			return;
		}

		$user_id = ( 'user-edit.php' === $hook && isset( $_GET['user_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			? (int) $_GET['user_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: get_current_user_id();

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		wp_enqueue_script( 'jorapress-app-password', JORAPRESS_URL . 'admin/js/app-password.js', array(), JORAPRESS_VERSION, true );
		wp_localize_script(
			'jorapress-app-password',
			'JORAPRESS_APP_PW',
			array(
				'login'   => $user->user_login,
				'strings' => array(
					'header' => __( 'Authorization header (ready to use — Base64 of username:password):', 'jorapress' ),
					'token'  => __( 'Base64 token only:', 'jorapress' ),
					'copy'   => __( 'Copy', 'jorapress' ),
					'copied' => __( 'Copied!', 'jorapress' ),
				),
			)
		);
	}

	public function notices(): void {
		if ( get_transient( 'jorapress_activation_notice' ) ) {
			delete_transient( 'jorapress_activation_notice' );
			printf(
				'<div class="notice notice-warning"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'JoraPress installed.', 'jorapress' ),
				esc_html__( 'This plugin enables remote code execution and is intended for dev/staging only. AI abilities are OFF until you enable them in JoraPress → Dashboard.', 'jorapress' )
			);
		}

		if ( $this->safety->looks_like_production() && ! $this->safety->production_ack() && $this->safety->is_enabled() ) {
			printf(
				'<div class="notice notice-error"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'JoraPress production warning:', 'jorapress' ),
				esc_html__( 'This looks like a production site. AI tool calls are blocked until you acknowledge the risk in JoraPress → Settings.', 'jorapress' )
			);
		}
	}

	// --- Page renderers ----------------------------------------------------

	public function render_dashboard(): void {
		$this->view( 'dashboard' );
	}

	public function render_chat(): void {
		$this->view( 'chat' );
	}

	public function render_doctor(): void {
		$this->view( 'doctor' );
	}

	public function render_connect(): void {
		$this->view( 'connect' );
	}

	public function render_sandbox(): void {
		$this->view( 'sandbox' );
	}

	public function render_audit(): void {
		$this->view( 'audit' );
	}

	public function render_settings(): void {
		$this->view( 'settings' );
	}

	private function view( string $name ): void {
		$file = JORAPRESS_DIR . 'includes/admin/views/' . $name . '.php';
		if ( is_readable( $file ) ) {
			$safety   = $this->safety;
			$audit    = $this->audit;
			$settings = $this->settings;
			include $file;
		}
	}
}
