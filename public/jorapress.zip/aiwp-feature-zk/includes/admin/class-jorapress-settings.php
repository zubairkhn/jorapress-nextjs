<?php
/**
 * Settings handling. Toggles, gating, model provider + encrypted API keys,
 * production acknowledgement and licence. Saved via a single nonce-protected
 * admin-post handler so API keys can be encrypted before storage.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Admin;

use JoraPress\Core\Safety;
use JoraPress\Core\Reporter;
use JoraPress\Agent\ProviderManager;
use JoraPress\Licensing\License;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Settings {

	public function __construct( private Safety $safety ) {}

	public function register(): void {
		add_action( 'admin_post_jorapress_save_settings', array( $this, 'handle_save' ) );
		add_action( 'admin_post_jorapress_toggle', array( $this, 'handle_toggle' ) );
		add_action( 'admin_post_jorapress_license', array( $this, 'handle_license' ) );
	}

	/**
	 * Master kill-switch toggle (also reachable from the dashboard).
	 */
	public function handle_toggle(): void {
		$this->guard( 'jorapress_toggle' );
		$on = isset( $_POST['enabled'] ) && '1' === $_POST['enabled'];
		$this->safety->set_enabled( $on );
		$this->redirect_back();
	}

	public function handle_save(): void {
		$this->guard( 'jorapress_save_settings' );

		$bools = array(
			'jorapress_allow_writes',
			'jorapress_allow_wp_cli',
			'jorapress_require_approval',
			'jorapress_ack_production_risk',
		);
		foreach ( $bools as $key ) {
			update_option( $key, isset( $_POST[ $key ] ) ? 1 : 0 );
		}

		update_option( 'jorapress_rate_limit', max( 0, (int) ( $_POST['jorapress_rate_limit'] ?? 60 ) ) );
		update_option( 'jorapress_agent_max_steps', max( 1, (int) ( $_POST['jorapress_agent_max_steps'] ?? 25 ) ) );

		$provider = sanitize_key( (string) ( $_POST['jorapress_provider'] ?? 'anthropic' ) );
		update_option( 'jorapress_provider', $provider );
		update_option( 'jorapress_model', sanitize_text_field( wp_unslash( (string) ( $_POST['jorapress_model'] ?? '' ) ) ) );

		// Site Doctor scheduled audits. Reschedule the cron event if the cadence
		// changed.
		$old_schedule = (string) get_option( 'jorapress_doctor_schedule', 'off' );
		$new_schedule = in_array( (string) ( $_POST['jorapress_doctor_schedule'] ?? 'off' ), array( 'off', 'daily', 'weekly' ), true )
			? (string) $_POST['jorapress_doctor_schedule']
			: 'off';
		update_option( 'jorapress_doctor_schedule', $new_schedule );
		update_option( 'jorapress_doctor_email', sanitize_email( (string) ( $_POST['jorapress_doctor_email'] ?? '' ) ) );
		if ( $old_schedule !== $new_schedule ) {
			Reporter::reschedule();
		}

		// API keys — encrypt before storage, ignore empty (so existing keys stay).
		$pm = new ProviderManager();
		foreach ( $pm->all() as $p ) {
			$field = 'jorapress_key_input_' . $p->id();
			if ( ! empty( $_POST[ $field ] ) ) {
				$pm->set_api_key( $p->id(), sanitize_text_field( wp_unslash( (string) $_POST[ $field ] ) ) );
			}
		}

		$this->redirect_back( 'saved' );
	}

	public function handle_license(): void {
		$this->guard( 'jorapress_license' );
		$action = (string) ( $_POST['license_action'] ?? '' );

		if ( 'deactivate' === $action ) {
			License::deactivate();
		} else {
			License::activate( sanitize_text_field( wp_unslash( (string) ( $_POST['jorapress_license_key'] ?? '' ) ) ) );
		}

		$this->redirect_back();
	}

	private function guard( string $action ): void {
		if ( ! current_user_can( JORAPRESS_CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'jorapress' ) );
		}
		check_admin_referer( $action );
	}

	private function redirect_back( string $flag = '' ): void {
		$url = wp_get_referer() ?: admin_url( 'admin.php?page=jorapress-settings' );
		if ( '' !== $flag ) {
			$url = add_query_arg( 'jorapress_msg', $flag, $url );
		}
		wp_safe_redirect( $url );
		exit;
	}
}
