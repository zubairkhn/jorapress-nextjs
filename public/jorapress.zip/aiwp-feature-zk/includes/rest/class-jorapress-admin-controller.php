<?php
/**
 * REST controller for the admin chat panel and dashboard actions. Cookie +
 * nonce authenticated, gated to the AI capability.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Rest;

use JoraPress\Core\ToolRouter;
use JoraPress\Core\Safety;
use JoraPress\Core\AuditLog;
use JoraPress\Core\Sandbox;
use JoraPress\Skills\SkillsManager;
use JoraPress\Agent\Loop;
use JoraPress\Agent\ProviderManager;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminController {

	public function __construct(
		private ToolRouter $router,
		private Safety $safety,
		private AuditLog $audit,
		private SkillsManager $skills
	) {}

	public function hooks(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function permission(): bool {
		return current_user_can( JORAPRESS_CAPABILITY );
	}

	public function register_routes(): void {
		$ns = JORAPRESS_REST_NAMESPACE;

		register_rest_route(
			$ns,
			'/chat/run',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'chat_run' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/chat/approve',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'chat_approve' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'status' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/sandbox',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'sandbox_list' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/sandbox/action',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'sandbox_action' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/audit',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'audit_list' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);
	}

	private function loop(): Loop {
		return new Loop( $this->router, new ProviderManager(), $this->skills );
	}

	public function chat_run( WP_REST_Request $request ): WP_REST_Response {
		$messages = (array) $request->get_param( 'messages' );
		$prompt   = (string) $request->get_param( 'prompt' );

		$result = $this->loop()->run( $messages, $prompt );
		return new WP_REST_Response( $result );
	}

	/**
	 * Execute (or deny) tool calls the user approved, then return for the UI to
	 * continue the loop with a fresh /chat/run (empty prompt).
	 */
	public function chat_approve( WP_REST_Request $request ): WP_REST_Response {
		$messages = (array) $request->get_param( 'messages' );
		$approved = (array) $request->get_param( 'approved' );
		$denied   = (array) $request->get_param( 'denied' );

		$steps = array();

		if ( $approved ) {
			$messages = $this->loop()->execute_tool_calls( $messages, $approved, $steps );
		}

		// Record denials as tool results so the model knows they were rejected.
		foreach ( $denied as $tc ) {
			$messages[] = array(
				'role'         => 'tool',
				'tool_call_id' => $tc['id'] ?? '',
				'name'         => $tc['name'] ?? '',
				'content'      => wp_json_encode( array( 'ok' => false, 'error' => 'User denied this action.' ) ),
			);
		}

		return new WP_REST_Response(
			array(
				'status'   => 'executed',
				'messages' => $messages,
				'steps'    => $steps,
			)
		);
	}

	public function status(): WP_REST_Response {
		$pm = new ProviderManager();

		return new WP_REST_Response(
			array(
				'enabled'          => $this->safety->is_enabled(),
				'writes_allowed'   => $this->safety->writes_allowed(),
				'looks_production' => $this->safety->looks_like_production(),
				'production_ack'   => $this->safety->production_ack(),
				'require_approval' => (bool) get_option( 'jorapress_require_approval', 1 ),
				'provider'         => $pm->active() ? $pm->active()->id() : null,
				'model'            => $pm->active_model(),
				'has_key'          => $pm->active() ? $pm->has_api_key( $pm->active()->id() ) : false,
				'tools'            => array_keys( $this->router->all() ),
			)
		);
	}

	public function sandbox_list(): WP_REST_Response {
		return new WP_REST_Response( array( 'files' => Sandbox::list_files() ) );
	}

	public function sandbox_action( WP_REST_Request $request ): WP_REST_Response {
		$action = (string) $request->get_param( 'action_type' );
		$path   = (string) $request->get_param( 'rel_path' );

		switch ( $action ) {
			case 'revert':
				Sandbox::revert( $path );
				break;
			case 'disable':
				Sandbox::set_disabled( $path, true );
				break;
			case 'enable':
				Sandbox::set_disabled( $path, false );
				break;
			default:
				return new WP_REST_Response( array( 'ok' => false, 'error' => 'Unknown action.' ), 400 );
		}

		return new WP_REST_Response( array( 'ok' => true, 'files' => Sandbox::list_files() ) );
	}

	public function audit_list( WP_REST_Request $request ): WP_REST_Response {
		$limit = (int) ( $request->get_param( 'limit' ) ?: 100 );
		return new WP_REST_Response( array( 'entries' => $this->audit->recent( $limit ) ) );
	}
}
