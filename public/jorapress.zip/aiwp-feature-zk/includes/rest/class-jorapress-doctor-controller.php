<?php
/**
 * REST controller for the "Site Doctor" dashboard. Runs the read-only scanners,
 * aggregates a health score, and dispatches fixers through the tool router (so
 * the full safety pipeline — write-gating, backups, audit — applies to writes).
 *
 * Scans are read-only and run regardless of the master switch so a site can be
 * diagnosed even with AI abilities off. Fixes always go through the router and
 * therefore respect the master switch, production guard and write gating.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Rest;

use JoraPress\Core\ToolRouter;
use JoraPress\Core\Safety;
use JoraPress\Core\AuditLog;
use JoraPress\Core\SafetyException;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DoctorController {

	/** domain => scanner tool name. */
	private const SCANNERS = array(
		'health'      => 'site_health',
		'bugs'        => 'error_scan',
		'performance' => 'perf_scan',
		'seo'         => 'seo_scan',
	);

	private const FIXERS = array( 'bug_fix', 'perf_fix', 'seo_fix' );

	private const HISTORY_OPTION = 'jorapress_doctor_history';
	private const HISTORY_MAX    = 60;

	public function __construct(
		private ToolRouter $router,
		private Safety $safety,
		private AuditLog $audit
	) {}

	public function hooks(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function permission(): bool {
		return current_user_can( JORAPRESS_CAPABILITY );
	}

	public function register_routes(): void {
		$ns = JORAPRESS_REST_NAMESPACE;

		register_rest_route(
			$ns,
			'/doctor/scan',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'scan' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/doctor/fix',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'fix' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			$ns,
			'/doctor/history',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'history' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);
	}

	/**
	 * Run every scanner, aggregate issues, compute a health score, store a
	 * history point. Read-only — bypasses the master switch on purpose.
	 */
	public function scan(): WP_REST_Response {
		$domains    = array();
		$all_issues = array();

		foreach ( self::SCANNERS as $domain => $tool_name ) {
			if ( ! $this->router->has( $tool_name ) ) {
				continue;
			}
			$result            = $this->router->all()[ $tool_name ]->run( array() );
			$domains[ $domain ] = $result;
			foreach ( (array) ( $result['issues'] ?? array() ) as $issue ) {
				$all_issues[] = $issue;
			}
		}

		$score = self::score( $all_issues );
		$this->record_history( $score, $all_issues );

		return new WP_REST_Response(
			array(
				'ok'        => true,
				'score'     => $score,
				'counts'    => $this->counts( $all_issues ),
				'domains'   => $domains,
				'generated' => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Dispatch a fixer through the router (full safety pipeline). The body must
	 * be { tool: "perf_fix", args: { action, dry_run, ... } }.
	 */
	public function fix( WP_REST_Request $request ): WP_REST_Response {
		$tool = (string) $request->get_param( 'tool' );
		$args = (array) $request->get_param( 'args' );

		if ( ! in_array( $tool, self::FIXERS, true ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'Unknown or disallowed fixer.' ), 400 );
		}

		try {
			$result = $this->router->call( $tool, $args, 'doctor' );
		} catch ( SafetyException $e ) {
			// Surface gating reasons (master switch off, writes disabled, prod) as
			// a normal payload so the UI can show a helpful message.
			return new WP_REST_Response( array( 'ok' => false, 'error' => $e->getMessage(), 'gated' => true ) );
		}

		return new WP_REST_Response( $result );
	}

	public function history(): WP_REST_Response {
		return new WP_REST_Response( array( 'ok' => true, 'history' => $this->get_history() ) );
	}

	/**
	 * Weighted 0–100 health score from a flat issue list.
	 *
	 * @param array<int,array<string,mixed>> $issues
	 */
	public static function score( array $issues ): int {
		$penalty = 0;
		foreach ( $issues as $i ) {
			$penalty += match ( (string) ( $i['severity'] ?? '' ) ) {
				'critical'       => 15,
				'warning'        => 5,
				'recommendation' => 2,
				default          => 0,
			};
		}
		return max( 0, min( 100, 100 - $penalty ) );
	}

	/** @param array<int,array<string,mixed>> $issues */
	private function counts( array $issues ): array {
		$out = array( 'critical' => 0, 'warning' => 0, 'recommendation' => 0, 'total' => count( $issues ) );
		foreach ( $issues as $i ) {
			$sev = (string) ( $i['severity'] ?? '' );
			if ( isset( $out[ $sev ] ) ) {
				++$out[ $sev ];
			}
		}
		return $out;
	}

	/** @param array<int,array<string,mixed>> $issues */
	private function record_history( int $score, array $issues ): void {
		$history   = $this->get_history();
		$history[] = array(
			'time'   => current_time( 'mysql' ),
			'score'  => $score,
			'counts' => $this->counts( $issues ),
		);
		if ( count( $history ) > self::HISTORY_MAX ) {
			$history = array_slice( $history, -self::HISTORY_MAX );
		}
		update_option( self::HISTORY_OPTION, $history, false );
	}

	/** @return array<int,array<string,mixed>> */
	private function get_history(): array {
		return (array) get_option( self::HISTORY_OPTION, array() );
	}
}
