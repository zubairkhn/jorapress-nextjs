<?php
/**
 * Minimal JSON-RPC 2.0 helpers for the MCP transport.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress\Mcp;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class JsonRpc {

	public const PARSE_ERROR      = -32700;
	public const INVALID_REQUEST  = -32600;
	public const METHOD_NOT_FOUND = -32601;
	public const INVALID_PARAMS   = -32602;
	public const INTERNAL_ERROR   = -32603;

	/**
	 * @param mixed $result
	 * @param mixed $id
	 * @return array<string,mixed>
	 */
	public static function result( $result, $id ): array {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'result'  => $result,
		);
	}

	/**
	 * @param mixed $id
	 * @return array<string,mixed>
	 */
	public static function error( int $code, string $message, $id = null, $data = null ): array {
		$error = array(
			'code'    => $code,
			'message' => $message,
		);
		if ( null !== $data ) {
			$error['data'] = $data;
		}
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'error'   => $error,
		);
	}

	public static function is_notification( array $message ): bool {
		// A request without an id is a notification (no response expected).
		return ! array_key_exists( 'id', $message );
	}
}
