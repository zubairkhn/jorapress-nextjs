<?php
/**
 * Activation routine: creates DB tables, default options and the sandbox dir.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

namespace JoraPress;

use JoraPress\Core\Sandbox;
use JoraPress\Core\Reporter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Activator {

	public static function activate(): void {
		self::create_tables();
		self::set_defaults();
		Sandbox::ensure_dir();

		// Match the Site Doctor cron event to the saved cadence (off by default).
		Reporter::reschedule();

		// Surface the security notice on next admin load.
		set_transient( 'jorapress_activation_notice', 1, 60 );

		flush_rewrite_rules();
	}

	private static function create_tables(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$audit   = $wpdb->prefix . 'jorapress_audit_log';
		$memory  = $wpdb->prefix . 'jorapress_memory';
		$sandbox = $wpdb->prefix . 'jorapress_sandbox_files';

		$sql = array();

		// Immutable audit trail: who, when, what tool, what code, result.
		$sql[] = "CREATE TABLE {$audit} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			front_door VARCHAR(20) NOT NULL DEFAULT 'mcp',
			tool VARCHAR(64) NOT NULL DEFAULT '',
			args LONGTEXT NULL,
			result_summary LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'ok',
			ip VARCHAR(64) NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY user_id (user_id),
			KEY tool (tool)
		) {$charset};";

		// Session / project memory for the agent (Phase 3).
		$sql[] = "CREATE TABLE {$memory} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scope VARCHAR(64) NOT NULL DEFAULT 'global',
			mem_key VARCHAR(191) NOT NULL,
			mem_value LONGTEXT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY scope_key (scope, mem_key)
		) {$charset};";

		// Registry of AI-written sandbox files for one-click revert.
		$sql[] = "CREATE TABLE {$sandbox} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			rel_path VARCHAR(255) NOT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			revision INT UNSIGNED NOT NULL DEFAULT 1,
			disabled TINYINT(1) NOT NULL DEFAULT 0,
			fatal TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY rel_path (rel_path)
		) {$charset};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	private static function set_defaults(): void {
		$defaults = array(
			'jorapress_enabled'            => 0,        // Master kill switch OFF by default.
			'jorapress_allow_writes'       => 0,        // db/file writes gated by default.
			'jorapress_allow_wp_cli'       => 0,
			'jorapress_rate_limit'         => 60,       // tool calls per minute per user.
			'jorapress_require_approval'   => 1,        // chat panel approval gate.
			'jorapress_agent_max_steps'    => 25,
			'jorapress_ack_production_risk'=> 0,
			'jorapress_provider'           => 'anthropic',
			'jorapress_model'              => 'claude-sonnet-4-6',
			'jorapress_doctor_schedule'    => 'off',      // off | daily | weekly.
			'jorapress_doctor_email'       => get_option( 'admin_email' ),
		);

		foreach ( $defaults as $key => $value ) {
			if ( false === get_option( $key, false ) ) {
				add_option( $key, $value );
			}
		}
	}
}
