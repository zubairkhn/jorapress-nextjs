<?php
/**
 * Uninstall routine. Removes JoraPress options and tables. Does NOT delete the
 * sandbox directory contents automatically — those may be live site files; the
 * operator can remove wp-content/uploads/jorapress-sandbox/ manually.
 *
 * @package JoraPress
 */

declare( strict_types=1 );

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$options = array(
	'jorapress_enabled',
	'jorapress_allow_writes',
	'jorapress_allow_wp_cli',
	'jorapress_rate_limit',
	'jorapress_require_approval',
	'jorapress_agent_max_steps',
	'jorapress_ack_production_risk',
	'jorapress_provider',
	'jorapress_model',
	'jorapress_license_key',
	'jorapress_license_active',
	'jorapress_crashguard_pending',
	'jorapress_key_anthropic',
	'jorapress_key_openai',
	'jorapress_key_gemini',
	'jorapress_key_openrouter',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

foreach ( array( 'jorapress_audit_log', 'jorapress_memory', 'jorapress_sandbox_files' ) as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" ); // phpcs:ignore WordPress.DB
}
