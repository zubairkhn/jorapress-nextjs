/**
 * Site Doctor UI. Runs the diagnostic scanners via the REST API, renders a
 * health score and per-domain issue lists, and applies (or previews) fixes.
 * Reuses the AIWP config (root, nonce) localized by admin.js.
 *
 * @package AIWP
 */
( function () {
	'use strict';

	var root = document.getElementById( 'aiwp-doctor' );
	if ( ! root ) {
		return;
	}

	var cfg = window.AIWP || {};
	var api = window.wp && window.wp.apiFetch ? window.wp.apiFetch : null;

	var DOMAIN_LABELS = {
		bugs: 'Bugs & Errors',
		performance: 'Performance',
		seo: 'SEO',
		health: 'Site Health'
	};
	var SEVERITY_ORDER = { critical: 0, warning: 1, recommendation: 2 };

	function request( path, method, data ) {
		var url = cfg.root + path;
		if ( api ) {
			return api( { url: url, method: method || 'GET', data: data || undefined } );
		}
		return fetch( url, {
			method: method || 'GET',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			body: data ? JSON.stringify( data ) : undefined,
			credentials: 'same-origin'
		} ).then( function ( r ) { return r.json(); } );
	}

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( text !== undefined ) { n.textContent = text; }
		return n;
	}

	var scanBtn = document.getElementById( 'aiwp-doctor-scan' );
	var meta = document.getElementById( 'aiwp-doctor-meta' );
	var scoreBox = document.getElementById( 'aiwp-doctor-score' );
	var scoreNum = document.getElementById( 'aiwp-score-num' );
	var scoreRing = document.getElementById( 'aiwp-score-ring' );
	var scoreCounts = document.getElementById( 'aiwp-score-counts' );
	var results = document.getElementById( 'aiwp-doctor-results' );

	function scoreColor( score ) {
		if ( score >= 85 ) { return '#00a32a'; }
		if ( score >= 60 ) { return '#dba617'; }
		return '#d63638';
	}

	function renderScore( data ) {
		scoreBox.hidden = false;
		scoreNum.textContent = data.score;
		var color = scoreColor( data.score );
		scoreRing.style.background =
			'conic-gradient(' + color + ' ' + ( data.score * 3.6 ) + 'deg, #e0e0e0 0deg)';
		scoreNum.style.color = color;

		var c = data.counts || {};
		scoreCounts.innerHTML = '';
		[
			[ 'critical', 'Critical', '#d63638' ],
			[ 'warning', 'Warnings', '#dba617' ],
			[ 'recommendation', 'Recommendations', '#2271b1' ]
		].forEach( function ( row ) {
			var line = el( 'div', 'aiwp-count-line' );
			var dot = el( 'span', 'aiwp-dot' );
			dot.style.background = row[2];
			line.appendChild( dot );
			line.appendChild( el( 'span', null, ( c[ row[0] ] || 0 ) + ' ' + row[1] ) );
			scoreCounts.appendChild( line );
		} );
	}

	function badge( severity ) {
		var b = el( 'span', 'aiwp-sev aiwp-sev--' + severity, severity );
		return b;
	}

	function fixArgsLabel( issue ) {
		if ( ! issue.fix_args ) { return ''; }
		return issue.fix_args.action ? ( ' (' + issue.fix_args.action + ')' ) : '';
	}

	function renderIssue( issue ) {
		var card = el( 'div', 'aiwp-issue aiwp-issue--' + issue.severity );

		var head = el( 'div', 'aiwp-issue__head' );
		head.appendChild( badge( issue.severity ) );
		head.appendChild( el( 'strong', 'aiwp-issue__title', issue.title ) );
		card.appendChild( head );

		card.appendChild( el( 'p', 'aiwp-issue__fix', issue.suggested_fix ) );

		if ( issue.evidence && Object.keys( issue.evidence ).length ) {
			var det = el( 'details', 'aiwp-issue__evidence' );
			det.appendChild( el( 'summary', null, 'Details' ) );
			var pre = el( 'pre' );
			pre.textContent = JSON.stringify( issue.evidence, null, 2 );
			det.appendChild( pre );
			card.appendChild( det );
		}

		if ( issue.auto_fixable && issue.fix_tool && issue.fix_args ) {
			var actions = el( 'div', 'aiwp-issue__actions' );

			var preview = el( 'button', 'button button-secondary', 'Preview fix' );
			var apply = el( 'button', 'button button-primary', 'Apply fix' + fixArgsLabel( issue ) );
			var out = el( 'span', 'aiwp-issue__result' );

			preview.addEventListener( 'click', function () {
				runFix( issue, true, out, [ preview, apply ] );
			} );
			apply.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Apply this fix now? Affected data is snapshotted and reversible.' ) ) { return; }
				runFix( issue, false, out, [ preview, apply ] );
			} );

			actions.appendChild( preview );
			actions.appendChild( apply );
			actions.appendChild( out );
			card.appendChild( actions );
		} else if ( issue.fix_tool ) {
			card.appendChild( el( 'p', 'aiwp-issue__manual', 'Manual fix — see suggestion above.' ) );
		}

		return card;
	}

	function runFix( issue, dryRun, out, buttons ) {
		var args = Object.assign( {}, issue.fix_args, { dry_run: dryRun } );
		buttons.forEach( function ( b ) { b.disabled = true; } );
		out.textContent = dryRun ? 'Previewing…' : 'Applying…';

		request( '/doctor/fix', 'POST', { tool: issue.fix_tool, args: args } ).then( function ( res ) {
			buttons.forEach( function ( b ) { b.disabled = false; } );
			if ( ! res || res.ok === false ) {
				out.textContent = '⚠ ' + ( res && res.error ? res.error : 'Failed.' );
				out.style.color = '#d63638';
				return;
			}
			out.style.color = res.dry_run ? '#2271b1' : '#00a32a';
			out.textContent = ( res.dry_run ? '👁 ' : '✓ ' ) + ( res.detail || 'Done.' );
		} ).catch( function ( e ) {
			buttons.forEach( function ( b ) { b.disabled = false; } );
			out.textContent = '⚠ ' + e.message;
			out.style.color = '#d63638';
		} );
	}

	function renderDomain( domain, payload ) {
		var section = el( 'div', 'aiwp-doctor-domain' );
		var issues = ( payload && payload.issues ) || [];

		var h = el( 'h2', null, DOMAIN_LABELS[ domain ] || domain );
		h.appendChild( el( 'span', 'aiwp-domain-count', ' ' + issues.length ) );
		section.appendChild( h );

		if ( ! issues.length ) {
			section.appendChild( el( 'p', 'aiwp-allgood', '✓ No issues found.' ) );
			return section;
		}

		issues.sort( function ( a, b ) {
			return ( SEVERITY_ORDER[ a.severity ] || 9 ) - ( SEVERITY_ORDER[ b.severity ] || 9 );
		} );
		issues.forEach( function ( issue ) {
			section.appendChild( renderIssue( issue ) );
		} );
		return section;
	}

	function render( data ) {
		renderScore( data );
		results.innerHTML = '';
		[ 'bugs', 'performance', 'seo', 'health' ].forEach( function ( domain ) {
			if ( data.domains && data.domains[ domain ] ) {
				results.appendChild( renderDomain( domain, data.domains[ domain ] ) );
			}
		} );
		meta.textContent = 'Last scan: ' + ( data.generated || 'now' );
	}

	scanBtn.addEventListener( 'click', function () {
		scanBtn.disabled = true;
		scanBtn.textContent = 'Scanning…';
		results.innerHTML = '';
		request( '/doctor/scan', 'POST', {} ).then( function ( data ) {
			scanBtn.disabled = false;
			scanBtn.textContent = 'Re-run scan';
			if ( ! data || data.ok === false ) {
				results.appendChild( el( 'p', 'aiwp-allgood', 'Scan failed.' ) );
				return;
			}
			render( data );
		} ).catch( function ( e ) {
			scanBtn.disabled = false;
			scanBtn.textContent = 'Run full scan';
			results.appendChild( el( 'p', null, 'Error: ' + e.message ) );
		} );
	} );
} )();
