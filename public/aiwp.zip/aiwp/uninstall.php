<?php
/**
 * Uninstall routine. Removes AIWP options and tables. Does NOT delete the
 * sandbox directory contents automatically — those may be live site files; the
 * operator can remove wp-content/uploads/aiwp-sandbox/ manually.
 *
 * @package AIWP
 */

declare( strict_types=1 );

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$options = array(
	'aiwp_enabled',
	'aiwp_allow_writes',
	'aiwp_allow_wp_cli',
	'aiwp_rate_limit',
	'aiwp_require_approval',
	'aiwp_agent_max_steps',
	'aiwp_ack_production_risk',
	'aiwp_provider',
	'aiwp_model',
	'aiwp_license_key',
	'aiwp_license_active',
	'aiwp_crashguard_pending',
	'aiwp_key_anthropic',
	'aiwp_key_openai',
	'aiwp_key_gemini',
	'aiwp_key_openrouter',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

foreach ( array( 'aiwp_audit_log', 'aiwp_memory', 'aiwp_sandbox_files' ) as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" ); // phpcs:ignore WordPress.DB
}
