<!-- aiwp-skill: performance, slow, speed, optimize, optimization, optimise, cache, caching, fast, autoload, transient, revisions, core web vitals, ttfb, page speed -->
# Performance optimization

**Diagnose with `perf_scan` before changing anything.** It reports autoload
bloat, post-revision and transient buildup, oversized images, missing object
cache, and large tables — each with a matching `perf_fix` action.

**Fix order (cheapest, safest first):**
1. **Autoload bloat** — options loaded on *every* request. `perf_fix
   action=trim_autoload` stops autoloading options > 100 KB (value preserved,
   rows snapshotted). Single biggest easy win.
2. **Expired transients** — `perf_fix action=clean_transients`.
3. **Post revisions** — `perf_fix action=clean_revisions` (keeps the newest 5
   per post). Then cap them in `wp-config.php`:
   `define( 'WP_POST_REVISIONS', 5 );`
4. **Images** — `perf_fix action=optimize_images` (needs an optimizer wired via
   the `aiwp_optimize_image` filter or a compression plugin). Serve WebP, add
   `width`/`height`, lazy-load.
5. **Object cache** — recommend Redis/Memcached with a drop-in for repeated
   query cost. **Page cache** — a full-page cache plugin or host-level cache.

**Always:** run each fixer with `dry_run=true` first to see the planned count,
then apply. Re-run `perf_scan` afterwards to confirm the issue cleared.

**Don't:** delete data without a snapshot (the fixers snapshot for you); don't
add a second caching plugin on top of an existing one.
