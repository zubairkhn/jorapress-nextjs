<!-- aiwp-skill: convention, slug, spacing, brand, style guide -->
# Site conventions (edit me)

This is an editable example skill. Put YOUR site's house rules here so the agent
follows them automatically. Examples:

- **Slugs:** lowercase, hyphenated, no stop-words (`our-services`, not `the-services`).
- **Spacing tokens:** use 8 / 16 / 24 / 48 / 80 px only.
- **Brand colours:** primary `#0B5FFF`, ink `#111827`, muted `#6B7280`.
- **Headings:** H1 once per page; section titles are H2.
- **Images:** always set alt text; prefer existing media library items before uploading.
- **Never** edit the live theme's `functions.php` directly — put PHP in the AIWP sandbox.

A user-authored copy of this file can also live in
`wp-content/uploads/aiwp-skills/` so it survives plugin updates.
