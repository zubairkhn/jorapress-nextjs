<!-- aiwp-skill: seo, meta description, meta, title tag, alt text, alt, sitemap, robots, schema, structured data, noindex, canonical, open graph, rankmath, yoast, search engine -->
# SEO optimization

**Run `seo_scan` first.** It finds missing/duplicate titles & meta descriptions,
images without alt text, blocked indexing, and a missing sitemap — each with a
matching `seo_fix` action.

**Fix order:**
1. **Indexing blocked** (critical) — if "Discourage search engines" is on,
   `seo_fix action=allow_indexing`. Nothing else matters until this is fixed.
2. **Missing meta descriptions** — `seo_fix action=generate_meta`
   (`post_ids` optional). Writes to Yoast/Rank Math's key if installed, else the
   Yoast key as a de-facto standard. Posts are snapshotted first.
3. **Missing alt text** — `seo_fix action=generate_alt`.
4. **Sitemap** — `seo_fix action=enable_sitemap` force-enables the core sitemap
   at `/wp-sitemap.xml`.

**AI-written copy:** the generators run through the `aiwp_seo_generate_text`
filter. With no filter wired they use a deterministic heuristic (excerpt/content
for descriptions, title/filename for alt). To use the configured AI provider,
hook that filter and return better copy.

**Good meta descriptions:** unique per page, ~150–160 chars, lead with the value
proposition, include the primary term naturally, no keyword stuffing.

**Always** `dry_run=true` first to preview generated text before writing.

**Beyond the fixers (do via `execute_php`/builder data):** add JSON-LD schema
(Article/Product/LocalBusiness/Breadcrumb), Open Graph/Twitter tags, fix
canonicals, repair broken internal links.
