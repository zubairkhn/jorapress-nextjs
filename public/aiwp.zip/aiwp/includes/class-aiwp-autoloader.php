<?php
/**
 * Lightweight PSR-4-ish autoloader for the AIWP\ namespace.
 *
 * Maps AIWP\Foo\Bar  ->  includes/foo/class-aiwp-bar.php
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Autoloader {

	public static function register(): void {
		spl_autoload_register( array( __CLASS__, 'load' ) );
	}

	public static function load( string $class ): void {
		// Only handle our namespace.
		if ( 0 !== strpos( $class, 'AIWP\\' ) ) {
			return;
		}

		$relative = substr( $class, strlen( 'AIWP\\' ) );
		$parts    = explode( '\\', $relative );
		$class_nm = array_pop( $parts );

		// Sub-namespace segments become lowercase directories.
		$sub_path = '';
		if ( $parts ) {
			$sub_path = strtolower( implode( '/', $parts ) ) . '/';
		}

		// ClassName -> class-class-name.php
		$file_name = 'class-aiwp-' . self::kebab( $class_nm ) . '.php';

		$path = AIWP_DIR . 'includes/' . $sub_path . $file_name;

		if ( is_readable( $path ) ) {
			require_once $path;
			return;
		}

		// Interfaces follow interface-aiwp-name.php convention.
		$iface = AIWP_DIR . 'includes/' . $sub_path . 'interface-aiwp-' . self::kebab( $class_nm ) . '.php';
		if ( is_readable( $iface ) ) {
			require_once $iface;
		}
	}

	private static function kebab( string $name ): string {
		// AbcDef -> abc-def ; handles acronyms reasonably.
		$name = preg_replace( '/([a-z0-9])([A-Z])/', '$1-$2', $name );
		$name = preg_replace( '/([A-Z]+)([A-Z][a-z])/', '$1-$2', (string) $name );
		return strtolower( (string) $name );
	}
}
