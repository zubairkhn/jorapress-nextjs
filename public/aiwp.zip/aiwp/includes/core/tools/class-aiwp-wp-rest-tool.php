<?php
/**
 * wp_rest — call internal WordPress REST routes in-process. A safer, more
 * structured option for the chat-panel audience than raw PHP/SQL.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WpRestTool implements ToolInterface {

	public function name(): string {
		return 'wp_rest';
	}

	public function description(): string {
		return 'Dispatch an internal WordPress REST API request (no HTTP round-trip). '
			. 'Example: method "GET", route "/wp/v2/posts?per_page=5". Honours the current user\'s caps.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'method' => array(
					'type'        => 'string',
					'enum'        => array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ),
					'description' => 'HTTP method.',
				),
				'route'  => array(
					'type'        => 'string',
					'description' => 'REST route, e.g. /wp/v2/pages/42',
				),
				'params' => array(
					'type'        => 'object',
					'description' => 'Body/query parameters.',
				),
			),
			'required'   => array( 'method', 'route' ),
		);
	}

	public function is_write( array $args ): bool {
		$method = strtoupper( (string) ( $args['method'] ?? 'GET' ) );
		return in_array( $method, array( 'POST', 'PUT', 'PATCH', 'DELETE' ), true );
	}

	public function run( array $args ): array {
		$method = strtoupper( (string) ( $args['method'] ?? 'GET' ) );
		$route  = (string) ( $args['route'] ?? '' );
		$params = (array) ( $args['params'] ?? array() );

		if ( '' === $route ) {
			return array(
				'ok'    => false,
				'error' => 'No route provided.',
			);
		}

		// Split any query string into params.
		$parts = explode( '?', $route, 2 );
		$path  = $parts[0];
		if ( isset( $parts[1] ) ) {
			parse_str( $parts[1], $qs );
			$params = array_merge( (array) $qs, $params );
		}

		$request = new \WP_REST_Request( $method, $path );
		foreach ( $params as $k => $v ) {
			$request->set_param( $k, $v );
		}

		$response = rest_do_request( $request );
		$data     = rest_get_server()->response_to_data( $response, false );

		return array(
			'ok'     => ! $response->is_error(),
			'status' => $response->get_status(),
			'data'   => $data,
		);
	}
}
