<?php
/**
 * Base class for AIWP "Doctor" fixers — tools that remediate issues found by the
 * scanners. Every fixer:
 *
 *   • supports `dry_run` (preview the planned change without applying it),
 *   • is a write only when actually applying (so it respects write-gating), and
 *   • snapshots affected data before destructive changes (revertible).
 *
 * Subclasses implement {@see actions()} (machine name => human label) and
 * {@see apply()} which performs (or, when $dry_run, only describes) one action.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class FixerTool implements ToolInterface {

	/** @return array<string,string> action machine name => human label. */
	abstract protected function actions(): array;

	/**
	 * Perform (or, when $dry_run, only plan) a single action.
	 *
	 * @param array<string,mixed> $args
	 * @return array<string,mixed> Must include 'changed' (int) and 'detail' (string).
	 */
	abstract protected function apply( string $action, array $args, bool $dry_run ): array;

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'action'  => array(
					'type'        => 'string',
					'enum'        => array_keys( $this->actions() ),
					'description' => 'Which remediation to run: ' . implode( ', ', array_keys( $this->actions() ) ) . '.',
				),
				'dry_run' => array(
					'type'        => 'boolean',
					'description' => 'Preview the change without applying it. Default false.',
				),
			),
			'required'   => array( 'action' ),
		);
	}

	/** A fixer writes only when it is actually applying (not a dry run). */
	public function is_write( array $args ): bool {
		return empty( $args['dry_run'] );
	}

	public function run( array $args ): array {
		$action  = (string) ( $args['action'] ?? '' );
		$dry_run = ! empty( $args['dry_run'] );

		if ( ! isset( $this->actions()[ $action ] ) ) {
			return array(
				'ok'      => false,
				'error'   => sprintf( 'Unknown action "%s". Available: %s', $action, implode( ', ', array_keys( $this->actions() ) ) ),
			);
		}

		try {
			$result = $this->apply( $action, $args, $dry_run );
		} catch ( \Throwable $e ) {
			return array( 'ok' => false, 'error' => $e->getMessage() );
		}

		return array_merge(
			array(
				'ok'      => true,
				'action'  => $action,
				'dry_run' => $dry_run,
				'changed' => 0,
				'detail'  => '',
			),
			$result
		);
	}
}
