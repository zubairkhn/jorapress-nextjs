<?php
/**
 * db_query — run SQL against the WordPress database. Read by default; writes
 * (INSERT/UPDATE/DELETE/REPLACE/ALTER/DROP/TRUNCATE/CREATE) are gated and a
 * snapshot of affected rows is taken first where feasible.
 *
 * Useful for inspecting and bulk-editing the post meta where builders store
 * their layout data (_elementor_data, _bricks_page_content_2, _fl_builder_data…).
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core\Tools;

use AIWP\Core\Backup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DbQueryTool implements ToolInterface {

	private const WRITE_VERBS = array( 'insert', 'update', 'delete', 'replace', 'alter', 'drop', 'truncate', 'create', 'rename', 'grant' );

	public function name(): string {
		return 'db_query';
	}

	public function description(): string {
		return 'Run a SQL query against the WordPress database. SELECT/SHOW/DESCRIBE return rows. '
			. 'Write queries require writes to be enabled and are snapshotted first. '
			. 'Table prefix for this install is exposed via the {prefix} placeholder.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'sql'      => array(
					'type'        => 'string',
					'description' => 'The SQL to execute. You may use {prefix} which is replaced by the wpdb table prefix.',
				),
				'snapshot' => array(
					'type'        => 'boolean',
					'description' => 'For write queries, snapshot affected table rows before running. Default true.',
				),
			),
			'required'   => array( 'sql' ),
		);
	}

	public function is_write( array $args ): bool {
		return $this->is_write_sql( (string) ( $args['sql'] ?? '' ) );
	}

	private function is_write_sql( string $sql ): bool {
		$verb = strtolower( strtok( trim( $sql ), " \t\n(" ) ?: '' );
		return in_array( $verb, self::WRITE_VERBS, true );
	}

	public function run( array $args ): array {
		global $wpdb;

		$sql = isset( $args['sql'] ) ? (string) $args['sql'] : '';
		$sql = str_replace( '{prefix}', $wpdb->prefix, $sql );
		if ( '' === trim( $sql ) ) {
			return array(
				'ok'    => false,
				'error' => 'Empty SQL.',
			);
		}

		$is_write = $this->is_write_sql( $sql );

		if ( $is_write && ( $args['snapshot'] ?? true ) ) {
			$table = $this->guess_table( $sql );
			if ( $table ) {
				Backup::snapshot_rows( $table );
			}
		}

		$wpdb->suppress_errors( true );

		if ( $is_write ) {
			$affected = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB
			if ( false === $affected ) {
				return array(
					'ok'    => false,
					'error' => $wpdb->last_error ?: 'Query failed.',
				);
			}
			return array(
				'ok'            => true,
				'rows_affected' => (int) $affected,
				'insert_id'     => (int) $wpdb->insert_id,
			);
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( null === $rows && $wpdb->last_error ) {
			return array(
				'ok'    => false,
				'error' => $wpdb->last_error,
			);
		}

		// Cap result size returned to the agent.
		$rows = is_array( $rows ) ? $rows : array();
		$cap  = array_slice( $rows, 0, 500 );

		return array(
			'ok'        => true,
			'row_count' => count( $rows ),
			'returned'  => count( $cap ),
			'rows'      => $cap,
		);
	}

	private function guess_table( string $sql ): ?string {
		if ( preg_match( '/\b(?:from|into|update|table)\s+`?([a-zA-Z0-9_]+)`?/i', $sql, $m ) ) {
			return $m[1];
		}
		return null;
	}
}
