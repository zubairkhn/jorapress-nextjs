<?php
/**
 * edit_file — targeted find/replace in an existing file. Backs up first.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core\Tools;

use AIWP\Core\Sandbox;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EditFileTool extends FilesystemTool {

	public function name(): string {
		return 'edit_file';
	}

	public function description(): string {
		return 'Replace an exact substring in a file. Fails if the search string is absent or '
			. '(unless replace_all) appears more than once. Backs up the previous version.';
	}

	public function input_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'path'        => array(
					'type'        => 'string',
					'description' => 'File path (relative to sandbox dir when sandbox=true, else install root).',
				),
				'search'      => array(
					'type'        => 'string',
					'description' => 'Exact text to find.',
				),
				'replace'     => array(
					'type'        => 'string',
					'description' => 'Replacement text.',
				),
				'replace_all' => array(
					'type'        => 'boolean',
					'description' => 'Replace every occurrence (default false).',
				),
				'sandbox'     => array(
					'type'        => 'boolean',
					'description' => 'Operate inside the sandbox dir (default false).',
				),
			),
			'required'   => array( 'path', 'search', 'replace' ),
		);
	}

	public function is_write( array $args ): bool {
		return true;
	}

	public function run( array $args ): array {
		$path        = (string) ( $args['path'] ?? '' );
		$search      = (string) ( $args['search'] ?? '' );
		$replace     = (string) ( $args['replace'] ?? '' );
		$replace_all = (bool) ( $args['replace_all'] ?? false );
		$sandbox     = (bool) ( $args['sandbox'] ?? false );

		$abs = $sandbox ? Sandbox::resolve( $path ) : $this->resolve( $path );

		if ( ! is_file( $abs ) ) {
			return array(
				'ok'    => false,
				'error' => 'File not found.',
			);
		}

		$contents = (string) file_get_contents( $abs ); // phpcs:ignore
		$count    = substr_count( $contents, $search );

		if ( 0 === $count ) {
			return array(
				'ok'    => false,
				'error' => 'Search string not found.',
			);
		}
		if ( $count > 1 && ! $replace_all ) {
			return array(
				'ok'    => false,
				'error' => sprintf( 'Search string appears %d times; pass replace_all=true or make it unique.', $count ),
			);
		}

		if ( $sandbox ) {
			$new = $replace_all
				? str_replace( $search, $replace, $contents )
				: $this->replace_first( $contents, $search, $replace );
			$res = Sandbox::write( $path, $new );
			return array(
				'ok'           => true,
				'replacements' => $replace_all ? $count : 1,
				'rel_path'     => $res['rel_path'],
			);
		}

		// Non-sandbox: back up then write.
		$backup = $abs . '.aiwp-' . gmdate( 'Ymd-His' ) . '.bak';
		copy( $abs, $backup );

		$new = $replace_all
			? str_replace( $search, $replace, $contents )
			: $this->replace_first( $contents, $search, $replace );

		$bytes = file_put_contents( $abs, $new ); // phpcs:ignore

		return array(
			'ok'           => false !== $bytes,
			'replacements' => $replace_all ? $count : 1,
			'backup'       => basename( $backup ),
		);
	}

	private function replace_first( string $haystack, string $search, string $replace ): string {
		$pos = strpos( $haystack, $search );
		if ( false === $pos ) {
			return $haystack;
		}
		return substr_replace( $haystack, $replace, $pos, strlen( $search ) );
	}
}
