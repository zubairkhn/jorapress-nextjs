<?php
/**
 * error_scan — parses the WordPress debug log for recent PHP errors, groups them
 * by message, and attributes each to the most likely plugin/theme/file. Reports
 * fatals as critical and deprecations/notices as warnings/recommendations.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ErrorScanTool extends ScannerTool {

	/** Cap how much of the log we read (bytes from the end). */
	private const MAX_BYTES = 524288; // 512 KB.

	public function name(): string {
		return 'error_scan';
	}

	public function description(): string {
		return 'Scan the WordPress debug log for recent PHP fatals, warnings and deprecations, grouped and attributed to the responsible plugin/theme.';
	}

	protected function domain(): string {
		return 'bugs';
	}

	protected function scan(): array {
		$log = $this->log_path();
		if ( '' === $log || ! is_readable( $log ) ) {
			return array(
				$this->issue(
					'no_log',
					self::SEVERITY_RECOMMENDATION,
					'Debug logging is off — errors cannot be scanned',
					'Enable WP_DEBUG and WP_DEBUG_LOG in wp-config.php so AIWP can detect runtime errors.',
					array()
				),
			);
		}

		$lines  = $this->tail( $log );
		$groups = array(); // signature => data.

		foreach ( $lines as $line ) {
			$parsed = $this->parse_line( $line );
			if ( null === $parsed ) {
				continue;
			}
			$sig = $parsed['type'] . '|' . $parsed['message'];
			if ( ! isset( $groups[ $sig ] ) ) {
				$groups[ $sig ] = array(
					'type'    => $parsed['type'],
					'message' => $parsed['message'],
					'source'  => $parsed['source'],
					'count'   => 0,
					'last'    => $parsed['raw'],
				);
			}
			++$groups[ $sig ]['count'];
		}

		if ( empty( $groups ) ) {
			return array();
		}

		$issues = array();
		foreach ( $groups as $g ) {
			$severity = match ( $g['type'] ) {
				'fatal'       => self::SEVERITY_CRITICAL,
				'warning'     => self::SEVERITY_WARNING,
				'deprecated'  => self::SEVERITY_RECOMMENDATION,
				default       => self::SEVERITY_RECOMMENDATION,
			};

			$issues[] = $this->issue(
				'log_' . substr( md5( $g['message'] ), 0, 8 ),
				$severity,
				sprintf( '%s × %d: %s', ucfirst( $g['type'] ), $g['count'], $this->shorten( $g['message'] ) ),
				$g['source']
					? sprintf( 'Originates in %s. Update or patch it, or deactivate to confirm.', $g['source'] )
					: 'Review the offending code and patch it.',
				array(
					'evidence'     => array(
						'type'   => $g['type'],
						'source' => $g['source'],
						'count'  => $g['count'],
						'sample' => $this->shorten( $g['last'], 300 ),
					),
					'auto_fixable' => 'fatal' === $g['type'] && (bool) $g['source'],
					'fix_tool'     => 'fatal' === $g['type'] && $g['source'] ? 'bug_fix' : null,
					'fix_args'     => 'fatal' === $g['type'] && $g['source']
						? array( 'action' => 'deactivate_plugin', 'plugin' => $g['source'] )
						: null,
				)
			);
		}

		return $issues;
	}

	private function log_path(): string {
		if ( defined( 'WP_DEBUG_LOG' ) && is_string( WP_DEBUG_LOG ) && '' !== WP_DEBUG_LOG ) {
			return WP_DEBUG_LOG;
		}
		$default = WP_CONTENT_DIR . '/debug.log';
		return file_exists( $default ) ? $default : '';
	}

	/** @return array<int,string> */
	private function tail( string $file ): array {
		$size = (int) filesize( $file );
		$fh   = fopen( $file, 'rb' );
		if ( ! $fh ) {
			return array();
		}
		if ( $size > self::MAX_BYTES ) {
			fseek( $fh, -self::MAX_BYTES, SEEK_END );
			fgets( $fh ); // discard partial first line.
		}
		$data = (string) stream_get_contents( $fh );
		fclose( $fh );
		return array_filter( explode( "\n", $data ) );
	}

	/** @return array{type:string,message:string,source:?string,raw:string}|null */
	private function parse_line( string $line ): ?array {
		if ( false === stripos( $line, 'PHP ' ) && false === stripos( $line, 'error' ) ) {
			return null;
		}

		$type = 'notice';
		if ( stripos( $line, 'Fatal error' ) !== false || stripos( $line, 'Uncaught' ) !== false ) {
			$type = 'fatal';
		} elseif ( stripos( $line, 'Deprecated' ) !== false ) {
			$type = 'deprecated';
		} elseif ( stripos( $line, 'Warning' ) !== false ) {
			$type = 'warning';
		} elseif ( stripos( $line, 'Notice' ) !== false ) {
			$type = 'notice';
		} else {
			return null;
		}

		// Strip the leading timestamp "[dd-Mon-YYYY ...] ".
		$message = (string) preg_replace( '/^\[[^\]]+\]\s*/', '', $line );
		// Normalize variable bits (line numbers, hashes) so similar errors group.
		$normalized = (string) preg_replace( '/\b\d+\b/', '#', $message );

		return array(
			'type'    => $type,
			'message' => trim( $normalized ),
			'source'  => $this->attribute( $line ),
			'raw'     => trim( $message ),
		);
	}

	/** Map a log line to a plugin/theme folder if its path appears. */
	private function attribute( string $line ): ?string {
		if ( preg_match( '#wp-content/plugins/([^/]+)/#', $line, $m ) ) {
			return 'plugin: ' . $m[1];
		}
		if ( preg_match( '#wp-content/themes/([^/]+)/#', $line, $m ) ) {
			return 'theme: ' . $m[1];
		}
		if ( preg_match( '#wp-content/mu-plugins/([^/\s]+)#', $line, $m ) ) {
			return 'mu-plugin: ' . $m[1];
		}
		return null;
	}

	private function shorten( string $s, int $len = 120 ): string {
		$s = trim( preg_replace( '/\s+/', ' ', $s ) ?? $s );
		return strlen( $s ) > $len ? substr( $s, 0, $len ) . '…' : $s;
	}
}
