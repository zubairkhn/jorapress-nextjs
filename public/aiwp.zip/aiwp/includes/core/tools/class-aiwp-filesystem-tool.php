<?php
/**
 * Shared base for filesystem tools. Scopes every path to the WordPress install
 * (ABSPATH) and blocks traversal outside it. Writes outside the sandbox dir are
 * treated as writes for gating.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core\Tools;

use AIWP\Core\SafetyException;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class FilesystemTool implements ToolInterface {

	public function is_write( array $args ): bool {
		return false;
	}

	/**
	 * Resolve a relative path against ABSPATH, refusing anything that escapes
	 * the install root.
	 */
	protected function resolve( string $path ): string {
		$root = wp_normalize_path( untrailingslashit( ABSPATH ) );
		$path = wp_normalize_path( $path );

		// Absolute paths must still live under the install root.
		if ( ! str_starts_with( $path, '/' ) ) {
			$path = $root . '/' . ltrim( $path, '/' );
		}

		$real_root = realpath( $root ) ?: $root;
		$candidate = $path;

		// For not-yet-existing files, validate the parent directory.
		$check = file_exists( $candidate ) ? realpath( $candidate ) : realpath( dirname( $candidate ) );
		if ( false === $check ) {
			$check = $candidate;
		}

		if ( ! str_starts_with( wp_normalize_path( $check ), $real_root ) ) {
			throw new SafetyException( 'Path is outside the WordPress install root.', 400 );
		}

		return $candidate;
	}
}
