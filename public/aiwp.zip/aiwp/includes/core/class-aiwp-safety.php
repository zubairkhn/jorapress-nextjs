<?php
/**
 * Safety layer: master switch, production detection, rate limiting, write
 * gating and capability enforcement. Every tool call passes through here.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Safety {

	/**
	 * Is the master "AI abilities" switch on?
	 */
	public function is_enabled(): bool {
		return (bool) get_option( 'aiwp_enabled', 0 );
	}

	public function set_enabled( bool $on ): void {
		update_option( 'aiwp_enabled', $on ? 1 : 0 );
	}

	public function writes_allowed(): bool {
		return (bool) get_option( 'aiwp_allow_writes', 0 );
	}

	public function wp_cli_allowed(): bool {
		return (bool) get_option( 'aiwp_allow_wp_cli', 0 );
	}

	/**
	 * Confirm the current actor may use AI abilities at all. Used on EVERY
	 * tool call, not just at authentication time.
	 */
	public function assert_capability(): void {
		if ( ! current_user_can( AIWP_CAPABILITY ) ) {
			throw new SafetyException( __( 'Insufficient capability for AI tools.', 'aiwp' ), 403 );
		}
	}

	/**
	 * Master gate run before any tool executes.
	 *
	 * @throws SafetyException When a guardrail blocks execution.
	 */
	public function preflight( string $tool, bool $is_write ): void {
		if ( ! $this->is_enabled() ) {
			throw new SafetyException( __( 'AI abilities are disabled (master kill switch is off).', 'aiwp' ), 423 );
		}

		$this->assert_capability();

		// Production guardrail. Refuse hard unless the operator has explicitly
		// acknowledged the risk in settings.
		if ( $this->looks_like_production() && ! $this->production_ack() ) {
			throw new SafetyException(
				__( 'This looks like a PRODUCTION site. AIWP is for dev/staging. Acknowledge the risk in AIWP settings to override.', 'aiwp' ),
				412
			);
		}

		if ( $is_write && ! $this->writes_allowed() ) {
			throw new SafetyException(
				sprintf(
					/* translators: %s tool name */
					__( 'The "%s" tool attempted a write, but writes are disabled. Enable writes in AIWP settings.', 'aiwp' ),
					$tool
				),
				423
			);
		}

		$this->enforce_rate_limit();
	}

	/**
	 * Heuristic production detection: HTTPS custom domain that isn't an obvious
	 * local/staging host, with WP_DEBUG off. Conservative — flags ambiguous
	 * cases so the operator must opt in.
	 */
	public function looks_like_production(): bool {
		$home = wp_parse_url( home_url(), PHP_URL_HOST );
		$home = is_string( $home ) ? strtolower( $home ) : '';

		$dev_markers = array( 'localhost', '127.0.0.1', '::1', '.local', '.test', '.dev', '.staging', 'staging.', 'dev.', '.lndo.site', '.ddev.site', '.wpengine' );
		foreach ( $dev_markers as $marker ) {
			if ( '' !== $home && ( str_contains( $home, $marker ) ) ) {
				return false;
			}
		}

		// WP_ENVIRONMENT_TYPE is the modern signal.
		if ( function_exists( 'wp_get_environment_type' ) ) {
			$env = wp_get_environment_type();
			if ( in_array( $env, array( 'local', 'development', 'staging' ), true ) ) {
				return false;
			}
			if ( 'production' === $env ) {
				return true;
			}
		}

		// Unknown environment + real-looking public domain (has a dot, not a
		// dev marker) => treat as production to be safe.
		return '' !== $home && str_contains( $home, '.' );
	}

	public function production_ack(): bool {
		return (bool) get_option( 'aiwp_ack_production_risk', 0 );
	}

	/**
	 * Per-user sliding-window rate limit using a transient bucket.
	 */
	public function enforce_rate_limit(): void {
		$limit = (int) get_option( 'aiwp_rate_limit', 60 );
		if ( $limit <= 0 ) {
			return;
		}

		$user = get_current_user_id();
		$key  = 'aiwp_rl_' . $user . '_' . gmdate( 'YmdHi' ); // per-minute bucket.
		$hits = (int) get_transient( $key );

		if ( $hits >= $limit ) {
			throw new SafetyException(
				sprintf(
					/* translators: %d limit */
					__( 'Rate limit reached (%d calls/min). Slow down or raise the limit in settings.', 'aiwp' ),
					$limit
				),
				429
			);
		}

		set_transient( $key, $hits + 1, MINUTE_IN_SECONDS + 5 );
	}
}
