<?php
/**
 * Tool router — the single chokepoint every tool call passes through,
 * regardless of front door (MCP or chat panel). Applies the safety preflight,
 * runs the tool, logs to the audit trail.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core;

use AIWP\Core\Tools\ToolInterface;
use AIWP\Core\Tools\ExecutePhpTool;
use AIWP\Core\Tools\DbQueryTool;
use AIWP\Core\Tools\ReadFileTool;
use AIWP\Core\Tools\WriteFileTool;
use AIWP\Core\Tools\EditFileTool;
use AIWP\Core\Tools\ListDirTool;
use AIWP\Core\Tools\WpCliTool;
use AIWP\Core\Tools\WpRestTool;
use AIWP\Core\Tools\SiteHealthTool;
use AIWP\Core\Tools\ErrorScanTool;
use AIWP\Core\Tools\PerfScanTool;
use AIWP\Core\Tools\SeoScanTool;
use AIWP\Core\Tools\BugFixTool;
use AIWP\Core\Tools\PerfFixTool;
use AIWP\Core\Tools\SeoFixTool;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ToolRouter {

	/** @var array<string,ToolInterface> */
	private array $tools = array();

	public function __construct(
		private Safety $safety,
		private AuditLog $audit
	) {}

	public function register_default_tools(): void {
		$defaults = array(
			new ExecutePhpTool(),
			new DbQueryTool(),
			new ReadFileTool(),
			new WriteFileTool(),
			new EditFileTool(),
			new ListDirTool(),
			new WpCliTool(),
			new WpRestTool(),
			// Doctor scanners (read-only diagnostics).
			new SiteHealthTool(),
			new ErrorScanTool(),
			new PerfScanTool(),
			new SeoScanTool(),
			// Doctor fixers (gated, snapshotted, dry_run-capable).
			new BugFixTool(),
			new PerfFixTool(),
			new SeoFixTool(),
		);

		foreach ( $defaults as $tool ) {
			$this->register( $tool );
		}

		// Allow add-ons / Pro packs to register more tools.
		do_action( 'aiwp_register_tools', $this );
	}

	public function register( ToolInterface $tool ): void {
		$this->tools[ $tool->name() ] = $tool;
	}

	public function has( string $name ): bool {
		return isset( $this->tools[ $name ] );
	}

	/**
	 * @return array<string,ToolInterface>
	 */
	public function all(): array {
		return $this->tools;
	}

	/**
	 * MCP-style tool descriptors for tools/list.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function descriptors(): array {
		$out = array();
		foreach ( $this->tools as $tool ) {
			// Respect capability gating in descriptors.
			if ( 'wp_cli' === $tool->name() && ! $this->safety->wp_cli_allowed() ) {
				continue;
			}
			$out[] = array(
				'name'        => $tool->name(),
				'description' => $tool->description(),
				'inputSchema' => $tool->input_schema(),
			);
		}
		return $out;
	}

	/**
	 * Execute a tool by name. Runs safety preflight + audit logging.
	 *
	 * @param array<string,mixed> $args
	 * @return array<string,mixed>
	 * @throws SafetyException
	 */
	public function call( string $name, array $args, string $front_door = 'mcp' ): array {
		if ( ! $this->has( $name ) ) {
			throw new SafetyException( sprintf( 'Unknown tool: %s', $name ), 404 );
		}

		$tool = $this->tools[ $name ];

		if ( 'wp_cli' === $name && ! $this->safety->wp_cli_allowed() ) {
			throw new SafetyException( 'The wp_cli tool is disabled in settings.', 423 );
		}

		$is_write = $tool->is_write( $args );

		// Safety gate (master switch, capability, production guard, write gate,
		// rate limit). Throws on violation.
		$this->safety->preflight( $name, $is_write );

		try {
			$result = $tool->run( $args );
			$status = ( $result['ok'] ?? true ) ? 'ok' : 'tool_error';
			$this->audit->record( $name, $args, $this->summarise( $result ), $status, $front_door );
			return $result;
		} catch ( \Throwable $e ) {
			$this->audit->record( $name, $args, $e->getMessage(), 'exception', $front_door );
			return array(
				'ok'    => false,
				'error' => $e->getMessage(),
			);
		}
	}

	private function summarise( array $result ): string {
		$copy = $result;
		if ( isset( $copy['rows'] ) && is_array( $copy['rows'] ) ) {
			$copy['rows'] = sprintf( '[%d rows]', count( $copy['rows'] ) );
		}
		if ( isset( $copy['contents'] ) ) {
			$copy['contents'] = sprintf( '[%d chars]', strlen( (string) $copy['contents'] ) );
		}
		return (string) wp_json_encode( $copy );
	}
}
