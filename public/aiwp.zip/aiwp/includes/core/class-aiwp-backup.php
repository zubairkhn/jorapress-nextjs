<?php
/**
 * Backup helper. Snapshots DB rows / files before destructive operations so a
 * bad AI write can be rolled back. Stores snapshots as JSON in the sandbox
 * backups dir.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Backup {

	/**
	 * Snapshot the rows a query is about to touch. Best-effort: we run a SELECT
	 * mirror of the target table for the affected ids when we can derive them.
	 *
	 * @param string $table Fully-qualified table name.
	 * @param string $where Optional WHERE clause (without the keyword).
	 */
	public static function snapshot_rows( string $table, string $where = '' ): string {
		global $wpdb;

		// Allow only known tables to avoid arbitrary reads here.
		$sql = "SELECT * FROM `{$table}`";
		if ( '' !== $where ) {
			$sql .= ' WHERE ' . $where;
		}
		$sql  .= ' LIMIT 5000';
		$rows  = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		$path  = self::file( 'rows_' . sanitize_key( $table ) );

		file_put_contents( // phpcs:ignore
			$path,
			wp_json_encode(
				array(
					'table'   => $table,
					'where'   => $where,
					'taken'   => current_time( 'mysql', true ),
					'rows'    => $rows,
				)
			)
		);

		return $path;
	}

	/**
	 * Snapshot a single post (post row + all meta) before the AI edits it.
	 * This is the common case for builder data (Elementor _elementor_data etc).
	 */
	public static function snapshot_post( int $post_id ): string {
		$post = get_post( $post_id, ARRAY_A );
		$meta = get_post_meta( $post_id );
		$path = self::file( 'post_' . $post_id );

		file_put_contents( // phpcs:ignore
			$path,
			wp_json_encode(
				array(
					'post_id' => $post_id,
					'taken'   => current_time( 'mysql', true ),
					'post'    => $post,
					'meta'    => $meta,
				)
			)
		);

		return $path;
	}

	private static function file( string $label ): string {
		Sandbox::ensure_dir();
		return Sandbox::backups_dir() . '/' . sanitize_file_name( $label ) . '.' . gmdate( 'Ymd-His' ) . '.json';
	}

	/**
	 * @return array<int,string> absolute paths of available snapshots.
	 */
	public static function list_snapshots(): array {
		$dir = Sandbox::backups_dir();
		if ( ! is_dir( $dir ) ) {
			return array();
		}
		$files = glob( $dir . '/*.json' );
		return is_array( $files ) ? $files : array();
	}
}
