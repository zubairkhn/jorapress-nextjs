<?php
/**
 * Deactivation routine. Leaves data intact; only clears scheduled work and
 * flips the master switch off as a safety measure.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Deactivator {

	public static function deactivate(): void {
		// Hard-disable AI abilities the moment the plugin is deactivated.
		update_option( 'aiwp_enabled', 0 );

		wp_clear_scheduled_hook( 'aiwp_cron_cleanup' );
		wp_clear_scheduled_hook( \AIWP\Core\Reporter::HOOK );
		flush_rewrite_rules();
	}
}
