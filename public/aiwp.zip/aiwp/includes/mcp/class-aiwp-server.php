<?php
/**
 * MCP front door. Exposes a JSON-RPC 2.0 endpoint at
 *   POST /wp-json/aiwp/v1/mcp
 * over Streamable HTTP. Authenticated with WordPress Application Passwords
 * (HTTP Basic over HTTPS), which WordPress core resolves into the current user
 * before our permission callback runs.
 *
 * Implements the core MCP methods: initialize, tools/list, tools/call, ping.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Mcp;

use AIWP\Core\ToolRouter;
use AIWP\Core\Safety;
use AIWP\Core\AuditLog;
use AIWP\Core\SafetyException;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Server {

	private const PROTOCOL_VERSION = '2025-06-18';

	public function __construct(
		private ToolRouter $router,
		private Safety $safety,
		private AuditLog $audit
	) {}

	public function hooks(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );

		// WordPress only offers Application Passwords over HTTPS by default.
		// Allow them on local/staging hosts so the dev workflow works over http.
		add_filter(
			'wp_is_application_passwords_available',
			function ( $available ) {
				if ( $available ) {
					return $available;
				}
				return ! $this->safety->looks_like_production();
			}
		);
	}

	public function register_routes(): void {
		register_rest_route(
			AIWP_REST_NAMESPACE,
			'/mcp',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'authorize' ),
			)
		);

		// Lightweight discovery / health route (GET).
		register_rest_route(
			AIWP_REST_NAMESPACE,
			'/mcp',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'discovery' ),
				'permission_callback' => array( $this, 'authorize' ),
			)
		);
	}

	/**
	 * Require an authenticated user with the AI capability. Application
	 * Passwords populate the current user before this runs.
	 */
	public function authorize(): bool|\WP_Error {
		// Require HTTPS only on production-looking public sites. Local/staging
		// hosts (.local, .test, localhost, *.ddev.site, etc.) are exempt so the
		// common dev workflow over http works.
		if ( ! is_ssl() && $this->safety->looks_like_production() ) {
			return new \WP_Error( 'aiwp_https_required', 'HTTPS is required for the MCP endpoint on production sites.', array( 'status' => 426 ) );
		}
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'aiwp_unauthorized', 'Authentication required (use a WordPress Application Password).', array( 'status' => 401 ) );
		}
		if ( ! current_user_can( AIWP_CAPABILITY ) ) {
			return new \WP_Error( 'aiwp_forbidden', 'Insufficient capability.', array( 'status' => 403 ) );
		}
		return true;
	}

	public function discovery(): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'name'            => 'AIWP MCP Server',
				'version'         => AIWP_VERSION,
				'protocolVersion' => self::PROTOCOL_VERSION,
				'transport'       => 'streamable-http',
				'enabled'         => $this->safety->is_enabled(),
			)
		);
	}

	/**
	 * Main JSON-RPC dispatcher. Accepts a single request or a batch.
	 */
	public function handle( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();

		if ( null === $body ) {
			return $this->respond( JsonRpc::error( JsonRpc::PARSE_ERROR, 'Invalid JSON.', null ) );
		}

		// Batch support.
		if ( array_is_list( $body ) ) {
			$responses = array();
			foreach ( $body as $message ) {
				$resp = $this->dispatch( (array) $message );
				if ( null !== $resp ) {
					$responses[] = $resp;
				}
			}
			return $this->respond( $responses );
		}

		$resp = $this->dispatch( $body );
		// Notifications get a 202 with empty body.
		if ( null === $resp ) {
			return new WP_REST_Response( null, 202 );
		}
		return $this->respond( $resp );
	}

	/**
	 * Route one JSON-RPC message. Returns null for notifications.
	 *
	 * @param array<string,mixed> $message
	 * @return array<string,mixed>|null
	 */
	private function dispatch( array $message ): ?array {
		$id     = $message['id'] ?? null;
		$method = (string) ( $message['method'] ?? '' );
		$params = (array) ( $message['params'] ?? array() );

		if ( '2.0' !== ( $message['jsonrpc'] ?? '' ) ) {
			return JsonRpc::error( JsonRpc::INVALID_REQUEST, 'jsonrpc must be "2.0".', $id );
		}

		$is_notification = JsonRpc::is_notification( $message );

		switch ( $method ) {
			case 'initialize':
				$result = $this->initialize( $params );
				break;

			case 'notifications/initialized':
			case 'notifications/cancelled':
				return null; // Ack-only notifications.

			case 'ping':
				$result = new \stdClass();
				break;

			case 'tools/list':
				$result = array( 'tools' => $this->router->descriptors() );
				break;

			case 'tools/call':
				return $is_notification ? null : $this->tools_call( $params, $id );

			default:
				return $is_notification ? null : JsonRpc::error( JsonRpc::METHOD_NOT_FOUND, sprintf( 'Method not found: %s', $method ), $id );
		}

		return $is_notification ? null : JsonRpc::result( $result, $id );
	}

	/**
	 * @param array<string,mixed> $params
	 * @return array<string,mixed>
	 */
	private function initialize( array $params ): array {
		return array(
			'protocolVersion' => self::PROTOCOL_VERSION,
			'capabilities'    => array(
				'tools' => array( 'listChanged' => false ),
			),
			'serverInfo'      => array(
				'name'    => 'AIWP — AI WordPress Builder',
				'version' => AIWP_VERSION,
			),
			'instructions'    => 'Use tools/list to discover primitives. There is no per-builder tool: '
				. 'read an existing builder layout with db_query/execute_php to learn its JSON shape, '
				. 'then write the new structure and clear the builder cache.',
		);
	}

	/**
	 * @param array<string,mixed> $params
	 * @param mixed               $id
	 * @return array<string,mixed>
	 */
	private function tools_call( array $params, $id ): array {
		$name = (string) ( $params['name'] ?? '' );
		$args = (array) ( $params['arguments'] ?? array() );

		try {
			$result = $this->router->call( $name, $args, 'mcp' );
			$is_err = ! ( $result['ok'] ?? true );

			return JsonRpc::result(
				array(
					'content' => array(
						array(
							'type' => 'text',
							'text' => (string) wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ),
						),
					),
					'isError' => $is_err,
				),
				$id
			);
		} catch ( SafetyException $e ) {
			return JsonRpc::error( JsonRpc::INTERNAL_ERROR, $e->getMessage(), $id, array( 'status' => $e->getCode() ) );
		} catch ( \Throwable $e ) {
			return JsonRpc::error( JsonRpc::INTERNAL_ERROR, $e->getMessage(), $id );
		}
	}

	/**
	 * @param array<string,mixed>|array<int,mixed> $payload
	 */
	private function respond( array $payload ): WP_REST_Response {
		$response = new WP_REST_Response( $payload, 200 );
		$response->header( 'Content-Type', 'application/json; charset=utf-8' );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}
}
