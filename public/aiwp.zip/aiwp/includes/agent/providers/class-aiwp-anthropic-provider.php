<?php
/**
 * Anthropic (Claude) provider. Maps the internal message format to the
 * Messages API tool-use schema and back.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Agent\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnthropicProvider implements ProviderInterface {

	private const ENDPOINT = 'https://api.anthropic.com/v1/messages';

	public function id(): string {
		return 'anthropic';
	}

	public function label(): string {
		return 'Anthropic (Claude)';
	}

	public function default_model(): string {
		return 'claude-sonnet-4-6';
	}

	public function send( array $messages, array $tools, string $system, string $model, string $api_key ): array {
		$body = array(
			'model'      => $model ?: $this->default_model(),
			'max_tokens' => 4096,
			'system'     => $system,
			'messages'   => $this->to_anthropic_messages( $messages ),
		);

		if ( $tools ) {
			$body['tools'] = array_map(
				static function ( array $t ): array {
					return array(
						'name'         => $t['name'],
						'description'  => $t['description'],
						'input_schema' => $t['inputSchema'],
					);
				},
				$tools
			);
		}

		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 120,
				'headers' => array(
					'content-type'      => 'application/json',
					'x-api-key'         => $api_key,
					'anthropic-version' => '2023-06-01',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		return $this->parse( $response );
	}

	private function to_anthropic_messages( array $messages ): array {
		$out = array();
		foreach ( $messages as $m ) {
			$role = $m['role'];

			if ( 'tool' === $role ) {
				$out[] = array(
					'role'    => 'user',
					'content' => array(
						array(
							'type'        => 'tool_result',
							'tool_use_id' => $m['tool_call_id'] ?? '',
							'content'     => (string) ( $m['content'] ?? '' ),
						),
					),
				);
				continue;
			}

			if ( 'assistant' === $role && ! empty( $m['tool_calls'] ) ) {
				$content = array();
				if ( ! empty( $m['content'] ) ) {
					$content[] = array(
						'type' => 'text',
						'text' => (string) $m['content'],
					);
				}
				foreach ( $m['tool_calls'] as $tc ) {
					$content[] = array(
						'type'  => 'tool_use',
						'id'    => $tc['id'],
						'name'  => $tc['name'],
						'input' => (object) $tc['arguments'],
					);
				}
				$out[] = array(
					'role'    => 'assistant',
					'content' => $content,
				);
				continue;
			}

			$out[] = array(
				'role'    => $role,
				'content' => (string) ( $m['content'] ?? '' ),
			);
		}
		return $out;
	}

	private function parse( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'text'        => '',
				'tool_calls'  => array(),
				'stop_reason' => 'error',
				'error'       => $response->get_error_message(),
			);
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( isset( $data['error'] ) ) {
			return array(
				'text'        => '',
				'tool_calls'  => array(),
				'stop_reason' => 'error',
				'error'       => $data['error']['message'] ?? 'Anthropic API error.',
			);
		}

		$text       = '';
		$tool_calls = array();
		foreach ( (array) ( $data['content'] ?? array() ) as $block ) {
			if ( 'text' === ( $block['type'] ?? '' ) ) {
				$text .= $block['text'];
			} elseif ( 'tool_use' === ( $block['type'] ?? '' ) ) {
				$tool_calls[] = array(
					'id'        => $block['id'],
					'name'      => $block['name'],
					'arguments' => (array) $block['input'],
				);
			}
		}

		return array(
			'text'        => $text,
			'tool_calls'  => $tool_calls,
			'stop_reason' => $data['stop_reason'] ?? 'end_turn',
			'usage'       => $data['usage'] ?? array(),
			'raw'         => $data,
		);
	}
}
