<?php
/**
 * OpenAI provider (Chat Completions with tool calling). The OpenRouter provider
 * subclasses this since the wire format is compatible.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Agent\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OpenAiProvider implements ProviderInterface {

	protected function endpoint(): string {
		return 'https://api.openai.com/v1/chat/completions';
	}

	public function id(): string {
		return 'openai';
	}

	public function label(): string {
		return 'OpenAI';
	}

	public function default_model(): string {
		return 'gpt-4o';
	}

	public function send( array $messages, array $tools, string $system, string $model, string $api_key ): array {
		$payload_messages = array_merge(
			array(
				array(
					'role'    => 'system',
					'content' => $system,
				),
			),
			$this->to_openai_messages( $messages )
		);

		$body = array(
			'model'    => $model ?: $this->default_model(),
			'messages' => $payload_messages,
		);

		if ( $tools ) {
			$body['tools'] = array_map(
				static function ( array $t ): array {
					return array(
						'type'     => 'function',
						'function' => array(
							'name'        => $t['name'],
							'description' => $t['description'],
							'parameters'  => $t['inputSchema'],
						),
					);
				},
				$tools
			);
		}

		$response = wp_remote_post(
			$this->endpoint(),
			array(
				'timeout' => 120,
				'headers' => $this->headers( $api_key ),
				'body'    => wp_json_encode( $body ),
			)
		);

		return $this->parse( $response );
	}

	protected function headers( string $api_key ): array {
		return array(
			'content-type'  => 'application/json',
			'authorization' => 'Bearer ' . $api_key,
		);
	}

	protected function to_openai_messages( array $messages ): array {
		$out = array();
		foreach ( $messages as $m ) {
			$role = $m['role'];

			if ( 'tool' === $role ) {
				$out[] = array(
					'role'         => 'tool',
					'tool_call_id' => $m['tool_call_id'] ?? '',
					'content'      => (string) ( $m['content'] ?? '' ),
				);
				continue;
			}

			if ( 'assistant' === $role && ! empty( $m['tool_calls'] ) ) {
				$out[] = array(
					'role'       => 'assistant',
					'content'    => (string) ( $m['content'] ?? '' ),
					'tool_calls' => array_map(
						static function ( array $tc ): array {
							return array(
								'id'       => $tc['id'],
								'type'     => 'function',
								'function' => array(
									'name'      => $tc['name'],
									'arguments' => wp_json_encode( $tc['arguments'] ),
								),
							);
						},
						$m['tool_calls']
					),
				);
				continue;
			}

			$out[] = array(
				'role'    => $role,
				'content' => (string) ( $m['content'] ?? '' ),
			);
		}
		return $out;
	}

	protected function parse( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'text'        => '',
				'tool_calls'  => array(),
				'stop_reason' => 'error',
				'error'       => $response->get_error_message(),
			);
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( isset( $data['error'] ) ) {
			return array(
				'text'        => '',
				'tool_calls'  => array(),
				'stop_reason' => 'error',
				'error'       => $data['error']['message'] ?? 'API error.',
			);
		}

		$choice     = $data['choices'][0] ?? array();
		$message    = $choice['message'] ?? array();
		$text       = (string) ( $message['content'] ?? '' );
		$tool_calls = array();

		foreach ( (array) ( $message['tool_calls'] ?? array() ) as $tc ) {
			$args         = json_decode( (string) ( $tc['function']['arguments'] ?? '{}' ), true );
			$tool_calls[] = array(
				'id'        => $tc['id'] ?? uniqid( 'call_', true ),
				'name'      => $tc['function']['name'] ?? '',
				'arguments' => is_array( $args ) ? $args : array(),
			);
		}

		return array(
			'text'        => $text,
			'tool_calls'  => $tool_calls,
			'stop_reason' => $choice['finish_reason'] ?? 'stop',
			'usage'       => $data['usage'] ?? array(),
			'raw'         => $data,
		);
	}
}
