<?php
/**
 * Model provider contract. Each provider normalises its vendor's tool-calling
 * API into one internal shape so the agent loop is provider-agnostic.
 *
 * Internal message shape (array of):
 *   [ 'role' => 'user'|'assistant'|'tool', 'content' => string,
 *     'tool_calls' => [ ['id','name','arguments'(array)] ]?,   // assistant turns
 *     'tool_call_id' => string?, 'name' => string? ]           // tool result turns
 *
 * Normalised response shape:
 *   [ 'text' => string, 'tool_calls' => [ ['id','name','arguments'] ],
 *     'stop_reason' => string, 'usage' => array, 'raw' => array ]
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Agent\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface ProviderInterface {

	/** Provider slug, e.g. "anthropic". */
	public function id(): string;

	/** Human label. */
	public function label(): string;

	/**
	 * Default model id for this provider.
	 */
	public function default_model(): string;

	/**
	 * Send a turn to the model.
	 *
	 * @param array<int,array<string,mixed>> $messages   Internal message list.
	 * @param array<int,array<string,mixed>> $tools      MCP-style tool descriptors.
	 * @param string                         $system     System prompt.
	 * @param string                         $model      Model id.
	 * @param string                         $api_key    Decrypted API key.
	 * @return array<string,mixed> Normalised response.
	 */
	public function send( array $messages, array $tools, string $system, string $model, string $api_key ): array;
}
