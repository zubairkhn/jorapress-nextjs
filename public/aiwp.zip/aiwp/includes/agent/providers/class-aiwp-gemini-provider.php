<?php
/**
 * Google Gemini provider (generateContent with function calling).
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Agent\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GeminiProvider implements ProviderInterface {

	public function id(): string {
		return 'gemini';
	}

	public function label(): string {
		return 'Google Gemini';
	}

	public function default_model(): string {
		return 'gemini-1.5-pro';
	}

	public function send( array $messages, array $tools, string $system, string $model, string $api_key ): array {
		$model = $model ?: $this->default_model();
		$url   = sprintf(
			'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
			rawurlencode( $model ),
			rawurlencode( $api_key )
		);

		$body = array(
			'system_instruction' => array(
				'parts' => array( array( 'text' => $system ) ),
			),
			'contents'           => $this->to_gemini_contents( $messages ),
		);

		if ( $tools ) {
			$body['tools'] = array(
				array(
					'function_declarations' => array_map(
						static function ( array $t ): array {
							return array(
								'name'        => $t['name'],
								'description' => $t['description'],
								'parameters'  => $t['inputSchema'],
							);
						},
						$tools
					),
				),
			);
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 120,
				'headers' => array( 'content-type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);

		return $this->parse( $response );
	}

	private function to_gemini_contents( array $messages ): array {
		$out = array();
		foreach ( $messages as $m ) {
			$role = $m['role'];

			if ( 'tool' === $role ) {
				$out[] = array(
					'role'  => 'user',
					'parts' => array(
						array(
							'functionResponse' => array(
								'name'     => $m['name'] ?? 'tool',
								'response' => array( 'result' => (string) ( $m['content'] ?? '' ) ),
							),
						),
					),
				);
				continue;
			}

			$g_role = 'assistant' === $role ? 'model' : 'user';

			if ( 'assistant' === $role && ! empty( $m['tool_calls'] ) ) {
				$parts = array();
				if ( ! empty( $m['content'] ) ) {
					$parts[] = array( 'text' => (string) $m['content'] );
				}
				foreach ( $m['tool_calls'] as $tc ) {
					$parts[] = array(
						'functionCall' => array(
							'name' => $tc['name'],
							'args' => (object) $tc['arguments'],
						),
					);
				}
				$out[] = array(
					'role'  => 'model',
					'parts' => $parts,
				);
				continue;
			}

			$out[] = array(
				'role'  => $g_role,
				'parts' => array( array( 'text' => (string) ( $m['content'] ?? '' ) ) ),
			);
		}
		return $out;
	}

	private function parse( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'text'        => '',
				'tool_calls'  => array(),
				'stop_reason' => 'error',
				'error'       => $response->get_error_message(),
			);
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( isset( $data['error'] ) ) {
			return array(
				'text'        => '',
				'tool_calls'  => array(),
				'stop_reason' => 'error',
				'error'       => $data['error']['message'] ?? 'Gemini API error.',
			);
		}

		$parts      = $data['candidates'][0]['content']['parts'] ?? array();
		$text       = '';
		$tool_calls = array();
		foreach ( (array) $parts as $part ) {
			if ( isset( $part['text'] ) ) {
				$text .= $part['text'];
			} elseif ( isset( $part['functionCall'] ) ) {
				$tool_calls[] = array(
					'id'        => uniqid( 'call_', true ),
					'name'      => $part['functionCall']['name'] ?? '',
					'arguments' => (array) ( $part['functionCall']['args'] ?? array() ),
				);
			}
		}

		return array(
			'text'        => $text,
			'tool_calls'  => $tool_calls,
			'stop_reason' => $data['candidates'][0]['finishReason'] ?? 'STOP',
			'usage'       => $data['usageMetadata'] ?? array(),
			'raw'         => $data,
		);
	}
}
