<?php
/**
 * OpenRouter provider — OpenAI-compatible wire format, different base URL and
 * a wide model catalogue (anthropic/*, openai/*, google/* …).
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Agent\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class OpenRouterProvider extends OpenAiProvider {

	protected function endpoint(): string {
		return 'https://openrouter.ai/api/v1/chat/completions';
	}

	public function id(): string {
		return 'openrouter';
	}

	public function label(): string {
		return 'OpenRouter';
	}

	public function default_model(): string {
		return 'anthropic/claude-sonnet-4';
	}

	protected function headers( string $api_key ): array {
		return array(
			'content-type'  => 'application/json',
			'authorization' => 'Bearer ' . $api_key,
			'http-referer'  => home_url( '/' ),
			'x-title'       => 'AIWP',
		);
	}
}
