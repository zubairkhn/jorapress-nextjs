<?php
/**
 * Provider manager: model abstraction layer. Resolves the active provider and
 * supplies the decrypted API key from encrypted option storage.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Agent;

use AIWP\Agent\Providers\ProviderInterface;
use AIWP\Agent\Providers\AnthropicProvider;
use AIWP\Agent\Providers\OpenAiProvider;
use AIWP\Agent\Providers\GeminiProvider;
use AIWP\Agent\Providers\OpenRouterProvider;
use AIWP\Core\Crypto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ProviderManager {

	/** @var array<string,ProviderInterface> */
	private array $providers = array();

	public function __construct() {
		foreach ( array( new AnthropicProvider(), new OpenAiProvider(), new GeminiProvider(), new OpenRouterProvider() ) as $p ) {
			$this->providers[ $p->id() ] = $p;
		}
	}

	/**
	 * @return array<string,ProviderInterface>
	 */
	public function all(): array {
		return $this->providers;
	}

	public function get( string $id ): ?ProviderInterface {
		return $this->providers[ $id ] ?? null;
	}

	public function active(): ?ProviderInterface {
		$id = (string) get_option( 'aiwp_provider', 'anthropic' );
		return $this->get( $id );
	}

	public function active_model(): string {
		$model = (string) get_option( 'aiwp_model', '' );
		if ( '' !== $model ) {
			return $model;
		}
		$provider = $this->active();
		return $provider ? $provider->default_model() : '';
	}

	/**
	 * Store an API key for a provider, encrypted at rest.
	 */
	public function set_api_key( string $provider_id, string $key ): void {
		update_option( 'aiwp_key_' . sanitize_key( $provider_id ), Crypto::encrypt( $key ), false );
	}

	public function api_key( string $provider_id ): string {
		$stored = (string) get_option( 'aiwp_key_' . sanitize_key( $provider_id ), '' );
		return Crypto::decrypt( $stored );
	}

	public function has_api_key( string $provider_id ): bool {
		return '' !== $this->api_key( $provider_id );
	}
}
