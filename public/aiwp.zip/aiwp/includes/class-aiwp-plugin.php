<?php
/**
 * Main plugin orchestrator (singleton).
 *
 * Wires together the shared Execution Core, the MCP front door, the admin
 * chat panel front door and the Pro layer. Everything hangs off one engine.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP;

use AIWP\Core\ToolRouter;
use AIWP\Core\Safety;
use AIWP\Core\AuditLog;
use AIWP\Mcp\Server as McpServer;
use AIWP\Rest\AdminController;
use AIWP\Rest\DoctorController;
use AIWP\Admin\Admin;
use AIWP\Skills\SkillsManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static ?Plugin $instance = null;

	private ToolRouter $router;
	private Safety $safety;
	private AuditLog $audit;
	private SkillsManager $skills;

	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->audit  = new AuditLog();
		$this->safety = new Safety();
		$this->skills = new SkillsManager();
		$this->router = new ToolRouter( $this->safety, $this->audit );
	}

	/**
	 * Boot the plugin once WordPress is loaded.
	 */
	public function boot(): void {
		load_plugin_textdomain( 'aiwp', false, dirname( AIWP_BASENAME ) . '/languages' );

		// Crash guard must register as early as possible so AI-loaded snippets
		// never white-screen the site.
		Core\CrashGuard::register();

		// Scheduled Site Doctor audits (WP-Cron) — read-only, opt-in.
		Core\Reporter::register();

		// Register the tool set on the shared router.
		$this->router->register_default_tools();

		// Let seo_fix force-enable the core XML sitemap if a site had it disabled.
		add_filter(
			'wp_sitemaps_enabled',
			static fn( $enabled ) => get_option( 'aiwp_force_core_sitemap' ) ? true : $enabled
		);

		// Front door A — MCP endpoint (REST/JSON-RPC).
		( new McpServer( $this->router, $this->safety, $this->audit ) )->hooks();

		// Front door B — admin chat panel REST controller + agent loop.
		( new AdminController( $this->router, $this->safety, $this->audit, $this->skills ) )->hooks();

		// Site Doctor — diagnostics + remediation dashboard REST controller.
		( new DoctorController( $this->router, $this->safety, $this->audit ) )->hooks();

		// Admin UI (settings, connect, audit, sandbox, chat).
		if ( is_admin() ) {
			( new Admin( $this->safety, $this->audit ) )->hooks();
		}

		do_action( 'aiwp_booted', $this );
	}

	public function router(): ToolRouter {
		return $this->router;
	}

	public function safety(): Safety {
		return $this->safety;
	}

	public function audit(): AuditLog {
		return $this->audit;
	}

	public function skills(): SkillsManager {
		return $this->skills;
	}
}
