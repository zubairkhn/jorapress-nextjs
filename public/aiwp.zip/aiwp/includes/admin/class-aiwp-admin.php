<?php
/**
 * Admin UI: menu, page routing, asset loading, settings registration and the
 * activation security notice.
 *
 * @package AIWP
 */

declare( strict_types=1 );

namespace AIWP\Admin;

use AIWP\Core\Safety;
use AIWP\Core\AuditLog;
use AIWP\Licensing\License;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin {

	private Settings $settings;

	public function __construct(
		private Safety $safety,
		private AuditLog $audit
	) {
		$this->settings = new Settings( $safety );
	}

	public function hooks(): void {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this->settings, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'profile_assets' ) );
		add_action( 'admin_notices', array( $this, 'notices' ) );
		add_action( 'init', array( License::class, 'register_updates' ) );
	}

	public function menu(): void {
		$cap = AIWP_CAPABILITY;

		add_menu_page(
			__( 'AIWP', 'aiwp' ),
			__( 'AIWP Builder', 'aiwp' ),
			$cap,
			'aiwp',
			array( $this, 'render_dashboard' ),
			'dashicons-superhero',
			58
		);

		$pages = array(
			'aiwp'          => __( 'Dashboard', 'aiwp' ),
			'aiwp-chat'     => __( 'Chat', 'aiwp' ),
			'aiwp-doctor'   => __( 'Site Doctor', 'aiwp' ),
			'aiwp-connect'  => __( 'Connect (MCP)', 'aiwp' ),
			'aiwp-sandbox'  => __( 'Sandbox', 'aiwp' ),
			'aiwp-audit'    => __( 'Audit Log', 'aiwp' ),
			'aiwp-settings' => __( 'Settings', 'aiwp' ),
		);

		$callbacks = array(
			'aiwp-chat'     => 'render_chat',
			'aiwp-doctor'   => 'render_doctor',
			'aiwp-connect'  => 'render_connect',
			'aiwp-sandbox'  => 'render_sandbox',
			'aiwp-audit'    => 'render_audit',
			'aiwp-settings' => 'render_settings',
		);

		foreach ( $pages as $slug => $title ) {
			if ( 'aiwp' === $slug ) {
				continue;
			}
			add_submenu_page( 'aiwp', $title, $title, $cap, $slug, array( $this, $callbacks[ $slug ] ) );
		}

		// Rename the first submenu entry to "Dashboard".
		add_submenu_page( 'aiwp', __( 'Dashboard', 'aiwp' ), __( 'Dashboard', 'aiwp' ), $cap, 'aiwp', array( $this, 'render_dashboard' ) );
	}

	public function assets( string $hook ): void {
		if ( ! str_contains( $hook, 'aiwp' ) ) {
			return;
		}

		wp_enqueue_style( 'aiwp-admin', AIWP_URL . 'admin/css/admin.css', array(), AIWP_VERSION );

		wp_enqueue_script( 'aiwp-admin', AIWP_URL . 'admin/js/admin.js', array( 'wp-api-fetch' ), AIWP_VERSION, true );
		wp_enqueue_script( 'aiwp-doctor', AIWP_URL . 'admin/js/doctor.js', array( 'aiwp-admin' ), AIWP_VERSION, true );
		wp_localize_script(
			'aiwp-admin',
			'AIWP',
			array(
				'root'     => esc_url_raw( rest_url( AIWP_REST_NAMESPACE ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'enabled'  => $this->safety->is_enabled(),
				'strings'  => array(
					'thinking' => __( 'Thinking…', 'aiwp' ),
					'approve'  => __( 'Approve', 'aiwp' ),
					'deny'     => __( 'Deny', 'aiwp' ),
				),
			)
		);
	}

	/**
	 * Enhance WordPress core's Application Passwords screen so a freshly created
	 * password is also offered as a ready-to-use Base64 HTTP Basic value. Core
	 * only shows the space-chunked raw password, which most people then have to
	 * Base64-encode by hand before they can use it with the MCP endpoint / REST
	 * API. We compute it in the browser (the password never returns to PHP).
	 */
	public function profile_assets( string $hook ): void {
		if ( 'profile.php' !== $hook && 'user-edit.php' !== $hook ) {
			return;
		}

		$user_id = ( 'user-edit.php' === $hook && isset( $_GET['user_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			? (int) $_GET['user_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: get_current_user_id();

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		wp_enqueue_script( 'aiwp-app-password', AIWP_URL . 'admin/js/app-password.js', array(), AIWP_VERSION, true );
		wp_localize_script(
			'aiwp-app-password',
			'AIWP_APP_PW',
			array(
				'login'   => $user->user_login,
				'strings' => array(
					'header' => __( 'Authorization header (ready to use — Base64 of username:password):', 'aiwp' ),
					'token'  => __( 'Base64 token only:', 'aiwp' ),
					'copy'   => __( 'Copy', 'aiwp' ),
					'copied' => __( 'Copied!', 'aiwp' ),
				),
			)
		);
	}

	public function notices(): void {
		if ( get_transient( 'aiwp_activation_notice' ) ) {
			delete_transient( 'aiwp_activation_notice' );
			printf(
				'<div class="notice notice-warning"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'AIWP installed.', 'aiwp' ),
				esc_html__( 'This plugin enables remote code execution and is intended for dev/staging only. AI abilities are OFF until you enable them in AIWP → Dashboard.', 'aiwp' )
			);
		}

		if ( $this->safety->looks_like_production() && ! $this->safety->production_ack() && $this->safety->is_enabled() ) {
			printf(
				'<div class="notice notice-error"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'AIWP production warning:', 'aiwp' ),
				esc_html__( 'This looks like a production site. AI tool calls are blocked until you acknowledge the risk in AIWP → Settings.', 'aiwp' )
			);
		}
	}

	// --- Page renderers ----------------------------------------------------

	public function render_dashboard(): void {
		$this->view( 'dashboard' );
	}

	public function render_chat(): void {
		$this->view( 'chat' );
	}

	public function render_doctor(): void {
		$this->view( 'doctor' );
	}

	public function render_connect(): void {
		$this->view( 'connect' );
	}

	public function render_sandbox(): void {
		$this->view( 'sandbox' );
	}

	public function render_audit(): void {
		$this->view( 'audit' );
	}

	public function render_settings(): void {
		$this->view( 'settings' );
	}

	private function view( string $name ): void {
		$file = AIWP_DIR . 'includes/admin/views/' . $name . '.php';
		if ( is_readable( $file ) ) {
			$safety   = $this->safety;
			$audit    = $this->audit;
			$settings = $this->settings;
			include $file;
		}
	}
}
