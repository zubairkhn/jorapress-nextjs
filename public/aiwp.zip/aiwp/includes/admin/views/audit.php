<?php
/**
 * Audit log view.
 *
 * @package AIWP
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiwp-wrap">
	<h1><?php esc_html_e( 'Audit Log', 'aiwp' ); ?></h1>
	<p><?php esc_html_e( 'Every tool call: who, when, what, and the result. Read-only.', 'aiwp' ); ?></p>

	<div id="aiwp-audit" data-aiwp-app="audit">
		<p class="aiwp-loading"><?php esc_html_e( 'Loading…', 'aiwp' ); ?></p>
	</div>
</div>
