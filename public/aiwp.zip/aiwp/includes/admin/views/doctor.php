<?php
/**
 * Site Doctor view. Runs the diagnostic scanners and lets the operator apply
 * (or preview) fixes, grouped by Bugs / Performance / SEO / Health.
 *
 * @package AIWP
 * @var \AIWP\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$writes  = $safety->writes_allowed();
$enabled = $safety->is_enabled();
?>
<div class="wrap aiwp-wrap" id="aiwp-doctor">
	<h1><span class="dashicons dashicons-heart"></span> <?php esc_html_e( 'Site Doctor', 'aiwp' ); ?></h1>
	<p class="aiwp-tagline"><?php esc_html_e( 'Diagnose and fix bugs, performance and SEO issues. Scans are read-only; fixes are gated, snapshotted and reversible.', 'aiwp' ); ?></p>

	<?php if ( ! $enabled || ! $writes ) : ?>
		<div class="notice notice-info inline"><p>
			<?php esc_html_e( 'Scanning works any time. Applying fixes needs AI abilities enabled (Dashboard) and writes allowed (Settings).', 'aiwp' ); ?>
		</p></div>
	<?php endif; ?>

	<p>
		<button class="button button-primary button-hero" id="aiwp-doctor-scan"><?php esc_html_e( 'Run full scan', 'aiwp' ); ?></button>
		<span class="aiwp-doctor-meta" id="aiwp-doctor-meta"></span>
	</p>

	<div class="aiwp-doctor-score" id="aiwp-doctor-score" hidden>
		<div class="aiwp-score-ring" id="aiwp-score-ring"><span id="aiwp-score-num">–</span></div>
		<div class="aiwp-score-counts" id="aiwp-score-counts"></div>
	</div>

	<div id="aiwp-doctor-results" class="aiwp-doctor-results"></div>
</div>
