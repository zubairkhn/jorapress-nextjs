<?php
/**
 * Connect view — generates copy-paste setup for popular MCP clients using the
 * site's Application Password flow. The Base64 Authorization header is built
 * live in the browser from the app password the user pastes (WordPress never
 * exposes the password to the server, so it cannot be pre-computed server-side).
 *
 * @package AIWP
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mcp_url    = rest_url( AIWP_REST_NAMESPACE . '/mcp' );
$app_pw_url = admin_url( 'profile.php#application-passwords-section' );
$user       = wp_get_current_user();
$login      = $user->user_login;
$is_https   = ( 0 === strpos( (string) $mcp_url, 'https://' ) );
?>
<div class="wrap aiwp-wrap" data-aiwp-app="connect"
	data-mcp-url="<?php echo esc_attr( $mcp_url ); ?>"
	data-login="<?php echo esc_attr( $login ); ?>"
	data-allow-http="<?php echo $is_https ? '0' : '1'; ?>">

	<h1><?php esc_html_e( 'Connect an AI client (MCP)', 'aiwp' ); ?></h1>
	<p><?php esc_html_e( 'Bring your own agent. Connect Claude Desktop, Claude Code, Cursor, Windsurf or any MCP client to this site.', 'aiwp' ); ?></p>

	<ol class="aiwp-steps">
		<li>
			<strong><?php esc_html_e( 'Create an Application Password.', 'aiwp' ); ?></strong>
			<?php
			printf(
				/* translators: link */
				esc_html__( 'Go to %s, add one named "AIWP", and copy the generated password.', 'aiwp' ),
				'<a href="' . esc_url( $app_pw_url ) . '">' . esc_html__( 'your profile → Application Passwords', 'aiwp' ) . '</a>'
			);
			?>
		</li>
		<li><strong><?php esc_html_e( 'Enable AI abilities', 'aiwp' ); ?></strong> <?php esc_html_e( 'on the Dashboard (master switch).', 'aiwp' ); ?></li>
		<li><strong><?php esc_html_e( 'Paste the password below', 'aiwp' ); ?></strong> <?php esc_html_e( '— the config snippets fill in automatically. Then copy them into your client.', 'aiwp' ); ?></li>
	</ol>

	<h2><?php esc_html_e( 'Endpoint', 'aiwp' ); ?></h2>
	<p><code class="aiwp-copy"><?php echo esc_html( $mcp_url ); ?></code> &nbsp; <?php esc_html_e( 'Transport: Streamable HTTP (JSON-RPC 2.0). Auth: HTTP Basic (Application Password).', 'aiwp' ); ?></p>

	<table class="form-table" role="presentation">
		<tr>
			<th><label for="aiwp-connect-user"><?php esc_html_e( 'WordPress username', 'aiwp' ); ?></label></th>
			<td><input type="text" id="aiwp-connect-user" class="regular-text" value="<?php echo esc_attr( $login ); ?>"></td>
		</tr>
		<tr>
			<th><label for="aiwp-connect-pass"><?php esc_html_e( 'Application Password', 'aiwp' ); ?></label></th>
			<td>
				<input type="text" id="aiwp-connect-pass" class="regular-text" autocomplete="off"
					placeholder="<?php esc_attr_e( 'e.g. abcd EFGH ijkl MNOP qrst UVWX', 'aiwp' ); ?>">
				<p class="description"><?php esc_html_e( 'Computed in your browser only. Never sent to the server or stored.', 'aiwp' ); ?></p>
			</td>
		</tr>
	</table>

	<h2><?php esc_html_e( 'Authorization header', 'aiwp' ); ?></h2>
	<p><code id="aiwp-connect-header" class="aiwp-copy"><?php esc_html_e( 'Basic … (paste your password above)', 'aiwp' ); ?></code></p>

	<h2><?php esc_html_e( 'Claude Desktop (claude_desktop_config.json)', 'aiwp' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Claude Desktop config launches local processes, so a remote HTTP server is bridged through mcp-remote (needs Node.js). Restart Claude Desktop after saving.', 'aiwp' ); ?></p>
	<pre class="aiwp-pre" id="aiwp-connect-desktop"></pre>

	<h2><?php esc_html_e( 'Claude Code (CLI)', 'aiwp' ); ?></h2>
	<pre class="aiwp-pre" id="aiwp-connect-claudecode"></pre>

	<h2><?php esc_html_e( 'Cursor / Windsurf (mcp.json)', 'aiwp' ); ?></h2>
	<pre class="aiwp-pre" id="aiwp-connect-cursor"></pre>

	<?php if ( ! $is_https ) : ?>
		<p class="description">
			<strong><?php esc_html_e( 'Note:', 'aiwp' ); ?></strong>
			<?php esc_html_e( 'This site is served over plain HTTP, so the mcp-remote bridge includes the --allow-http flag. For any non-local site, use HTTPS instead.', 'aiwp' ); ?>
		</p>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Test prompt', 'aiwp' ); ?></h2>
	<blockquote><?php esc_html_e( '"List the active plugins, then build a hero + features + CTA section in Elementor on the page titled Home."', 'aiwp' ); ?></blockquote>
</div>
