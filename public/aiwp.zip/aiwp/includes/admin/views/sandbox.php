<?php
/**
 * Sandbox view — lists AI-written files with disable / enable / revert actions.
 * Driven by the REST API + admin.js.
 *
 * @package AIWP
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiwp-wrap">
	<h1><?php esc_html_e( 'AI Sandbox', 'aiwp' ); ?></h1>
	<p><?php esc_html_e( 'Files the AI wrote into the recoverable sandbox directory. A file that caused a fatal error is auto-disabled. Everything here is one-click revertible.', 'aiwp' ); ?></p>

	<div id="aiwp-sandbox" data-aiwp-app="sandbox">
		<p class="aiwp-loading"><?php esc_html_e( 'Loading…', 'aiwp' ); ?></p>
	</div>
</div>
