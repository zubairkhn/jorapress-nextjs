<?php
/**
 * Chat panel view. The conversation UI is rendered by admin.js against the
 * /chat/run and /chat/approve REST endpoints.
 *
 * @package AIWP
 * @var \AIWP\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiwp-wrap aiwp-chat-wrap">
	<h1><?php esc_html_e( 'AIWP Chat', 'aiwp' ); ?></h1>

	<?php if ( ! $safety->is_enabled() ) : ?>
		<div class="notice notice-warning inline"><p>
			<?php
			printf(
				/* translators: link */
				esc_html__( 'AI abilities are disabled. Enable them on the %s first.', 'aiwp' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=aiwp' ) ) . '">' . esc_html__( 'Dashboard', 'aiwp' ) . '</a>'
			);
			?>
		</p></div>
	<?php endif; ?>

	<div id="aiwp-chat" data-aiwp-app="chat">
		<div id="aiwp-chat-log" class="aiwp-chat-log"></div>
		<div id="aiwp-chat-pending" class="aiwp-chat-pending" hidden></div>
		<form id="aiwp-chat-form" class="aiwp-chat-form">
			<textarea id="aiwp-chat-input" rows="2" placeholder="<?php esc_attr_e( 'e.g. Rebuild my homepage hero in Elementor with a headline, subtext and a Get started button…', 'aiwp' ); ?>"></textarea>
			<button type="submit" class="button button-primary"><?php esc_html_e( 'Send', 'aiwp' ); ?></button>
		</form>
		<p class="description"><?php esc_html_e( 'The agent will read your site, propose changes, and (when approval is on) pause before any write.', 'aiwp' ); ?></p>
	</div>
</div>
