<?php
/**
 * Dashboard view. Master switch, status at a glance, quick links.
 *
 * @package AIWP
 * @var \AIWP\Core\Safety $safety
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$enabled    = $safety->is_enabled();
$is_prod    = $safety->looks_like_production();
$prod_ack   = $safety->production_ack();
$writes     = $safety->writes_allowed();
?>
<div class="wrap aiwp-wrap">
	<h1><span class="dashicons dashicons-superhero"></span> <?php esc_html_e( 'AIWP — AI WordPress Builder', 'aiwp' ); ?></h1>
	<p class="aiwp-tagline"><?php esc_html_e( 'A secure bridge that lets an AI agent build and design this site. Bring your own agent over MCP, or use the built-in chat panel.', 'aiwp' ); ?></p>

	<?php if ( $is_prod && ! $prod_ack ) : ?>
		<div class="notice notice-error inline"><p>
			<strong><?php esc_html_e( 'Production site detected.', 'aiwp' ); ?></strong>
			<?php esc_html_e( 'AIWP is meant for dev/staging. Tool calls are blocked until you acknowledge the risk in Settings.', 'aiwp' ); ?>
		</p></div>
	<?php endif; ?>

	<div class="aiwp-cards">
		<div class="aiwp-card aiwp-card--switch">
			<h2><?php esc_html_e( 'AI abilities', 'aiwp' ); ?></h2>
			<p class="aiwp-status <?php echo $enabled ? 'on' : 'off'; ?>">
				<?php echo $enabled ? esc_html__( 'ENABLED', 'aiwp' ) : esc_html__( 'DISABLED', 'aiwp' ); ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'aiwp_toggle' ); ?>
				<input type="hidden" name="action" value="aiwp_toggle">
				<input type="hidden" name="enabled" value="<?php echo $enabled ? '0' : '1'; ?>">
				<button class="button button-<?php echo $enabled ? 'secondary' : 'primary'; ?> button-hero">
					<?php echo $enabled ? esc_html__( 'Disable all AI (kill switch)', 'aiwp' ) : esc_html__( 'Enable AI abilities', 'aiwp' ); ?>
				</button>
			</form>
		</div>

		<div class="aiwp-card">
			<h2><?php esc_html_e( 'Status', 'aiwp' ); ?></h2>
			<ul class="aiwp-statuslist">
				<li><?php esc_html_e( 'Environment', 'aiwp' ); ?>: <strong><?php echo esc_html( function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'unknown' ); ?></strong></li>
				<li><?php esc_html_e( 'Looks like production', 'aiwp' ); ?>: <strong><?php echo $is_prod ? esc_html__( 'yes', 'aiwp' ) : esc_html__( 'no', 'aiwp' ); ?></strong></li>
				<li><?php esc_html_e( 'Writes allowed', 'aiwp' ); ?>: <strong><?php echo $writes ? esc_html__( 'yes', 'aiwp' ) : esc_html__( 'no (read-only)', 'aiwp' ); ?></strong></li>
				<li><?php esc_html_e( 'MCP endpoint', 'aiwp' ); ?>: <code><?php echo esc_html( rest_url( AIWP_REST_NAMESPACE . '/mcp' ) ); ?></code></li>
			</ul>
		</div>

		<div class="aiwp-card">
			<h2><?php esc_html_e( 'Get started', 'aiwp' ); ?></h2>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=aiwp-chat' ) ); ?>"><?php esc_html_e( 'Open Chat', 'aiwp' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=aiwp-connect' ) ); ?>"><?php esc_html_e( 'Connect an AI client', 'aiwp' ); ?></a>
			</p>
			<p class="description"><?php esc_html_e( 'Non-technical? Use Chat. Developer? Connect Claude Code / Cursor / Windsurf over MCP.', 'aiwp' ); ?></p>
		</div>
	</div>
</div>
