# AIWP — AI WordPress Builder

A **Novamira-style** plugin that lets an AI agent build and design WordPress
sites (Elementor, Bricks, Divi, Gutenberg, …) through natural-language prompts.

> **The core idea:** AIWP is *not* "a chatbox that calls OpenAI." It is a secure
> **remote-execution bridge**. The plugin ships **no AI model and no API key** in
> its MCP mode — the intelligence is *your* agent (Claude Code, Cursor, Windsurf).
> It works with "every builder" because there is no per-builder code: the AI just
> runs PHP/SQL and writes each builder's own data structure.

Author: **Zubair** · License: GPL-2.0-or-later · Slug/text-domain: `aiwp`
*(rename later — a find-and-replace of `aiwp`/`AIWP` does it)*

> ⚠️ **This plugin enables remote arbitrary code execution. It is for
> dev/staging only.** AI abilities ship **OFF** and are gated behind a master
> switch, capability checks, a production guardrail, write gating, rate limits,
> a crash guard, automatic backups and an immutable audit log.

---

## Architecture

One shared **Execution Core**, two interchangeable front doors:

```
A) MCP endpoint  (/wp-json/aiwp/v1/mcp, JSON-RPC 2.0)  ← external AI client
B) Admin chat panel (wp-admin + server-side agent loop) ← BYO API key
            │
            ▼
   Auth & capability gate → Tool router → Safety layer
   execute_php · db_query · read/write/edit/list file · wp_cli · wp_rest
   sandbox · crash guard · backups · audit log · rate limit · kill switch
```

### The tools (primitives)

| Tool | Purpose |
|------|---------|
| `execute_php` | Run PHP in the WP runtime (the master key — reaches every builder API). |
| `db_query` | SQL; reads by default, writes gated + snapshotted. |
| `read_file` / `write_file` / `edit_file` / `list_dir` | Filesystem scoped to the install. |
| `wp_cli` | WP-CLI where the host allows shell access. |
| `wp_rest` | Dispatch internal WP REST routes (safer, structured). |

### Site Doctor tools (diagnose + fix)

AIWP also ships a **WordPress Doctor**: scanners that diagnose bugs, performance
and SEO issues, and fixers that remediate them safely. They're available over
MCP, in the chat agent, and from the **AIWP → Site Doctor** dashboard.

| Tool | Purpose |
|------|---------|
| `site_health` | Environment audit: PHP/MySQL, HTTPS, cron, REST, object cache, updates. |
| `error_scan` | Parse the debug log; group errors and attribute them to a plugin/theme. |
| `perf_scan` | Autoload bloat, revisions, transients, oversized images, object cache. |
| `seo_scan` | Meta titles/descriptions, alt text, indexing, sitemap. |
| `bug_fix` | Update plugins, deactivate a fatal-throwing plugin. |
| `perf_fix` | Trim autoload, clean revisions/transients, optimize images. |
| `seo_fix` | Generate meta/alt text, allow indexing, enable sitemap. |

Scanners are read-only (they run even with the master switch off). Fixers route
through the safety layer (write gating, snapshots, audit) and support a
`dry_run` preview. Optional scheduled audits email a health-score report
(**AIWP → Settings → Site Doctor**). See `PLAN-WP-DOCTOR.md` for the full design.

## Install

1. Copy the `aiwp/` folder to `wp-content/plugins/`.
2. (Optional) `composer install` for dev tooling — the plugin runs without it.
3. Activate **AIWP — AI WordPress Builder** in WP admin.
4. Go to **AIWP → Dashboard** and click **Enable AI abilities**.

Requires WordPress 6.5+ and PHP 8.1+.

## Use it — MCP (developers)

1. **AIWP → Connect (MCP)**: create an Application Password, copy the snippet.
2. Add the server to Claude Code / Cursor / Windsurf.
3. Prompt: *"List active plugins, then build a hero + features + CTA in Elementor on the Home page."*

Endpoint: `POST /wp-json/aiwp/v1/mcp` · Transport: Streamable HTTP (JSON-RPC 2.0)
· Auth: HTTP Basic with an Application Password over HTTPS. Implements
`initialize`, `tools/list`, `tools/call`, `ping`.

## Use it — Chat panel (non-technical)

1. **AIWP → Settings**: pick a provider (Anthropic / OpenAI / Gemini / OpenRouter),
   paste your API key (stored encrypted), choose a model.
2. **AIWP → Chat**: type a prompt and watch it build. With *Require approval* on,
   the agent pauses before every write so you can approve or deny.

## Safety model

- **Master kill switch** — instant global off (Dashboard).
- **Production guardrail** — heuristic detection; tool calls refuse on a
  production-looking site until you acknowledge the risk in Settings.
- **Write gating** — DB/file writes are off until enabled; reads always allowed.
- **Crash guard** — wraps `execute_php` and sandbox loads; a fatal is caught and
  the offending file auto-disabled (no white screen).
- **Sandbox** — AI-written files live in `wp-content/uploads/aiwp-sandbox/`,
  tracked, versioned, one-click revertible (AIWP → Sandbox).
- **Backups** — affected rows/posts snapshotted before writes.
- **Audit log** — every tool call recorded (AIWP → Audit Log).
- **Rate limiting** — per-user calls/minute.
- **Encrypted secrets** — API keys encrypted at rest (libsodium → OpenSSL).

## Pro layer (Phase 3)

- **Skills** — Markdown playbooks the agent auto-loads when a task matches
  (`includes/skills/packs/` + user-authored `wp-content/uploads/aiwp-skills/`).
  Bundled: Elementor, Gutenberg, Bricks/Divi/Beaver/Oxygen, site conventions.
- **Memory** — key/value project context across sessions.
- **Licensing/updates** — provider-agnostic scaffold; wire Freemius or EDD +
  a self-hosted update server (`includes/licensing/`). The plugin self-distributes
  because the WordPress.org repo will not accept arbitrary code execution.

## Layout

```
aiwp.php                     bootstrap + constants
includes/
  class-aiwp-autoloader.php  PSR-ish loader
  class-aiwp-plugin.php      orchestrator (one engine, two front doors)
  class-aiwp-activator.php   tables + defaults
  core/                      safety, audit, crash guard, sandbox, backup, crypto, router
  core/tools/                the primitives
  mcp/                       JSON-RPC + MCP server (front door A)
  agent/                     loop + provider manager + providers (front door B)
  skills/  memory/  licensing/   Pro layer
  rest/                      admin chat + dashboard REST
  admin/                     menus, settings, views
admin/js/admin.js            chat + sandbox + audit UI (no build step)
admin/css/admin.css
```

## Renaming for release

Replace `aiwp` (lowercase, used for slug/text-domain/REST namespace/option keys)
and `AIWP` (constants/namespace) consistently, then update the header in
`aiwp.php`. Option keys and the REST namespace change too, so do it before any
production install.
# aiwp
